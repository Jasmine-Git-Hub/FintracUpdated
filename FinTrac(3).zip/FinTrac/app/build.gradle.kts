plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.gms)
    alias(libs.plugins.google.firebase.crashlytics)
}

android {
    namespace = "com.example.fintrac"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.fintrac"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
}

dependencies {
    // Firebase BOM
    implementation(platform(libs.firebase.bom))

    // AndroidX
    implementation(libs.appcompat)
    implementation(libs.activity)
    implementation(libs.constraintlayout)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.androidx.recyclerview)

    // Material
    implementation(libs.material)

    // Firebase
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.crashlytics)
    implementation(libs.firebase.auth)
    implementation(libs.firebase.firestore)

    // Google Play Services - need mo pa rin i-add sa catalog
    implementation("com.google.android.gms:play-services-auth:21.5.0")

    // MPAndroidChart - need mo pa rin i-add sa catalog
    implementation("com.github.PhilJay:MPAndroidChart:v3.1.0")

    // Compose Theme Adapter
    implementation(libs.compose.theme.adapter)

    // Testing
    testImplementation(libs.junit)
    androidTestImplementation(libs.ext.junit)
    androidTestImplementation(libs.espresso.core)
    implementation("com.google.firebase:firebase-messaging:23.4.0")
    // WorkManager para sa libreng background checking ng notifications
    implementation("androidx.work:work-runtime:2.8.1")
    // Add Google Play Services Auth
    implementation("com.google.android.gms:play-services-auth:20.7.0")

}