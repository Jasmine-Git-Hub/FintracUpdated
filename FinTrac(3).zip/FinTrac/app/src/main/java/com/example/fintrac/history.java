package com.example.fintrac;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

@SuppressLint("SetTextI18n")
public class history extends Fragment {

    private TextView tvTransactionCount;
    private HistoryAdapter adapter;
    private List<Transaction> allTransactions;

    private FirebaseFirestore db;
    private FirebaseUser currentUser;

    private String currentFilter = "all";
    private boolean isFetching = false;

    public history() {
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        SettingHelper.applyTheme(requireActivity());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = FirebaseFirestore.getInstance();
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        ChipGroup chipGroupFilter = view.findViewById(R.id.chipGroupFilter);
        tvTransactionCount = view.findViewById(R.id.tvTransactionCount);
        RecyclerView rvHistory = view.findViewById(R.id.rvHistory);

        allTransactions = new ArrayList<>();
        rvHistory.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new HistoryAdapter(new ArrayList<>(), requireContext());
        rvHistory.setAdapter(adapter);

        chipGroupFilter.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (!checkedIds.isEmpty()) {
                int id = checkedIds.get(0);
                if (id == R.id.chipAll) {
                    currentFilter = "all";
                } else if (id == R.id.chipIncome) {
                    currentFilter = "income";
                } else if (id == R.id.chipExpense) {
                    currentFilter = "expense";
                } else if (id == R.id.chipBills) {
                    currentFilter = "bills";
                } else if (id == R.id.chipJars) {
                    currentFilter = "jars";
                }
                filterList();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (currentUser != null) {
            loadAllHistory();
        }
    }

    private void loadAllHistory() {
        if (currentUser == null || isFetching) return;

        isFetching = true;
        allTransactions.clear();
        tvTransactionCount.setText("Loading...");

        String userId = currentUser.getUid();

        AtomicInteger pendingFetches = new AtomicInteger(3);

        Runnable checkAndSort = () -> {
            if (pendingFetches.decrementAndGet() == 0) {
                // Compatible sorting format
                Collections.sort(allTransactions, (t1, t2) -> {
                    Date d1 = getDateFromTransaction(t1);
                    Date d2 = getDateFromTransaction(t2);
                    if (d1 != null && d2 != null) {
                        return d2.compareTo(d1); // Newest first
                    }
                    return 0;
                });

                requireActivity().runOnUiThread(() -> {
                    isFetching = false;
                    Log.d("HistoryFragment", "Total items loaded: " + allTransactions.size());
                    if (allTransactions.isEmpty()) {
                        Toast.makeText(requireContext(), "No history found", Toast.LENGTH_SHORT).show();
                    }
                    filterList();
                });
            }
        };

        loadTransactions(userId, checkAndSort);
        loadBillsAsTransactions(userId, checkAndSort);
        loadJarRootTransactions(userId, checkAndSort);
    }

    private Date getDateFromTransaction(Transaction t) {
        if (t.getTimestamp() != null) {
            return t.getTimestamp().toDate();
        } else if (t.getDate() != null) {
            return t.getDate();
        }
        return new Date();
    }

    private void loadTransactions(String userId, Runnable completionCallback) {
        db.collection("users").document(userId).collection("transactions")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                Transaction item = document.toObject(Transaction.class);
                                item.setId(document.getId());

                                // FILTER: Skip zero-amount transactions that might be jar-related
                                if (item.getAmount() == 0.0) {
                                    String title = item.getTitle();
                                    String desc = item.getDescription();
                                    if ((title != null && (title.contains("Jar") || title.contains("jar"))) ||
                                            (desc != null && (desc.contains("Jar") || desc.contains("jar")))) {
                                        continue; // Skip jar-related zero transactions
                                    }
                                }

                                allTransactions.add(item);
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping transaction", e);
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private void loadBillsAsTransactions(String userId, Runnable completionCallback) {
        db.collection("users").document(userId).collection("bills")
                .whereEqualTo("isPaid", true)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            Transaction billTransaction = createTransactionFromBill(document, userId);
                            if (billTransaction != null) {
                                // FILTER: Skip zero-amount bill transactions
                                if (billTransaction.getAmount() != 0.0) {
                                    allTransactions.add(billTransaction);
                                }
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private Transaction createTransactionFromBill(QueryDocumentSnapshot document, String userId) {
        try {
            String billName = document.getString("name");
            String amountStr = document.getString("amount");

            double amount = 0;
            if (amountStr != null) {
                String cleanAmount = amountStr.replaceAll("[^\\d.]", "");
                if (!cleanAmount.isEmpty()) amount = Double.parseDouble(cleanAmount);
            }

            Transaction tx = new Transaction();
            tx.setId("bill_" + document.getId());
            tx.setTitle("Paid Bill: " + billName);

            String cat = document.getString("category");
            String freq = document.getString("frequency");
            tx.setDescription((cat != null ? cat : "Bill") + " • " + (freq != null ? freq : "One-time"));

            tx.setCategory("Bills");
            tx.setAmount(amount);
            tx.setExpense(true);
            tx.setUserId(userId);

            if (document.contains("timestamp") && document.get("timestamp") != null) {
                Timestamp ts = document.getTimestamp("timestamp");
                if (ts != null) {
                    tx.setTimestamp(ts);
                    tx.setDate(ts.toDate());
                } else {
                    tx.setDate(new Date(10000));
                }
            } else {
                String dueDate = document.getString("dueDate");
                if (dueDate != null) {
                    try {
                        String cleanDate = dueDate.replace("Due: ", "").trim();
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("M/d/yyyy", java.util.Locale.US);
                        Date parsedDate = sdf.parse(cleanDate);
                        if (parsedDate != null) {
                            tx.setDate(parsedDate);
                            tx.setTimestamp(new Timestamp(parsedDate));
                        } else {
                            tx.setDate(new Date(10000));
                        }
                    } catch (Exception e) {
                        tx.setDate(new Date(10000));
                    }
                } else {
                    tx.setDate(new Date(10000));
                }
            }
            return tx;
        } catch (Exception e) {
            Log.e("HistoryFragment", "Error creating bill tx", e);
        }
        return null;
    }

    private void loadJarRootTransactions(String userId, Runnable completionCallback) {
        db.collection("transactions")
                .whereEqualTo("userId", userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                // Check if this is a jar transaction
                                boolean isJarTransaction = document.contains("jarId") ||
                                        document.contains("jarName") ||
                                        (document.contains("type") &&
                                                document.getString("type") != null &&
                                                document.getString("type").equals("ADD_PARTICIPANT"));

                                // Get amount to check if it's zero
                                Double amount = document.getDouble("amount");
                                boolean isZeroAmount = amount != null && amount == 0.0;

                                // Skip zero-amount jar transactions (like ADD_PARTICIPANT)
                                if (isJarTransaction && isZeroAmount) {
                                    Log.d("HistoryFragment", "Skipping zero-amount jar transaction: " + document.getId());
                                    continue;
                                }

                                if (isJarTransaction) {
                                    // This is a jar transaction with non-zero amount
                                    JarTransaction jarTx = document.toObject(JarTransaction.class);
                                    Transaction tx = new Transaction();
                                    tx.setId("root_jar_" + document.getId());

                                    String jarName = jarTx.getJarName() != null ? jarTx.getJarName() : "Shared Jar";
                                    tx.setTitle("Jar Activity: " + jarName);

                                    String note = jarTx.getNote();
                                    tx.setDescription(note != null && !note.isEmpty() ? note : "Savings contribution");

                                    tx.setCategory("Jars");
                                    tx.setAmount(jarTx.getAmount());

                                    boolean isExpense = jarTx.getType() != null &&
                                            (jarTx.getType().equals("WITHDRAW") ||
                                                    jarTx.getType().equals("WITHDRAWAL"));
                                    tx.setExpense(isExpense);
                                    tx.setUserId(userId);

                                    if (jarTx.getTimestamp() != null) {
                                        tx.setTimestamp(jarTx.getTimestamp());
                                        tx.setDate(jarTx.getTimestamp().toDate());
                                    } else {
                                        tx.setDate(new Date());
                                        tx.setTimestamp(new Timestamp(new Date()));
                                    }
                                    allTransactions.add(tx);
                                } else {
                                    // Regular transaction from root collection
                                    Transaction tx = document.toObject(Transaction.class);
                                    tx.setId(document.getId());

                                    // FILTER: Skip zero-amount transactions with jar-related keywords
                                    if (tx.getAmount() == 0.0) {
                                        String title = tx.getTitle();
                                        String desc = tx.getDescription();
                                        if ((title != null && (title.contains("Jar") || title.contains("jar") ||
                                                title.contains("Joined"))) ||
                                                (desc != null && (desc.contains("Jar") || desc.contains("jar") ||
                                                        desc.contains("Joined")))) {
                                            continue; // Skip jar-related zero transactions
                                        }
                                    }

                                    if (tx.getTimestamp() != null) {
                                        tx.setDate(tx.getTimestamp().toDate());
                                    } else if (tx.getDate() == null) {
                                        tx.setDate(new Date());
                                        tx.setTimestamp(new Timestamp(new Date()));
                                    }

                                    allTransactions.add(tx);
                                }
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping root tx", e);
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private void filterList() {
        List<Transaction> filteredList = new ArrayList<>();

        for (Transaction item : allTransactions) {
            String cat = item.getCategory() != null ? item.getCategory().toLowerCase() : "";
            String title = item.getTitle() != null ? item.getTitle() : "";
            String id = item.getId() != null ? item.getId() : "";
            double amount = item.getAmount();

            // EXTRA FILTER: Skip any remaining zero-amount transactions that might be jar-related
            if (amount == 0.0) {
                if ((title != null && (title.contains("Jar") || title.contains("jar") ||
                        title.contains("Joined") || title.contains("joined"))) ||
                        (cat != null && (cat.contains("jar") || cat.contains("jars")))) {
                    continue; // Skip zero-amount jar transactions
                }
            }

            boolean isAutoBill = id.startsWith("bill_");
            boolean isAutoJar = id.startsWith("root_jar_");
            boolean isMarkedAsPaid = title.startsWith("Paid: ") || title.startsWith("Paid Bill: ");
            boolean isManualHomeFrag = !isAutoBill && !isAutoJar && !isMarkedAsPaid;

            switch (currentFilter) {
                case "all":
                    filteredList.add(item);
                    break;
                case "income":
                    if (!item.isExpense() && isManualHomeFrag) {
                        filteredList.add(item);
                    }
                    break;
                case "expense":
                    if (item.isExpense() && isManualHomeFrag) {
                        filteredList.add(item);
                    }
                    break;
                case "bills":
                    if (isAutoBill || isMarkedAsPaid || cat.contains("bills")) {
                        filteredList.add(item);
                    }
                    break;
                case "jars":
                    if (isAutoJar || cat.contains("jars") || cat.contains("jar")) {
                        // For jars filter, only include non-zero transactions
                        if (amount > 0) {
                            filteredList.add(item);
                        }
                    }
                    break;
            }
        }

        adapter.setTransactions(filteredList);
        String text = filteredList.size() == 1 ? "1 transaction" : filteredList.size() + " transactions";
        tvTransactionCount.setText(text);
    }
}