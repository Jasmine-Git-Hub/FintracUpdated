package com.example.fintrac;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;


import androidx.core.app.NotificationCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class DeadlineReminderReceiver extends BroadcastReceiver {

    private static final String CHANNEL_ID = "deadline_reminders_channel";

    @Override
    public void onReceive(Context context, Intent intent) {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser == null) return;

        String userId = currentUser.getUid();
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Calendar today = Calendar.getInstance();
        today.set(Calendar.HOUR_OF_DAY, 0);
        today.set(Calendar.MINUTE, 0);
        today.set(Calendar.SECOND, 0);
        today.set(Calendar.MILLISECOND, 0);

        // Unified check for all modules
        checkBillDeadlines(context, db, userId, today);
        checkJarDeadlines(context, db, userId, today);
        checkChallengeStatus(context, db, userId); // BAGONG DAGDAG
    }

    // --- BILLS LOGIC ---
    private void checkBillDeadlines(Context context, FirebaseFirestore db, String userId, Calendar today) {
        db.collection("users").document(userId).collection("bills")
                .whereEqualTo("isPaid", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        String dueDateStr = doc.getString("dueDate");
                        if (dueDateStr != null) {
                            dueDateStr = dueDateStr.replace("Due: ", "").trim();
                            try {
                                Date dueDate = sdf.parse(dueDateStr);
                                if (dueDate != null) {
                                    processDeadline(context, db, userId, dueDate, today,
                                            "Bill", doc.getString("name"), doc.getString("amount"), doc.getId(), "BILL_DUE");
                                }
                            } catch (Exception e) { Log.e("Deadline", "Bill date error", e); }
                        }
                    }
                });
    }

    // --- JARS LOGIC ---
    private void checkJarDeadlines(Context context, FirebaseFirestore db, String userId, Calendar today) {
        db.collection("jars").whereArrayContains("participants", userId).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Boolean isArchived = doc.getBoolean("isArchived");
                        if (isArchived != null && isArchived) continue;

                        Double saved = doc.getDouble("savedAmount");
                        Double goal = doc.getDouble("goalAmount");
                        if (saved != null && goal != null && saved >= goal) continue;

                        String deadlineStr = doc.getString("deadline");
                        if (deadlineStr != null && !deadlineStr.isEmpty()) {
                            Date deadlineDate = parseJarDate(deadlineStr);
                            if (deadlineDate != null) {
                                processDeadline(context, db, userId, deadlineDate, today,
                                        "Jar", doc.getString("name"), null, doc.getId(), "JAR_DEADLINE");
                            }
                        }
                    }
                });
    }

    // --- CHALLENGES LOGIC (NEW) ---
    private void checkChallengeStatus(Context context, FirebaseFirestore db, String userId) {
        db.collection("users").document(userId).collection("challenges")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    long now = System.currentTimeMillis();
                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Boolean isArchived = doc.getBoolean("isArchived");
                        if (isArchived != null && isArchived) continue;

                        String name = doc.getString("name");
                        Long currentDay = doc.getLong("currentDay");
                        Long totalDays = doc.getLong("totalDays");
                        Long lastCheckIn = doc.getLong("lastCheckInTime");

                        if (currentDay == null || totalDays == null) continue;

                        // 1. Consistency Reminder: Kung lumagpas na ng 20 hours simula nung huling check-in
                        if (lastCheckIn != null && (now - lastCheckIn) > TimeUnit.HOURS.toMillis(20)) {
                            String msg = "Consistency is key! Time to check-in for your '" + name + "' challenge.";
                            showSystemNotification(context, "Challenge Check-in", msg, (name + "checkin").hashCode());
                            addInAppNotification(db, userId, "Challenge Check-in", msg, "CHALLENGE_REMINDER", doc.getId(), name);
                        }

                        // 2. Ending Soon: Kung huling araw na ng challenge
                        if ((totalDays - currentDay) == 1) {
                            String msg = "Last push! Only 1 day left to complete your '" + name + "' challenge!";
                            showSystemNotification(context, "Challenge Ending Soon", msg, (name + "end").hashCode());
                            addInAppNotification(db, userId, "Challenge Ending Soon", msg, "CHALLENGE_DEADLINE", doc.getId(), name);
                        }
                    }
                });
    }

    // --- SHARED HELPERS ---
    private void processDeadline(Context context, FirebaseFirestore db, String userId, Date dueDate, Calendar today,
                                 String typeStr, String title, String amount, String docId, String notifType) {
        Calendar dueCal = Calendar.getInstance();
        dueCal.setTime(dueDate);
        dueCal.set(Calendar.HOUR_OF_DAY, 0);
        dueCal.set(Calendar.MINUTE, 0);
        dueCal.set(Calendar.SECOND, 0);
        dueCal.set(Calendar.MILLISECOND, 0);

        long diffInMillis = dueCal.getTimeInMillis() - today.getTimeInMillis();
        long daysLeft = TimeUnit.MILLISECONDS.toDays(diffInMillis);

        if (daysLeft == 3 || daysLeft == 1 || daysLeft == 0) {
            String timeMsg = (daysLeft == 0) ? "TODAY!" : "in " + daysLeft + " days.";
            String message = "Your " + typeStr + " '" + title + "' is due " + timeMsg;

            showSystemNotification(context, typeStr + " Deadline: " + title, message, docId.hashCode());
            addInAppNotification(db, userId, typeStr + " Deadline: " + title, message, notifType, docId, title);
        }
    }

    private Date parseJarDate(String dateStr) {
        String[] formats = {"yyyy-MM-dd", "MMM dd, yyyy", "MM/dd/yyyy", "dd/MM/yyyy"};
        for (String f : formats) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(f, Locale.getDefault());
                sdf.setLenient(false);
                Date d = sdf.parse(dateStr);
                if (d != null) return d;
            } catch (Exception ignored) {}
        }
        return null;
    }

    private void showSystemNotification(Context context, String title, String message, int notificationId) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "FinTrac Alerts", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        Intent intent = new Intent(context, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        notificationManager.notify(notificationId, builder.build());
    }

    private void addInAppNotification(FirebaseFirestore db, String userId, String title, String message, String type, String relatedId, String relatedName) {
        Map<String, Object> notification = new HashMap<>();
        notification.put("title", title);
        notification.put("message", message);
        notification.put("type", type);
        notification.put("isRead", false);
        notification.put("timestamp", com.google.firebase.firestore.FieldValue.serverTimestamp());

        if (type.contains("JAR")) {
            notification.put("jarId", relatedId);
            notification.put("jarName", relatedName);
        }

        db.collection("users").document(userId).collection("notifications").add(notification);
    }
}