package com.example.fintrac;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class NotificationAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_NORMAL = 0;
    private static final int TYPE_DEADLINE = 1;

    private final List<NotificationItem> notifications; // Made final
    private final Context context; // Made final
    private final OnNotificationActionListener listener; // Made final

    public interface OnNotificationActionListener {
        void onAcceptInvite(NotificationItem notification);
        void onDeclineInvite(NotificationItem notification);
        void onNotificationClick(NotificationItem notification);
        void onDismissReminder(NotificationItem notification);
        // Removed unused onMarkAsRead method
    }

    public NotificationAdapter(Context context, List<NotificationItem> notifications,
                               OnNotificationActionListener listener) {
        this.context = context;
        this.notifications = notifications;
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        NotificationItem notification = notifications.get(position);
        String type = notification.getType();

        // Use deadline layout for reminder and deadline types
        if (type != null && (type.equals("BILL_DUE") ||
                type.equals("JAR_DEADLINE") ||
                type.equals("CHALLENGE_REMINDER") ||
                type.equals("CHALLENGE_DEADLINE") ||
                type.equals("CHALLENGE_CHECKIN"))) {
            return TYPE_DEADLINE;
        }
        return TYPE_NORMAL;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == TYPE_DEADLINE) {
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.item_notification_reminder, parent, false);
            return new DeadlineViewHolder(view);
        } else {
            View view = LayoutInflater.from(context)
                    .inflate(R.layout.item_notification, parent, false);
            return new NormalViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        NotificationItem notification = notifications.get(position);

        if (holder instanceof NormalViewHolder) {
            bindNormalViewHolder((NormalViewHolder) holder, notification);
        } else if (holder instanceof DeadlineViewHolder) {
            bindDeadlineViewHolder((DeadlineViewHolder) holder, notification);
        }
    }

    private void bindNormalViewHolder(@NonNull NormalViewHolder holder, NotificationItem notification) {
        // Set title and message
        holder.title.setText(notification.getTitle());
        holder.message.setText(notification.getMessage());

        // Set time ago
        holder.timeText.setText(getTimeAgo(notification.getTimestamp()));

        // Set icon based on notification type
        int iconResId;
        int iconColor;
        String type = notification.getType();

        if (type == null) type = "";

        // Using if-else instead of switch for better compatibility
        if (type.equals("BILL_PAID")) {
            iconResId = R.drawable.ic_visual_reports;
            iconColor = R.color.green;
            holder.actionButtons.setVisibility(View.GONE);
        } else if (type.equals("JAR_INVITE")) {
            iconResId = R.drawable.ic_add_person;
            iconColor = R.color.blue;
            holder.actionButtons.setVisibility(View.VISIBLE);
            holder.btnAccept.setVisibility(View.VISIBLE);
            holder.btnDecline.setVisibility(View.VISIBLE);
        } else if (type.equals("BILL_DUE")) {
            iconResId = R.drawable.ic_visual_reports;
            iconColor = R.color.red;
            holder.actionButtons.setVisibility(View.GONE);
        } else if (type.equals("JAR_GOAL_REACHED")) {
            iconResId = R.drawable.ic_goal;
            iconColor = R.color.green;
            holder.actionButtons.setVisibility(View.GONE);
        } else if (type.equals("JAR_DEADLINE")) {
            iconResId = R.drawable.ic_notifications;
            iconColor = R.color.red;
            holder.actionButtons.setVisibility(View.GONE);
        } else if (type.equals("CHALLENGE_REMINDER")) {
            iconResId = R.drawable.ic_notifications;
            iconColor = R.color.jar_color_orange;
            holder.actionButtons.setVisibility(View.GONE);
        } else if (type.equals("CHALLENGE_DEADLINE")) {
            iconResId = R.drawable.ic_goal;
            iconColor = R.color.red;
            holder.actionButtons.setVisibility(View.GONE);
        } else {
            iconResId = R.drawable.ic_notifications;
            iconColor = R.color.gray;
            holder.actionButtons.setVisibility(View.GONE);
        }

        holder.icon.setImageResource(iconResId);
        holder.iconCard.setCardBackgroundColor(ContextCompat.getColor(context, iconColor));

        // Show unread indicator
        holder.unreadIndicator.setVisibility(notification.isRead() ? View.GONE : View.VISIBLE);

        // Set click listeners
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onNotificationClick(notification);
            }
        });

        // Accept button click
        if (holder.btnAccept != null) {
            holder.btnAccept.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onAcceptInvite(notification);
                }
            });
        }

        // Decline button click
        if (holder.btnDecline != null) {
            holder.btnDecline.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeclineInvite(notification);
                }
            });
        }
    }

    private void bindDeadlineViewHolder(@NonNull DeadlineViewHolder holder, NotificationItem notification) {
        String type = notification.getType();
        String title = notification.getTitle();
        String message = notification.getMessage();

        // Set due tag based on type and urgency
        String dueTag = "REMINDER";
        int tagColor = R.color.blue;
        int tagBgColor = R.color.blue_light;

        if (type != null) {
            if (type.equals("BILL_DUE")) {
                dueTag = "BILL DUE";
                tagColor = R.color.dashboard_red;
                tagBgColor = R.color.dashboard_red_light;

                // Check if it's today or tomorrow
                if (message != null) {
                    if (message.contains("TODAY") || message.contains("today")) {
                        dueTag = "DUE TODAY!";
                    } else if (message.contains("TOMORROW") || message.contains("tomorrow")) {
                        dueTag = "DUE TOMORROW";
                    }
                }
            } else if (type.equals("JAR_DEADLINE")) {
                dueTag = "JAR DEADLINE";
                tagColor = R.color.jar_color_orange;
                tagBgColor = R.color.warning_bg;
            } else if (type.equals("CHALLENGE_REMINDER")) {
                dueTag = "REMINDER";
                tagColor = R.color.blue;
                tagBgColor = R.color.blue_light;
            } else if (type.equals("CHALLENGE_DEADLINE")) {
                dueTag = "CHALLENGE ENDING";
                tagColor = R.color.jar_color_purple;
                tagBgColor = R.color.purple_light;
            } else if (type.equals("CHALLENGE_CHECKIN")) {
                dueTag = "CHECK-IN TIME";
                tagColor = R.color.green;
                tagBgColor = R.color.green_light;
            }
        }

        holder.dueTag.setText(dueTag);
        holder.dueTag.setTextColor(ContextCompat.getColor(context, tagColor));
        holder.dueTag.setBackgroundTintList(ColorStateList.valueOf(
                ContextCompat.getColor(context, tagBgColor)));

        // Set title - extract just the name part
        String displayTitle = title;
        if (title != null) {
            if (title.contains("Deadline:")) {
                displayTitle = title.replace("Deadline:", "").trim();
            } else if (title.contains("Bill")) {
                displayTitle = title;
            }
        }
        holder.reminderTitle.setText(displayTitle);

        // Set deadline/message text
        if (message != null) {
            holder.deadlineText.setText(message);
        }

        // For challenge reminders, show progress if available
        if (type != null && (type.equals("CHALLENGE_REMINDER") ||
                type.equals("CHALLENGE_CHECKIN") ||
                type.equals("CHALLENGE_DEADLINE"))) {
            holder.progressContainer.setVisibility(View.VISIBLE);

            // Get progress data from notification if available
            Double goalAmount = notification.getGoalAmount();

            if (goalAmount != null && goalAmount > 0) {
                // This is for jar progress
                holder.progressAmount.setText("Goal: " + String.format(Locale.getDefault(), "%.0f", goalAmount));
                holder.progressBar.setProgress(50); // Example progress
                holder.progressDetails.setText("50% complete • Keep going!");
                holder.progressBar.setVisibility(View.VISIBLE);
            } else {
                // Generic challenge text
                holder.progressAmount.setText("In Progress");
                holder.progressDetails.setText("Don't break the streak!");
                holder.progressBar.setVisibility(View.GONE);
            }
        } else {
            holder.progressContainer.setVisibility(View.GONE);
        }

        // Set dismiss button click
        holder.btnDismiss.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDismissReminder(notification);
            }
        });

        // Make the whole item clickable
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onNotificationClick(notification);
            }
        });
    }

    @Override
    public int getItemCount() {
        return notifications.size();
    }

    private String getTimeAgo(Date date) {
        if (date == null) return "";

        long now = System.currentTimeMillis();
        long diff = now - date.getTime();
        long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
        long hours = TimeUnit.MILLISECONDS.toHours(diff);
        long days = TimeUnit.MILLISECONDS.toDays(diff);

        if (seconds < 60) {
            return "Just now";
        } else if (minutes < 60) {
            return minutes + "m ago";
        } else if (hours < 24) {
            return hours + "h ago";
        } else if (days < 7) {
            return days + "d ago";
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
            return sdf.format(date);
        }
    }

    // Normal ViewHolder for item_notification.xml
    public static class NormalViewHolder extends RecyclerView.ViewHolder {
        final CardView iconCard;
        final ImageView icon;
        final TextView title, message, timeText;
        final LinearLayout actionButtons;
        final MaterialButton btnAccept, btnDecline;
        final View unreadIndicator;

        public NormalViewHolder(@NonNull View itemView) {
            super(itemView);
            iconCard = itemView.findViewById(R.id.icon_card);
            icon = itemView.findViewById(R.id.notification_icon);
            title = itemView.findViewById(R.id.notification_title);
            message = itemView.findViewById(R.id.notification_message);
            timeText = itemView.findViewById(R.id.time_text);
            actionButtons = itemView.findViewById(R.id.action_buttons_container);
            btnAccept = itemView.findViewById(R.id.btn_accept);
            btnDecline = itemView.findViewById(R.id.btn_decline);
            unreadIndicator = itemView.findViewById(R.id.unread_indicator);
        }
    }

    // Deadline ViewHolder for item_notification_reminder.xml
    public static class DeadlineViewHolder extends RecyclerView.ViewHolder {
        final TextView dueTag, reminderTitle, deadlineText, progressAmount, progressDetails;
        final LinearProgressIndicator progressBar;
        final LinearLayout progressContainer;
        final MaterialButton btnDismiss;

        public DeadlineViewHolder(@NonNull View itemView) {
            super(itemView);
            dueTag = itemView.findViewById(R.id.tv_due_tag);
            reminderTitle = itemView.findViewById(R.id.tv_reminder_title);
            deadlineText = itemView.findViewById(R.id.tv_deadline);
            progressAmount = itemView.findViewById(R.id.tv_progress_amount);
            progressBar = itemView.findViewById(R.id.progress_bar);
            progressDetails = itemView.findViewById(R.id.tv_progress_details);
            progressContainer = itemView.findViewById(R.id.ll_progress_container);
            btnDismiss = itemView.findViewById(R.id.btn_dismiss);
        }
    }
}