package com.example.fintrac;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class InviteDialogFragment extends DialogFragment {

    private final String jarId;
    private final String jarName;

    public InviteDialogFragment(String jarId, String jarName) {
        this.jarId = jarId;
        this.jarName = jarName;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_invite, null);

        // UI Binding
        TextView title = view.findViewById(R.id.dialog_title);
        EditText emailEditText = view.findViewById(R.id.email_edit_text);
        Button sendButton = view.findViewById(R.id.send_button);
        Button shareLinkButton = view.findViewById(R.id.share_link_button);
        ImageButton closeButton = view.findViewById(R.id.btn_close);

        // Close button
        if (closeButton != null) {
            closeButton.setOnClickListener(v -> dismiss());
        }

        // Set title
        if (title != null) {
            title.setText("Invite to " + jarName);
        }

        // Send email invite (your existing functionality)
        sendButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString().trim();
            if (!email.isEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                Toast.makeText(getActivity(), "Invitation sent to " + email, Toast.LENGTH_SHORT).show();
                dismiss();
            } else {
                emailEditText.setError("Enter a valid email");
            }
        });

        // Enhanced Share Link Button
        shareLinkButton.setOnClickListener(v -> {
            shareInviteLink();
        });

        builder.setView(view);
        AlertDialog dialog = builder.create();

        // Make sure dialog can be cancelled
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        return dialog;
    }

    private void shareInviteLink() {
        // Create the invite link
        String inviteLink = "https://fintrac.app/join/" + jarId;

        // Create the share content
        String shareSubject = "Join my FinTrac jar: " + jarName;
        String shareText = String.format(
                "I'm inviting you to join my shared jar '%s' on FinTrac! " +
                        "Click the link below to join:\n\n%s\n\n" +
                        "With FinTrac, you can easily track shared expenses and manage money together.",
                jarName, inviteLink
        );

        // Create share intent
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);

        // Add the link as a URL for better handling by messaging apps
        shareIntent.putExtra(Intent.EXTRA_REFERRER, Uri.parse(inviteLink));

        // Create chooser with custom title
        Intent chooser = Intent.createChooser(shareIntent, "Share invitation via");

        // Add custom flags to ensure it works properly
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

        // Start the share activity
        startActivity(chooser);

        // Show feedback
        Toast.makeText(getActivity(), "Sharing invite link...", Toast.LENGTH_SHORT).show();

        // Dismiss the dialog after sharing
        dismiss();
    }
}