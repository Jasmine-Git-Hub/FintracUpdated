package com.example.fintrac;

import android.content.Context;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class NotificationWorker extends Worker {

    public NotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        // This manually triggers your DeadlineReminderReceiver in the background
        Context context = getApplicationContext();
        Intent intent = new Intent(context, DeadlineReminderReceiver.class);
        context.sendBroadcast(intent);

        return Result.success();
    }
}