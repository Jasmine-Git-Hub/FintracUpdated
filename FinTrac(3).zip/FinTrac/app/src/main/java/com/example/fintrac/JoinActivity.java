package com.example.fintrac;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class JoinActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Handle the incoming deep link
        handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        Uri data = intent.getData();

        if (data != null && data.getPath() != null) {
            // Extract jarId from the URL: https://fintrac.app/join/{jarId}
            String path = data.getPath();
            String jarId = path.replace("/join/", "");

            if (!jarId.isEmpty()) {
                // Process the join request
                processJoinRequest(jarId);
            } else {
                Toast.makeText(this, "Invalid invitation link", Toast.LENGTH_SHORT).show();
                finish();
            }
        } else {
            Toast.makeText(this, "No invitation data found", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    private void processJoinRequest(String jarId) {
        // TODO: Check if user is logged in
        boolean isLoggedIn = checkIfUserIsLoggedIn();

        if (isLoggedIn) {
            // User is logged in, proceed to join the jar
            joinJar(jarId);
        } else {
            // User is not logged in, save the invite and redirect to login
            savePendingInvite(jarId);
            startActivity(new Intent(this, LogIn.class));
            finish();
        }
    }

    private boolean checkIfUserIsLoggedIn() {
        // TODO: Implement your authentication check
        // Return true if user is logged in, false otherwise
        return false; // Placeholder
    }

    private void savePendingInvite(String jarId) {
        // TODO: Save the pending invite to SharedPreferences or database
        // This will be used after login to auto-join the jar
        getSharedPreferences("app_prefs", MODE_PRIVATE)
                .edit()
                .putString("pending_jar_invite", jarId)
                .apply();
    }

    private void joinJar(String jarId) {
        // TODO: Implement the actual join logic
        // For now, just show a message and navigate to the jar
        Toast.makeText(this, "Joining jar: " + jarId, Toast.LENGTH_SHORT).show();

        // Navigate to the jar details or main activity
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("jarId", jarId);
        intent.putExtra("action", "join");
        startActivity(intent);
        finish();
    }
}