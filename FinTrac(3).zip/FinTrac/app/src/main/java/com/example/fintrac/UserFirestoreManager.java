package com.example.fintrac;

import android.util.Log;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UserFirestoreManager {
    private static final String TAG = "UserFirestoreManager";
    private static final String COLLECTION_USERS = "users";

    private final FirebaseFirestore db;
    private final FirebaseAuth mAuth;

    public UserFirestoreManager() {
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
    }

    public interface UserCallback<T> {
        void onSuccess(T result);
        void onFailure(Exception e);
    }

    // Save current user to Firestore
    public void saveCurrentUser(UserCallback<Void> callback) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            callback.onFailure(new Exception("User not authenticated"));
            return;
        }

        Map<String, Object> userMap = new HashMap<>();
        userMap.put("uid", currentUser.getUid());
        userMap.put("email", currentUser.getEmail());
        userMap.put("displayName", currentUser.getDisplayName() != null ?
                currentUser.getDisplayName() :
                currentUser.getEmail().split("@")[0]);
        userMap.put("photoUrl", currentUser.getPhotoUrl() != null ?
                currentUser.getPhotoUrl().toString() : "");

        db.collection(COLLECTION_USERS)
                .document(currentUser.getUid())
                .set(userMap)
                .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                .addOnFailureListener(callback::onFailure);
    }
    // Add this method to save the FCM Token
    public void saveFcmToken(String token) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null && token != null) {
            Map<String, Object> tokenUpdate = new HashMap<>();
            tokenUpdate.put("fcmToken", token);

            db.collection(COLLECTION_USERS)
                    .document(currentUser.getUid())
                    .update(tokenUpdate)
                    .addOnSuccessListener(aVoid -> Log.d(TAG, "FCM Token successfully updated!"))
                    .addOnFailureListener(e -> Log.e(TAG, "Error updating FCM token", e));
        }
    }

    // Get user by email
    public void getUserByEmail(String email, UserCallback<String> callback) {
        db.collection(COLLECTION_USERS)
                .whereEqualTo("email", email)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (!queryDocumentSnapshots.isEmpty()) {
                        String userId = queryDocumentSnapshots.getDocuments().get(0).getId();
                        callback.onSuccess(userId);
                    } else {
                        callback.onFailure(new Exception("User not found"));
                    }
                })
                .addOnFailureListener(callback::onFailure);
    }
}

