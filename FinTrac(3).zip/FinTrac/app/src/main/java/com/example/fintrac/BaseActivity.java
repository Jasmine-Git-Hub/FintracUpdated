package com.example.fintrac;

import android.os.Bundle;
import android.util.Log;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Apply theme before super.onCreate
        SettingHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Apply theme color when activity resumes
        applyThemeToActivity();
    }

    /**
     * Apply theme to the entire activity
     */
    protected void applyThemeToActivity() {
        try {
            int themeColorResId = SettingHelper.getThemeColor(this);
            ThemeColorManager.applyThemeColor(this, themeColorResId);
        } catch (Exception e) {
            Log.e("BaseActivity", "Error applying theme: " + e.getMessage());
        }
    }
}