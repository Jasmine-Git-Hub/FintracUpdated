package com.example.fintrac;

import android.app.Application;
import android.content.Context;

public class FinTracApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Apply saved theme on app start
        SettingHelper.applyTheme(this);
    }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
    }
}