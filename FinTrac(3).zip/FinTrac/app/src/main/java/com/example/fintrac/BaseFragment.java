package com.example.fintrac;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public abstract class BaseFragment extends Fragment {

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        applyThemeColors();
    }

    @Override
    public void onResume() {
        super.onResume();
        applyThemeColors();
    }

    private void applyThemeColors() {
        if (getActivity() != null) {
            SettingHelper.applyThemeColor(getActivity());
        }
    }
}