package com.example.fintrac;

import android.util.Log;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import java.util.HashMap;
import java.util.Map;

public class FirestoreService {

    private final FirebaseFirestore db;
    private CollectionReference billsRef;
    private final String userId;

    public FirestoreService() {
        db = FirebaseFirestore.getInstance();

        // CHECK LOGIN STATUS
        if (FirebaseAuth.getInstance().getCurrentUser() != null) {
            userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
            // Kung naka-login: users -> [USER_ID] -> bills
            billsRef = db.collection("users").document(userId).collection("bills");
            Log.d("FirestoreService", "User Logged In. Saving to: users/" + userId + "/bills");
        } else {
            // Kung GUEST: bills (sa labas/root)
            userId = "guest";
            billsRef = db.collection("bills");
            Log.d("FirestoreService", "User NOT Logged In. Saving to: bills (root)");
        }
    }

    public Task<DocumentReference> addBill(Bill bill) {
        // Log bago i-save
        Log.d("FirestoreService", "Attempting to add bill: " + bill.name);

        return billsRef.add(bill)
                .addOnSuccessListener(docRef -> {
                    Log.d("FirestoreService", "SUCCESS! Bill added with ID: " + docRef.getId());
                })
                .addOnFailureListener(e -> {
                    Log.e("FirestoreService", "FAILED to add bill", e);
                });
    }

    public Task<QuerySnapshot> getAllBills() {
        return billsRef.get();
    }

    public Task<Void> updateBill(String id, Bill bill) {
        return billsRef.document(id).set(bill);
    }

    public Task<Void> updateBillPaidStatus(String id, boolean isPaid) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("isPaid", isPaid);
        return billsRef.document(id).update(updates);
    }

    public Task<Void> deleteBill(String id) {
        return billsRef.document(id).delete();
    }

    // NEW METHOD: Archives the bill when marked as paid
    public Task<Void> archiveBill(String id) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("isPaid", true);
        updates.put("isArchived", true);
        updates.put("archivedAt", FieldValue.serverTimestamp());

        Log.d("FirestoreService", "Archiving bill ID: " + id);
        return billsRef.document(id).update(updates);
    }
}