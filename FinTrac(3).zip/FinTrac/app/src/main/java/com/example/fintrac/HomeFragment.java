package com.example.fintrac;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class HomeFragment extends Fragment {

    // --- VARIABLES ---
    private double currentBalance = 0.00;
    private double totalInJars = 0.00;
    private final List<Transaction> transactionList = new ArrayList<>();
    private TransactionAdapter adapter;

    // Chart Variables
    private BarChart barChart;
    private float[] weeklyExpenses;

    // UI Elements
    private TextView tvTotalBalance, tvSpendable, tvNoTransactions;
    private TextView welcomeText, usernameText;
    private TextView tvInJarsAmount, tvUnpaidBillsAmount, tvInJarsSubtitle, tvUnpaidBillsSubtitle;
    private CardView profileCard;
    private ImageView profileImage;
    private RecyclerView recyclerView;
    private MaterialButton btnSeeMoreActivity;

    private boolean isRecentActivityExpanded = false;

    // Unpaid Bills Elements
    private final List<Bill> unpaidBillsList = new ArrayList<>();
    private double totalUnpaidBillsValue = 0.0;
    private LinearLayout unpaidBillsContainer;
    private TextView tvNoUnpaidBills;

    // Notification variables
    private MaterialCardView notificationBellCard;
    private ImageView notificationBell;
    private TextView notificationBadge;
    private final List<NotificationItem> notificationList = new ArrayList<>();
    private BottomSheetDialog notificationDialog;
    private ListenerRegistration notificationListener;

    private boolean isExpenseType = true;

    private FirebaseAuth mAuth;
    private FirestoreHelper firestoreHelper;
    private FirebaseFirestore db;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        SettingHelper.applyTheme(requireActivity());
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }

        weeklyExpenses = new float[]{0f, 0f, 0f, 0f, 0f, 0f, 0f};

        if (savedInstanceState != null) {
            isRecentActivityExpanded = savedInstanceState.getBoolean("isRecentActivityExpanded", false);
            float[] savedExpenses = savedInstanceState.getFloatArray("weeklyExpenses");
            if (savedExpenses != null) {
                System.arraycopy(savedExpenses, 0, weeklyExpenses, 0,
                        Math.min(weeklyExpenses.length, savedExpenses.length));
            }
        }

        mAuth = FirebaseAuth.getInstance();
        firestoreHelper = FirestoreHelper.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }

        SettingHelper.updateRatesIfNecessary(requireContext());

        // Initialize all views
        tvTotalBalance = view.findViewById(R.id.total_balance_amount);
        tvSpendable = view.findViewById(R.id.spendable_amount);
        tvNoTransactions = view.findViewById(R.id.no_transactions_text);
        recyclerView = view.findViewById(R.id.transactions_recycler_view);
        btnSeeMoreActivity = view.findViewById(R.id.btn_see_more_activity);
        welcomeText = view.findViewById(R.id.welcome_text);
        usernameText = view.findViewById(R.id.username_text);
        tvInJarsAmount = view.findViewById(R.id.in_jars_amount);
        tvUnpaidBillsAmount = view.findViewById(R.id.unpaid_bills_amount);
        tvInJarsSubtitle = view.findViewById(R.id.in_jars_subtitle);
        tvUnpaidBillsSubtitle = view.findViewById(R.id.unpaid_bills_subtitle);

        unpaidBillsContainer = view.findViewById(R.id.unpaid_bills_container);
        tvNoUnpaidBills = view.findViewById(R.id.tv_no_unpaid_bills);

        profileCard = view.findViewById(R.id.profile_card);
        profileImage = view.findViewById(R.id.profile_image);

        FloatingActionButton addTransactionFab = view.findViewById(R.id.add_transaction_fab);
        barChart = view.findViewById(R.id.weeklySpendingChart);

        initNotificationBell(view);
        displayCurrentUserInfo();

        adapter = new TransactionAdapter(transactionList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        if (btnSeeMoreActivity != null) {
            btnSeeMoreActivity.setOnClickListener(v -> {
                isRecentActivityExpanded = !isRecentActivityExpanded;
                btnSeeMoreActivity.setText(isRecentActivityExpanded ? "See less" : "See more");
                loadTransactions(isRecentActivityExpanded ? 50 : 5);
            });
        }

        setupWeeklyChart();
        addTransactionFab.setOnClickListener(v -> showNewTransactionDialog());
        setupProfileCard();

        startBackgroundNotificationService();
    }

    private void startBackgroundNotificationService() {
        PeriodicWorkRequest notificationWork = new PeriodicWorkRequest.Builder(
                NotificationWorker.class, 12, TimeUnit.HOURS)
                .build();

        WorkManager.getInstance(requireContext()).enqueueUniquePeriodicWork(
                "DeadlineReminders",
                ExistingPeriodicWorkPolicy.KEEP,
                notificationWork
        );
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
            applyThemeColor();
        }
        displayCurrentUserInfo();
        loadUserProfileData();

        loadUserData();
        loadUnpaidBills();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean("isRecentActivityExpanded", isRecentActivityExpanded);
        outState.putFloatArray("weeklyExpenses", weeklyExpenses);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (notificationListener != null) {
            notificationListener.remove();
        }
        // Removed barChart = null; to prevent disappearing charts on fragment transition
    }

    private void applyThemeColor() {
        if (getActivity() == null) return;
        android.content.SharedPreferences prefs = requireActivity().getSharedPreferences("FinTracPrefs", Context.MODE_PRIVATE);
        String currentTheme = prefs.getString("selected_theme", "Ocean Blue");
        int themeColorResId = ThemeColorManager.getThemeColorResId(requireContext(), currentTheme);
        ThemeColorManager.applyThemeColor(requireActivity(), themeColorResId);
    }

    private void loadUserData() {
        loadTransactions(isRecentActivityExpanded ? 50 : 5);
        loadBalance();
        loadWeeklyExpenses();
    }

    private void loadTransactions(int limit) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        firestoreHelper.getRecentTransactions(limit, new FirestoreHelper.OnTransactionsLoadedListener() {
            @Override
            public void onSuccess(List<Transaction> transactions) {
                if (isAdded() && getContext() != null) {
                    transactionList.clear();
                    transactionList.addAll(transactions);
                    adapter.notifyDataSetChanged();
                    updateDashboardDisplay();
                }
            }

            @Override
            public void onFailure(String error) {
                if (isAdded() && getContext() != null) {
                    Log.e("HomeFragment", "Transactions load failed: " + error);
                    updateDashboardDisplay();
                }
            }
        });
    }

    private void loadBalance() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("users")
                .document(currentUser.getUid())
                .collection("transactions")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double totalIncome = 0.0;
                    double totalExpense = 0.0;

                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        double amount = 0.0;
                        Object amountObj = doc.get("amount");
                        if (amountObj instanceof Number) {
                            amount = ((Number) amountObj).doubleValue();
                        } else if (amountObj instanceof String) {
                            try {
                                String cleanAmount = ((String) amountObj).replaceAll("[^\\d.]", "");
                                if (!cleanAmount.isEmpty()) {
                                    amount = Double.parseDouble(cleanAmount);
                                }
                            } catch (NumberFormatException e) {
                                continue;
                            }
                        }

                        boolean isExpense = false;
                        if (doc.contains("isExpense")) {
                            Boolean val = doc.getBoolean("isExpense");
                            isExpense = (val != null) ? val : false;
                        } else if (doc.contains("expense")) {
                            Boolean val = doc.getBoolean("expense");
                            isExpense = (val != null) ? val : false;
                        }

                        if (isExpense) {
                            totalExpense += amount;
                        } else {
                            totalIncome += amount;
                        }
                    }

                    if (isAdded() && getContext() != null) {
                        currentBalance = totalIncome;
                        double spendableAmount = Math.max(0, totalIncome - totalExpense);

                        tvTotalBalance.setText(SettingHelper.formatAmount(requireContext(), currentBalance));
                        tvSpendable.setText(SettingHelper.formatAmount(requireContext(), spendableAmount));

                        loadTotalInJars();
                    }
                });
    }

    private void loadWeeklyExpenses() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        firestoreHelper.getWeeklyExpenses(new FirestoreHelper.OnWeeklyExpensesLoadedListener() {
            @Override
            public void onSuccess(float[] expenses) {
                // Check if view is still valid before touching UI
                if (isAdded() && getView() != null) {
                    if (expenses != null) {
                        System.arraycopy(expenses, 0, weeklyExpenses, 0,
                                Math.min(weeklyExpenses.length, expenses.length));
                    }
                    if (barChart != null) {
                        // Use post to ensure UI updates happen reliably on the main thread
                        barChart.post(() -> {
                            setupWeeklyChart();
                            barChart.setVisibility(View.VISIBLE);
                            barChart.animateY(600); // Forces redraw and adds nice animation
                        });
                    }
                }
            }

            @Override
            public void onFailure(String error) {
                if (isAdded() && getView() != null && barChart != null) {
                    barChart.post(() -> setupWeeklyChart());
                }
            }
        });
    }

    private void loadTotalInJars() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || !isAdded()) return;

        FirebaseFirestore.getInstance()
                .collection("jars")
                .whereArrayContains("participants", currentUser.getUid())
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double jarsTotal = 0.0;
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Double savedAmount = doc.getDouble("savedAmount");
                        if (savedAmount != null) {
                            jarsTotal += savedAmount;
                        }
                    }
                    totalInJars = jarsTotal;

                    if (isAdded() && getContext() != null) {
                        tvInJarsAmount.setText(SettingHelper.formatAmount(requireContext(), totalInJars));
                        updateBalanceDisplay();
                    }
                })
                .addOnFailureListener(e -> loadTotalInJarsFromSubcollection());
    }

    private void loadTotalInJarsFromSubcollection() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || !isAdded()) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("jars")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double jarsTotal = 0.0;
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Double savedAmount = doc.getDouble("savedAmount");
                        if (savedAmount != null) {
                            jarsTotal += savedAmount;
                        }
                    }
                    totalInJars = jarsTotal;

                    if (isAdded() && getContext() != null) {
                        tvInJarsAmount.setText(SettingHelper.formatAmount(requireContext(), totalInJars));
                        updateBalanceDisplay();
                    }
                })
                .addOnFailureListener(e -> {
                    totalInJars = 0.0;
                    if (isAdded() && getContext() != null) {
                        tvInJarsAmount.setText(SettingHelper.formatAmount(requireContext(), 0));
                        updateBalanceDisplay();
                    }
                });
    }

    private void updateBalanceDisplay() {
        if (getContext() != null) {
            if (currentBalance > 0) {
                double percentage = (totalInJars / currentBalance) * 100;
                tvInJarsSubtitle.setText(String.format(Locale.getDefault(),
                        "%.1f%% of total balance", percentage));
            } else {
                tvInJarsSubtitle.setText("0% of total balance");
            }
        }
    }

    private void loadUserProfileData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        FirebaseFirestore.getInstance().collection("users").document(currentUser.getUid())
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot != null && documentSnapshot.exists() && isAdded()) {
                        String fullName = documentSnapshot.getString("fullName");
                        if (fullName != null && !fullName.isEmpty() && usernameText != null) {
                            usernameText.setText(fullName);
                        }

                        if (profileImage != null) {
                            String savedAvatar = documentSnapshot.getString("profileAvatar");
                            String savedUri = documentSnapshot.getString("profileImageLocalUri");

                            if (savedUri != null && !savedUri.isEmpty()) {
                                profileImage.setImageDrawable(null);
                                profileImage.setPadding(0, 0, 0, 0);
                                profileImage.setImageTintList(null);
                                profileImage.setImageURI(Uri.parse(savedUri));
                            } else if (savedAvatar != null) {
                                profileImage.setImageDrawable(null);
                                profileImage.setPadding(0, 0, 0, 0);
                                profileImage.setImageTintList(null);
                                int resId = getResources().getIdentifier(savedAvatar, "drawable", requireContext().getPackageName());
                                if (resId != 0) {
                                    profileImage.setImageResource(resId);
                                }
                            }
                        }
                    }
                });
    }

    private void loadUnpaidBills() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("users")
                .document(currentUser.getUid())
                .collection("bills")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (isAdded() && getContext() != null) {
                        unpaidBillsList.clear();
                        double unpaidSum = 0.0;

                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            Boolean isPaid = doc.getBoolean("isPaid");
                            boolean isPaidValue = (isPaid != null) ? isPaid : false;

                            String amountStr = doc.getString("amount");
                            double amount = 0.0;
                            if (amountStr != null) {
                                try {
                                    String cleanAmount = amountStr.replaceAll("[^\\d.]", "");
                                    if (!cleanAmount.isEmpty()) {
                                        amount = Double.parseDouble(cleanAmount);
                                    }
                                } catch (NumberFormatException e) {
                                    Log.e("HomeFragment", "Error parsing amount", e);
                                }
                            }

                            if (!isPaidValue) {
                                unpaidSum += amount;

                                Long logoResIdLong = doc.getLong("logoResId");
                                int logoResId = (logoResIdLong != null) ? logoResIdLong.intValue() : R.drawable.ic_visual_reports;

                                Bill bill = new Bill(
                                        doc.getId(),
                                        doc.getString("name"),
                                        doc.getString("category"),
                                        doc.getString("frequency"),
                                        amountStr,
                                        doc.getString("dueDate"),
                                        logoResId,
                                        false
                                );
                                unpaidBillsList.add(bill);
                            }
                        }

                        totalUnpaidBillsValue = unpaidSum;

                        updateUnpaidBillsTotal();
                        displayUnpaidBills();
                    }
                });
    }

    private void displayUnpaidBills() {
        if (!isAdded() || getView() == null) return;

        for (int i = unpaidBillsContainer.getChildCount() - 1; i >= 0; i--) {
            View child = unpaidBillsContainer.getChildAt(i);
            if (child.getId() != R.id.tv_unpaid_bills_title &&
                    child.getId() != R.id.tv_no_unpaid_bills) {
                unpaidBillsContainer.removeView(child);
            }
        }

        if (unpaidBillsList.isEmpty()) {
            tvNoUnpaidBills.setVisibility(View.VISIBLE);
        } else {
            tvNoUnpaidBills.setVisibility(View.GONE);

            List<Bill> sortedBills = new ArrayList<>(unpaidBillsList);
            sortedBills.sort((b1, b2) -> {
                SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
                try {
                    String dateStr1 = b1.dueDate != null ? b1.dueDate.replace("Due: ", "").trim() : "";
                    String dateStr2 = b2.dueDate != null ? b2.dueDate.replace("Due: ", "").trim() : "";

                    Date date1 = sdf.parse(dateStr1);
                    Date date2 = sdf.parse(dateStr2);
                    if (date1 != null && date2 != null) {
                        return date1.compareTo(date2);
                    }
                } catch (Exception e) {
                    Log.e("HomeFragment", "Date parsing error", e);
                }
                return 0;
            });

            int count = Math.min(sortedBills.size(), 5);
            for (int i = 0; i < count; i++) {
                Bill bill = sortedBills.get(i);
                View billView = LayoutInflater.from(getContext())
                        .inflate(R.layout.item_upcoming_bill, unpaidBillsContainer, false);

                TextView tvName = billView.findViewById(R.id.tv_bill_name);
                TextView tvAmount = billView.findViewById(R.id.tv_bill_amount);
                TextView tvDueDate = billView.findViewById(R.id.tv_due_date);
                ImageView ivIcon = billView.findViewById(R.id.iv_bill_icon);
                MaterialCardView iconCard = billView.findViewById(R.id.icon_card);

                tvName.setText(bill.name != null ? bill.name : "Unnamed Bill");
                tvAmount.setText(bill.amount != null ? bill.amount : "₱0.00");

                String dueText = calculateDueText(bill.dueDate);
                tvDueDate.setText(dueText);

                if (dueText.contains("Today")) {
                    tvDueDate.setTextColor(ContextCompat.getColor(requireContext(), R.color.dashboard_red));
                    if (iconCard != null) {
                        iconCard.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.dashboard_red_light));
                    }
                } else if (dueText.contains("Tomorrow")) {
                    tvDueDate.setTextColor(ContextCompat.getColor(requireContext(), R.color.jar_color_orange));
                    if (iconCard != null) {
                        iconCard.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.warning_bg));
                    }
                }

                ivIcon.setImageResource(bill.logoResId != 0 ? bill.logoResId : R.drawable.ic_visual_reports);

                billView.setOnClickListener(v -> showBillOptionsDialog(bill));
                unpaidBillsContainer.addView(billView);
            }

            if (sortedBills.size() > 5) {
                MaterialButton btnViewAll = new MaterialButton(requireContext());
                btnViewAll.setText("View All Bills (" + sortedBills.size() + ")");
                btnViewAll.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
                btnViewAll.setTextColor(ContextCompat.getColor(requireContext(), R.color.dashboard_blue));
                btnViewAll.setStrokeColor(ColorStateList.valueOf(ContextCompat.getColor(requireContext(), R.color.dashboard_blue)));
                btnViewAll.setStrokeWidth(1);
                btnViewAll.setCornerRadius(12);
                btnViewAll.setLayoutParams(new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT));

                int marginTop = (int) (16 * getResources().getDisplayMetrics().density);
                int marginHorizontal = (int) (16 * getResources().getDisplayMetrics().density);
                ((LinearLayout.LayoutParams) btnViewAll.getLayoutParams()).setMargins(
                        marginHorizontal, marginTop, marginHorizontal, 0);

                btnViewAll.setOnClickListener(v -> {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_bills);
                    }
                });

                unpaidBillsContainer.addView(btnViewAll);
            }
        }
    }

    private String calculateDueText(String dueDateStr) {
        if (dueDateStr == null || dueDateStr.isEmpty()) return "Due date unknown";

        try {
            String cleanDate = dueDateStr.replace("Due: ", "").trim();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            Date dueDate = sdf.parse(cleanDate);
            if (dueDate == null) return dueDateStr;

            Calendar dueCal = Calendar.getInstance();
            dueCal.setTime(dueDate);
            dueCal.set(Calendar.HOUR_OF_DAY, 0);
            dueCal.set(Calendar.MINUTE, 0);
            dueCal.set(Calendar.SECOND, 0);
            dueCal.set(Calendar.MILLISECOND, 0);

            Calendar today = Calendar.getInstance();
            today.set(Calendar.HOUR_OF_DAY, 0);
            today.set(Calendar.MINUTE, 0);
            today.set(Calendar.SECOND, 0);
            today.set(Calendar.MILLISECOND, 0);

            long diffInMillis = dueCal.getTimeInMillis() - today.getTimeInMillis();
            long daysLeft = TimeUnit.MILLISECONDS.toDays(diffInMillis);

            if (daysLeft < 0) return "Overdue!";
            if (daysLeft == 0) return "Due Today!";
            if (daysLeft == 1) return "Due Tomorrow";
            if (daysLeft <= 7) return "Due in " + daysLeft + " days";

            SimpleDateFormat outputFormat = new SimpleDateFormat("MMM dd", Locale.getDefault());
            return "Due " + outputFormat.format(dueDate);
        } catch (Exception e) {
            return dueDateStr;
        }
    }

    private void showBillOptionsDialog(Bill bill) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(bill.name != null ? bill.name : "Bill Details")
                .setMessage("Amount: " + (bill.amount != null ? bill.amount : "₱0.00") +
                        "\nDue Date: " + (bill.dueDate != null ? bill.dueDate : "Unknown") +
                        "\nCategory: " + (bill.category != null ? bill.category : "Uncategorized") +
                        "\nFrequency: " + (bill.frequency != null ? bill.frequency : "One-time"))
                .setPositiveButton("Mark as Paid", (dialog, which) -> markBillAsPaid(bill))
                .setNegativeButton("View Details", (dialog, which) -> {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_bills);
                    }
                })
                .setNeutralButton("Close", null)
                .show();
    }

    private void markBillAsPaid(Bill bill) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || bill.id == null) return;

        db.collection("users")
                .document(currentUser.getUid())
                .collection("bills")
                .document(bill.id)
                .update("isPaid", true)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Bill marked as paid", Toast.LENGTH_SHORT).show();
                    loadUnpaidBills();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to update bill", Toast.LENGTH_SHORT).show());
    }

    private void updateUnpaidBillsTotal() {
        if (tvUnpaidBillsAmount == null || tvUnpaidBillsSubtitle == null || getContext() == null) return;

        String formattedTotal = SettingHelper.formatAmount(requireContext(), totalUnpaidBillsValue);
        tvUnpaidBillsAmount.setText(formattedTotal);

        int count = unpaidBillsList.size();
        if (count == 0) {
            tvUnpaidBillsSubtitle.setText(R.string.no_pending_bills);
        } else if (count == 1) {
            tvUnpaidBillsSubtitle.setText(R.string.one_pending_bill);
        } else {
            tvUnpaidBillsSubtitle.setText(getString(R.string.pending_bills_count, count));
        }
    }

    private void displayCurrentUserInfo() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String displayName = currentUser.getDisplayName();
            String email = currentUser.getEmail();

            if (displayName != null && !displayName.isEmpty()) {
                usernameText.setText(displayName);
                welcomeText.setText(R.string.welcome_back);
            } else {
                usernameText.setText(email != null ? email : getString(R.string.user));
                welcomeText.setText(R.string.welcome);
            }
        } else {
            usernameText.setText(R.string.guest);
            welcomeText.setText(R.string.welcome);
        }
    }

    private void setupProfileCard() {
        if (profileCard != null) {
            profileCard.setOnClickListener(v -> showProfileOptionsDialog());
        }
    }

    private void showProfileOptionsDialog() {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());
        View view = getLayoutInflater().inflate(R.layout.dialog_profile_menu, null, false);
        dialog.setContentView(view);

        View bottomSheet = (View) view.getParent();
        if (bottomSheet != null) {
            bottomSheet.setBackgroundColor(Color.TRANSPARENT);
        }

        TextView btnEditProfile = view.findViewById(R.id.btnMenuEditProfile);
        TextView btnLogout = view.findViewById(R.id.btnMenuLogout);
        TextView btnCancel = view.findViewById(R.id.btnMenuCancel);

        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                dialog.dismiss();
                startActivity(new Intent(getActivity(), EditProfileActivity.class));
            });
        }

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                dialog.dismiss();
                showLogoutConfirmationDialog();
            });
        }

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    private void showLogoutConfirmationDialog() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.logout)
                .setMessage(R.string.logout_confirmation)
                .setPositiveButton(R.string.yes, (dialog, which) -> logoutUser())
                .setNegativeButton(R.string.cancel, (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void logoutUser() {
        mAuth.signOut();
        redirectToLogin();
    }

    private void redirectToLogin() {
        if (getActivity() != null) {
            Intent intent = new Intent(getActivity(), LogIn.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            getActivity().finish();
        }
    }

    private void setupWeeklyChart() {
        if (barChart == null || getContext() == null || !isAdded()) return;

        try {
            ArrayList<BarEntry> entries = new ArrayList<>();
            double rate = SettingHelper.getExchangeRate(requireContext(), SettingHelper.getCurrency(requireContext()));

            for (int i = 0; i < weeklyExpenses.length; i++) {
                float value = (float) (weeklyExpenses[i] * rate);
                entries.add(new BarEntry(i, value));
            }

            BarDataSet dataSet = new BarDataSet(entries, getString(R.string.weekly_spending));

            Context context = requireContext();
            dataSet.setColor(SettingHelper.isDarkMode(context) ?
                    Color.parseColor("#64B5F6") : Color.parseColor("#2196F3"));
            dataSet.setValueTextColor(Color.BLACK);
            dataSet.setValueTextSize(10f);
            dataSet.setDrawValues(false);

            BarData barData = new BarData(dataSet);
            barData.setBarWidth(0.5f);

            // Important: removed barChart.clear() to prevent lifecycle view glitches
            barChart.setData(barData);

            barChart.getDescription().setEnabled(false);
            barChart.getLegend().setEnabled(false);
            barChart.setDrawGridBackground(false);
            barChart.getAxisRight().setEnabled(false);
            barChart.getAxisLeft().setDrawGridLines(true);
            barChart.getAxisLeft().setAxisMinimum(0f);
            barChart.getAxisLeft().setSpaceTop(15f);
            barChart.setFitBars(true);
            barChart.setPinchZoom(false);
            barChart.setScaleEnabled(false);
            barChart.setDoubleTapToZoomEnabled(false);
            barChart.setExtraOffsets(5, 10, 5, 15);

            int textColor = SettingHelper.isDarkMode(context) ? Color.WHITE : Color.BLACK;
            barChart.getXAxis().setTextColor(textColor);
            barChart.getAxisLeft().setTextColor(textColor);

            String[] days = {
                    getString(R.string.mon), getString(R.string.tue),
                    getString(R.string.wed), getString(R.string.thu),
                    getString(R.string.fri), getString(R.string.sat),
                    getString(R.string.sun)
            };

            XAxis xAxis = barChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
            xAxis.setGranularity(1f);
            xAxis.setGranularityEnabled(true);
            xAxis.setDrawGridLines(false);
            xAxis.setLabelCount(7, false);
            xAxis.setAxisMinimum(-0.5f);
            xAxis.setAxisMaximum(6.5f);

            barChart.notifyDataSetChanged();
            barChart.invalidate();
            barChart.requestLayout(); // Force re-measuring for returning from other fragments

        } catch (Exception e) {
            Log.e("HomeFragment", "Error setting up chart", e);
        }
    }

    private void updateDashboardDisplay() {
        if (transactionList.isEmpty()) {
            tvNoTransactions.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
            if (btnSeeMoreActivity != null) btnSeeMoreActivity.setVisibility(View.GONE);
        } else {
            tvNoTransactions.setVisibility(View.GONE);
            if (btnSeeMoreActivity != null) {
                btnSeeMoreActivity.setVisibility(View.VISIBLE);
            }
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void updateWeeklyExpenses(float amount) {
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int index;

        switch (dayOfWeek) {
            case Calendar.MONDAY:    index = 0; break;
            case Calendar.TUESDAY:   index = 1; break;
            case Calendar.WEDNESDAY: index = 2; break;
            case Calendar.THURSDAY:  index = 3; break;
            case Calendar.FRIDAY:    index = 4; break;
            case Calendar.SATURDAY:  index = 5; break;
            case Calendar.SUNDAY:    index = 6; break;
            default: index = 0;
        }
        weeklyExpenses[index] += amount;
        setupWeeklyChart();
    }

    private void showNewTransactionDialog() {
        Context context = requireContext();
        MaterialAlertDialogBuilder builder = new MaterialAlertDialogBuilder(context);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_new_transaction, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        SettingHelper.applyTheme(dialog.getContext());

        ImageButton btnClose = dialogView.findViewById(R.id.btn_close);
        MaterialButton btnExpense = dialogView.findViewById(R.id.btn_type_expense);
        MaterialButton btnIncome = dialogView.findViewById(R.id.btn_type_income);
        MaterialButton btnSave = dialogView.findViewById(R.id.btn_save_transaction);
        TextInputLayout tilCategory = dialogView.findViewById(R.id.til_category);
        TextView tvCategoryLabel = dialogView.findViewById(R.id.tv_category_label);
        TextInputEditText etAmount = dialogView.findViewById(R.id.et_amount);
        TextInputEditText etDesc = dialogView.findViewById(R.id.et_desc);
        AutoCompleteTextView actCategory = dialogView.findViewById(R.id.act_category);

        int colorRed, colorGreen, colorGray, colorTextGray;

        if (SettingHelper.isDarkMode(context)) {
            colorRed = Color.parseColor("#EF9A9A");
            colorGreen = Color.parseColor("#81C784");
            colorGray = Color.parseColor("#424242");
            colorTextGray = Color.parseColor("#B0B0B0");
        } else {
            colorRed = ContextCompat.getColor(context, R.color.jar_color_red);
            colorGreen = ContextCompat.getColor(context, R.color.green);
            colorGray = ContextCompat.getColor(context, R.color.light_gray);
            colorTextGray = ContextCompat.getColor(context, R.color.gray);
        }

        String[] categories = {getString(R.string.food), getString(R.string.transportation),
                getString(R.string.bills), getString(R.string.shopping),
                getString(R.string.entertainment), getString(R.string.health),
                getString(R.string.education), getString(R.string.other)};
        ArrayAdapter<String> adapterCat = new ArrayAdapter<>(context,
                android.R.layout.simple_dropdown_item_1line, categories);
        actCategory.setAdapter(adapterCat);
        actCategory.setText(categories[0], false);

        Runnable updateUI = () -> {
            if (isExpenseType) {
                btnExpense.setStrokeColor(ColorStateList.valueOf(colorRed));
                btnExpense.setTextColor(colorRed);
                btnIncome.setStrokeColor(ColorStateList.valueOf(colorGray));
                btnIncome.setTextColor(colorTextGray);

                if (tilCategory != null) tilCategory.setVisibility(View.VISIBLE);
                if (tvCategoryLabel != null) tvCategoryLabel.setVisibility(View.VISIBLE);

                btnSave.setText(R.string.add_expense);
                btnSave.setBackgroundTintList(ColorStateList.valueOf(colorRed));
            } else {
                btnIncome.setStrokeColor(ColorStateList.valueOf(colorGreen));
                btnIncome.setTextColor(colorGreen);
                btnExpense.setStrokeColor(ColorStateList.valueOf(colorGray));
                btnExpense.setTextColor(colorTextGray);

                if (tilCategory != null) tilCategory.setVisibility(View.GONE);
                if (tvCategoryLabel != null) tvCategoryLabel.setVisibility(View.GONE);

                btnSave.setText(R.string.add_income);
                btnSave.setBackgroundTintList(ColorStateList.valueOf(colorGreen));
            }
        };

        isExpenseType = true;
        updateUI.run();

        btnExpense.setOnClickListener(v -> {
            isExpenseType = true;
            updateUI.run();
        });
        btnIncome.setOnClickListener(v -> {
            isExpenseType = false;
            updateUI.run();
        });
        btnClose.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String amountStr = Objects.requireNonNull(etAmount.getText()).toString().trim();
            if (amountStr.isEmpty()) {
                Toast.makeText(context, R.string.enter_amount, Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double uiAmount = Double.parseDouble(amountStr);
                double amountInPHP = SettingHelper.convertToBasePHP(context, uiAmount);

                String desc = Objects.requireNonNull(etDesc.getText()).toString().trim();
                String category = Objects.requireNonNull(actCategory.getText()).toString().trim();

                if (desc.isEmpty()) {
                    Toast.makeText(context, "Please enter a description", Toast.LENGTH_SHORT).show();
                    etDesc.setError("Required field");
                    etDesc.requestFocus();
                    return;
                }

                if (isExpenseType && category.isEmpty()) {
                    Toast.makeText(context, R.string.select_category, Toast.LENGTH_SHORT).show();
                    return;
                }

                FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser == null) {
                    Toast.makeText(context, R.string.user_not_authenticated, Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    redirectToLogin();
                    return;
                }

                String title = isExpenseType ?
                        (category.isEmpty() ? getString(R.string.expense) : category) :
                        (desc.isEmpty() ? getString(R.string.income) : desc);

                Transaction transaction = new Transaction(
                        title, desc, category, amountInPHP, isExpenseType, currentUser.getUid()
                );

                btnSave.setEnabled(false);
                btnSave.setText(R.string.saving);

                firestoreHelper.addTransaction(transaction, new FirestoreHelper.OnTransactionAddedListener() {
                    @Override
                    public void onSuccess(Transaction savedTransaction) {
                        if (isAdded() && getContext() != null) {
                            transactionList.add(0, savedTransaction);
                            adapter.notifyItemInserted(0);
                            recyclerView.smoothScrollToPosition(0);

                            if (isExpenseType) {
                                updateWeeklyExpenses((float) amountInPHP);
                            }

                            loadBalance();
                            updateDashboardDisplay();
                            Toast.makeText(context, R.string.transaction_saved, Toast.LENGTH_SHORT).show();
                            btnSave.setEnabled(true);
                            dialog.dismiss();
                        }
                    }

                    @Override
                    public void onFailure(String error) {
                        if (isAdded() && getContext() != null) {
                            Toast.makeText(context, getString(R.string.save_failed) + error, Toast.LENGTH_LONG).show();
                            btnSave.setEnabled(true);
                            btnSave.setText(isExpenseType ? R.string.add_expense : R.string.add_income);
                        }
                    }
                });

            } catch (NumberFormatException e) {
                Toast.makeText(context, R.string.invalid_amount, Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void initNotificationBell(View view) {
        notificationBellCard = view.findViewById(R.id.notification_bell_card);
        notificationBell = view.findViewById(R.id.notification_bell);
        notificationBadge = view.findViewById(R.id.notification_badge);

        notificationBellCard.setOnClickListener(v -> showNotificationsDialog());
        setupNotificationListener();
        checkPendingInvitations();
    }

    private void setupNotificationListener() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        notificationListener = FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("HomeFragment", "Error listening to notifications", error);
                        return;
                    }

                    if (value != null) {
                        notificationList.clear();
                        int unreadCount = 0;

                        for (DocumentSnapshot doc : value.getDocuments()) {
                            NotificationItem notification = doc.toObject(NotificationItem.class);
                            if (notification != null) {
                                notification.setId(doc.getId());
                                notificationList.add(notification);
                                if (!notification.isRead()) {
                                    unreadCount++;
                                }
                            }
                        }

                        updateNotificationBadge(unreadCount);

                        if (notificationDialog != null && notificationDialog.isShowing()) {
                            NotificationAdapter adapter = (NotificationAdapter)
                                    ((RecyclerView) notificationDialog.findViewById(R.id.notifications_recycler_view))
                                            .getAdapter();
                            if (adapter != null) {
                                adapter.notifyDataSetChanged();
                            }
                            updateNotificationsDialogVisibility();
                        }
                    }
                });
    }

    private void updateNotificationBadge(int unreadCount) {
        if (notificationBadge != null) {
            notificationBadge.setVisibility(unreadCount > 0 ? View.VISIBLE : View.GONE);
            if (unreadCount > 0) {
                notificationBadge.setText(String.valueOf(unreadCount));
            }
        }
    }

    private void checkPendingInvitations() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .whereEqualTo("type", "JAR_INVITE")
                .whereEqualTo("isRead", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.size() > 0) {
                        animateNotificationBell();
                    }
                });
    }

    private void animateNotificationBell() {
        if (notificationBell != null) {
            notificationBell.animate()
                    .rotation(10f)
                    .setDuration(100)
                    .withEndAction(() -> notificationBell.animate()
                            .rotation(-10f)
                            .setDuration(100)
                            .withEndAction(() -> notificationBell.animate()
                                    .rotation(0f)
                                    .setDuration(100)))
                    .start();
        }
    }

    private void showNotificationsDialog() {
        if (getContext() == null) return;

        notificationDialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_notifications, null);
        notificationDialog.setContentView(dialogView);

        RecyclerView recyclerView = dialogView.findViewById(R.id.notifications_recycler_view);
        TextView noNotificationsText = dialogView.findViewById(R.id.no_notifications_text);
        TextView markAllRead = dialogView.findViewById(R.id.mark_all_read);

        NotificationAdapter notificationAdapter = new NotificationAdapter(requireContext(), notificationList,
                new NotificationAdapter.OnNotificationActionListener() {
                    @Override
                    public void onAcceptInvite(NotificationItem notification) {
                        acceptJarInvite(notification);
                    }

                    @Override
                    public void onDeclineInvite(NotificationItem notification) {
                        declineJarInvite(notification);
                    }

                    @Override
                    public void onNotificationClick(NotificationItem notification) {
                        markNotificationAsRead(notification);
                        handleNotificationClick(notification);
                    }

                    @Override
                    public void onDismissReminder(NotificationItem notification) {
                        dismissReminder(notification);
                    }
                });

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(notificationAdapter);

        markAllRead.setOnClickListener(v -> markAllNotificationsAsRead());

        updateNotificationsDialogVisibility();

        notificationDialog.setOnDismissListener(dialog -> notificationDialog = null);

        notificationDialog.setOnShowListener(dialogInterface -> {
            BottomSheetDialog bottomSheetDialog = (BottomSheetDialog) dialogInterface;
            View bottomSheet = bottomSheetDialog.findViewById(com.google.android.material.R.id.design_bottom_sheet);
            if (bottomSheet != null) {
                android.util.DisplayMetrics displayMetrics = new android.util.DisplayMetrics();
                requireActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                int screenHeight = displayMetrics.heightPixels;

                ViewGroup.LayoutParams layoutParams = bottomSheet.getLayoutParams();
                layoutParams.height = (int) (screenHeight * 0.85);
                bottomSheet.setLayoutParams(layoutParams);

                BottomSheetBehavior<View> behavior = BottomSheetBehavior.from(bottomSheet);
                behavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                behavior.setSkipCollapsed(true);
                behavior.setHideable(true);
            }
        });

        notificationDialog.show();
    }

    private void dismissReminder(NotificationItem notification) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .document(notification.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    notificationList.remove(notification);
                    updateNotificationBadge(getUnreadCount());
                    if (notificationDialog != null && notificationDialog.isShowing()) {
                        RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
                        if (recyclerView != null && recyclerView.getAdapter() != null) {
                            recyclerView.getAdapter().notifyDataSetChanged();
                        }
                        updateNotificationsDialogVisibility();
                    }
                    Toast.makeText(getContext(), "Reminder dismissed", Toast.LENGTH_SHORT).show();
                });
    }

    private void updateNotificationsDialogVisibility() {
        if (notificationDialog == null) return;

        RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
        TextView noNotificationsText = notificationDialog.findViewById(R.id.no_notifications_text);

        boolean isEmpty = notificationList.isEmpty();
        if (recyclerView != null) {
            recyclerView.setVisibility(isEmpty ? View.GONE : View.VISIBLE);
        }
        if (noNotificationsText != null) {
            noNotificationsText.setVisibility(isEmpty ? View.VISIBLE : View.GONE);
        }
    }

    private void acceptJarInvite(NotificationItem notification) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getJarId() == null) return;

        Toast.makeText(getContext(), "Joining jar...", Toast.LENGTH_SHORT).show();

        DocumentReference jarRef = FirebaseFirestore.getInstance()
                .collection("jars")
                .document(notification.getJarId());

        jarRef.get().addOnSuccessListener(documentSnapshot -> {
            if (!documentSnapshot.exists()) {
                Toast.makeText(getContext(), "Jar not found", Toast.LENGTH_SHORT).show();
                return;
            }

            List<String> participants = (List<String>) documentSnapshot.get("participants");
            if (participants == null) {
                participants = new ArrayList<>();
            }

            if (participants.contains(currentUser.getUid())) {
                Toast.makeText(getContext(), "You are already a participant", Toast.LENGTH_SHORT).show();
                deleteNotification(notification);
                return;
            }

            participants.add(currentUser.getUid());

            Map<String, Double> contributions = (Map<String, Double>) documentSnapshot.get("participantContributions");
            if (contributions == null) {
                contributions = new HashMap<>();
            }
            contributions.put(currentUser.getUid(), 0.0);

            Map<String, Object> updates = new HashMap<>();
            updates.put("participants", participants);
            updates.put("participantContributions", contributions);

            jarRef.update(updates)
                    .addOnSuccessListener(aVoid -> {
                        String userName = currentUser.getDisplayName();
                        if (userName == null || userName.isEmpty()) {
                            userName = currentUser.getEmail() != null ?
                                    currentUser.getEmail().split("@")[0] : "User";
                        }

                        FirestoreHelper.getInstance().addJarTransaction(
                                notification.getJarId(),
                                notification.getJarName(),
                                currentUser.getUid(),
                                userName,
                                "ADD_PARTICIPANT",
                                0.0,
                                "Joined the jar"
                        );

                        deleteNotification(notification);
                        Toast.makeText(getContext(), "You've joined " + notification.getJarName() + "!", Toast.LENGTH_LONG).show();
                        openJarDetails(notification.getJarId(), notification.getJarName());
                    })
                    .addOnFailureListener(e ->
                            Toast.makeText(getContext(), "Failed to accept invitation: " + e.getMessage(), Toast.LENGTH_LONG).show());
        }).addOnFailureListener(e ->
                Toast.makeText(getContext(), "Failed to load jar: " + e.getMessage(), Toast.LENGTH_LONG).show());
    }

    private void declineJarInvite(NotificationItem notification) {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle("Decline Invitation")
                .setMessage("Are you sure you want to decline the invitation to join '" +
                        notification.getJarName() + "'?")
                .setPositiveButton("Yes, Decline", (dialogInterface, which) -> {
                    deleteNotification(notification);
                    Toast.makeText(getContext(), "Invitation declined", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteNotification(NotificationItem notification) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .document(notification.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    notificationList.remove(notification);
                    updateNotificationBadge(getUnreadCount());
                    if (notificationDialog != null && notificationDialog.isShowing()) {
                        RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
                        if (recyclerView != null && recyclerView.getAdapter() != null) {
                            recyclerView.getAdapter().notifyDataSetChanged();
                        }
                        updateNotificationsDialogVisibility();
                    }
                });
    }

    private int getUnreadCount() {
        int count = 0;
        for (NotificationItem notification : notificationList) {
            if (!notification.isRead()) count++;
        }
        return count;
    }

    private void markNotificationAsRead(NotificationItem notification) {
        if (notification.isRead()) return;

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getId() == null) return;

        Map<String, Object> updates = new HashMap<>();
        updates.put("isRead", true);
        updates.put("read", true);

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .document(notification.getId())
                .update(updates)
                .addOnSuccessListener(aVoid -> {
                    notification.setRead(true);
                    updateNotificationBadge(getUnreadCount());
                    if (notificationDialog != null && notificationDialog.isShowing()) {
                        RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
                        if (recyclerView != null && recyclerView.getAdapter() != null) {
                            recyclerView.getAdapter().notifyDataSetChanged();
                        }
                    }
                });
    }

    private void markAllNotificationsAsRead() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        WriteBatch batch = FirebaseFirestore.getInstance().batch();
        boolean hasUnread = false;

        for (NotificationItem notification : notificationList) {
            if (!notification.isRead()) {
                hasUnread = true;
                DocumentReference notifRef = FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(currentUser.getUid())
                        .collection("notifications")
                        .document(notification.getId());

                batch.update(notifRef, "isRead", true);
                batch.update(notifRef, "read", true);
                notification.setRead(true);
            }
        }

        if (hasUnread) {
            updateNotificationBadge(0);
            if (notificationDialog != null && notificationDialog.isShowing()) {
                RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
                if (recyclerView != null && recyclerView.getAdapter() != null) {
                    recyclerView.getAdapter().notifyDataSetChanged();
                }
            }

            batch.commit().addOnSuccessListener(aVoid ->
                            Toast.makeText(getContext(), "All notifications marked as read.", Toast.LENGTH_SHORT).show())
                    .addOnFailureListener(e ->
                            Toast.makeText(getContext(), "Failed to update some notifications.", Toast.LENGTH_SHORT).show());
        } else {
            Toast.makeText(getContext(), "You have no unread notifications.", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleNotificationClick(NotificationItem notification) {
        if (getContext() == null) return;

        BottomSheetDialog detailsDialog = new BottomSheetDialog(requireContext());
        View view = getLayoutInflater().inflate(R.layout.dialog_notification_details, null);
        detailsDialog.setContentView(view);

        ImageView icon = view.findViewById(R.id.detail_icon);
        TextView title = view.findViewById(R.id.detail_title);
        TextView date = view.findViewById(R.id.detail_date);
        TextView message = view.findViewById(R.id.detail_message);
        MaterialButton btnAction = view.findViewById(R.id.btn_action);
        MaterialButton btnClose = view.findViewById(R.id.btn_close);

        title.setText(notification.getTitle());
        message.setText(notification.getMessage());

        if (notification.getTimestamp() != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault());
            date.setText(sdf.format(notification.getTimestamp()));
        } else {
            date.setText("Just now");
        }

        int iconResId = R.drawable.ic_notifications;
        int bgColor = Color.parseColor("#F1F3F4");
        int iconTint = Color.parseColor("#5F6368");
        String buttonText = "";
        boolean showButton = true;

        String type = notification.getType() != null ? notification.getType() : "DEFAULT";

        switch (type) {
            case "BILL_PAID":
                iconResId = R.drawable.ic_visual_reports;
                bgColor = Color.parseColor("#E6F4EA");
                iconTint = Color.parseColor("#4CAF50");
                buttonText = "View Bills";
                break;
            case "BILL_DUE":
                iconResId = R.drawable.ic_visual_reports;
                bgColor = Color.parseColor("#FCE8E6");
                iconTint = Color.parseColor("#EA4335");
                buttonText = "Pay Bill Now";
                break;
            case "JAR_INVITE":
                iconResId = R.drawable.ic_add_person;
                bgColor = Color.parseColor("#E8F0FE");
                iconTint = Color.parseColor("#1976D2");
                buttonText = "Go to Jars";
                break;
            case "JAR_GOAL_REACHED":
            case "JAR_UPDATE":
            case "ADD_MONEY":
                iconResId = R.drawable.ic_wallet;
                bgColor = type.equals("JAR_GOAL_REACHED") ? Color.parseColor("#FEF7E0") : Color.parseColor("#E6F4EA");
                iconTint = type.equals("JAR_GOAL_REACHED") ? Color.parseColor("#F29900") : Color.parseColor("#4CAF50");
                buttonText = "View Jar Details";
                break;
            case "CHALLENGE_REMINDER":
            case "CHALLENGE_DEADLINE":
            case "CHALLENGE_CHECKIN":
                iconResId = R.drawable.ic_notifications;
                bgColor = Color.parseColor("#F3E5F5");
                iconTint = Color.parseColor("#9C27B0");
                buttonText = "View Challenges";
                break;
            default:
                showButton = false;
                break;
        }

        icon.setImageResource(iconResId);
        icon.setColorFilter(iconTint);
        if (icon.getBackground() != null) {
            icon.getBackground().setTint(bgColor);
        }

        if (showButton) {
            btnAction.setVisibility(View.VISIBLE);
            btnAction.setText(buttonText);
            btnAction.setOnClickListener(v -> {
                detailsDialog.dismiss();
                if (notificationDialog != null) notificationDialog.dismiss();

                if (type.equals("BILL_PAID")) {
                    startActivity(new Intent(getActivity(), ArchivesActivity.class));
                } else if (type.equals("BILL_DUE") || type.contains("BILL")) {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_bills);
                    }
                } else if (type.equals("JAR_INVITE")) {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_jars);
                    }
                } else if (type.contains("CHALLENGE")) {
                    if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_challenges);
                    }
                } else if (type.contains("JAR") || type.equals("ADD_MONEY")) {
                    if (notification.getJarId() != null) {
                        openJarDetails(notification.getJarId(), notification.getJarName());
                    } else if (getActivity() instanceof MainActivity) {
                        ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_jars);
                    }
                }
            });
        } else {
            btnAction.setVisibility(View.GONE);
        }

        btnClose.setOnClickListener(v -> detailsDialog.dismiss());
        detailsDialog.show();
    }

    private void openJarDetails(String jarId, String jarName) {
        Intent intent = new Intent(getActivity(), SharedJarsDetails.class);
        intent.putExtra("JAR_ID", jarId);
        intent.putExtra("JAR_NAME", jarName);
        intent.putExtra("JAR_SAVED", 0.0);
        intent.putExtra("JAR_GOAL", 0.0);
        intent.putExtra("ICON_NAME", "hat");
        intent.putExtra("COLOR", 0xFFF44336);
        intent.putExtra("JAR_TYPE", "Shared");
        startActivity(intent);

        if (notificationDialog != null) {
            notificationDialog.dismiss();
        }
    }

    public static class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {
        private final List<Transaction> list;

        public TransactionAdapter(List<Transaction> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_transaction, parent, false);
            SettingHelper.applyTheme(parent.getContext());
            return new ViewHolder(view);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Transaction item = list.get(position);
            Context context = holder.itemView.getContext();

            holder.tvTitle.setText(item.getTitle());

            String dateToShow = "Recent";
            if (item.getTimestamp() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                dateToShow = sdf.format(item.getTimestamp().toDate());
            } else if (item.getDate() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                dateToShow = sdf.format(item.getDate());
            }
            holder.tvDate.setText(dateToShow);

            if (holder.tvDesc != null) {
                String desc = item.getDescription();
                if (desc == null || desc.trim().isEmpty()) {
                    desc = item.getCategory() != null ? item.getCategory() : "";
                }
                holder.tvDesc.setText(desc);
            }

            String formattedAmount = SettingHelper.formatAmount(context, item.getAmount());
            int expenseColor, incomeColor, expenseBgColor, incomeBgColor;

            if (SettingHelper.isDarkMode(context)) {
                expenseColor = Color.parseColor("#EF9A9A");
                incomeColor = Color.parseColor("#81C784");
                expenseBgColor = Color.parseColor("#4A1F1F");
                incomeBgColor = Color.parseColor("#1F4A23");
            } else {
                expenseColor = Color.parseColor("#F44336");
                incomeColor = Color.parseColor("#4CAF50");
                expenseBgColor = Color.parseColor("#FCE8E6");
                incomeBgColor = Color.parseColor("#E6F4EA");
            }

            if (item.isExpense()) {
                holder.tvAmount.setText(context.getString(R.string.amount_format_negative, formattedAmount));
                holder.tvAmount.setTextColor(expenseColor);
                holder.cardBackground.setCardBackgroundColor(expenseBgColor);
                holder.iconImage.setImageResource(R.drawable.ic_arrow_down);
                holder.iconImage.setColorFilter(expenseColor);
            } else {
                holder.tvAmount.setText(context.getString(R.string.amount_format_positive, formattedAmount));
                holder.tvAmount.setTextColor(incomeColor);
                holder.cardBackground.setCardBackgroundColor(incomeBgColor);
                holder.iconImage.setImageResource(R.drawable.ic_arrow_up);
                holder.iconImage.setColorFilter(incomeColor);
            }

            if (SettingHelper.isDarkMode(context)) {
                holder.tvTitle.setTextColor(Color.WHITE);
                holder.tvDate.setTextColor(Color.LTGRAY);
                if (holder.tvDesc != null) holder.tvDesc.setTextColor(Color.LTGRAY);
            } else {
                holder.tvTitle.setTextColor(Color.BLACK);
                holder.tvDate.setTextColor(Color.DKGRAY);
                if (holder.tvDesc != null) holder.tvDesc.setTextColor(Color.DKGRAY);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDate, tvAmount, tvDesc;
            CardView cardBackground;
            ImageView iconImage;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.text_title);
                tvDate = itemView.findViewById(R.id.text_date);
                tvAmount = itemView.findViewById(R.id.text_amount);
                tvDesc = itemView.findViewById(R.id.text_desc);
                cardBackground = itemView.findViewById(R.id.icon_background_card);
                iconImage = itemView.findViewById(R.id.icon_image);
            }
        }
    }
}