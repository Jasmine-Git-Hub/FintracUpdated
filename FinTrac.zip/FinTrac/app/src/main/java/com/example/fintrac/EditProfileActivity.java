package com.example.fintrac;

import android.app.DatePickerDialog;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class EditProfileActivity extends AppCompatActivity {

    private ImageView btnBack, ivProfilePicture;
    private MaterialCardView cardProfileImage;
    private TextView tvChangePhoto;
    private EditText etFullName, etEmail, etBirthday, etOccupation;
    private Spinner spinnerGender;
    private MaterialButton btnSaveProfile;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String userID;

    private Uri selectedImageUri = null;
    private String selectedAvatarName = null;

    private final ActivityResultLauncher<String> pickMedia =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    selectedImageUri = uri;
                    selectedAvatarName = null;
                    ivProfilePicture.setPadding(0, 0, 0, 0);
                    ivProfilePicture.setImageTintList(null);
                    ivProfilePicture.setImageURI(uri);
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SettingHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            userID = currentUser.getUid();
        } else {
            userID = "guest_user";
        }

        initViews();
        setupGenderSpinner();
        loadExistingProfile();
        setupListeners();
    }

    private void initViews() {
        btnBack = findViewById(R.id.btnBack);
        ivProfilePicture = findViewById(R.id.ivProfilePicture);
        cardProfileImage = findViewById(R.id.cardProfileImage);
        tvChangePhoto = findViewById(R.id.tvChangePhoto);
        etFullName = findViewById(R.id.etFullName);
        etEmail = findViewById(R.id.etEmail);
        etBirthday = findViewById(R.id.etBirthday);
        etOccupation = findViewById(R.id.etOccupation);
        spinnerGender = findViewById(R.id.spinnerGender);
        btnSaveProfile = findViewById(R.id.btnSaveProfile);

        // Gawing Read-Only ang Email para iwas conflict sa Firebase Auth at duplicate checks
        etEmail.setEnabled(false);
        etEmail.setFocusable(false);
    }

    private void setupListeners() {
        btnBack.setOnClickListener(v -> finish());
        cardProfileImage.setOnClickListener(v -> showAvatarMenu());
        tvChangePhoto.setOnClickListener(v -> showAvatarMenu());
        etBirthday.setOnClickListener(v -> showDatePicker());

        // Direkta na sa pag-save, wala ng email checking
        btnSaveProfile.setOnClickListener(v -> validateAndSaveProfile());
    }

    private void showAvatarMenu() {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_choose_avatar, null, false);
        dialog.setContentView(view);

        MaterialButton btnGallery = view.findViewById(R.id.btnChooseGallery);

        View.OnClickListener avatarClickListener = v -> {
            String tagStr = (String) v.getTag();
            if (tagStr != null) {
                selectedAvatarName = tagStr;
                selectedImageUri = null;
                ivProfilePicture.setPadding(16, 16, 16, 16);
                ivProfilePicture.setImageTintList(null);

                int resId = getResources().getIdentifier(tagStr, "drawable", getPackageName());
                if (resId != 0) {
                    ivProfilePicture.setImageResource(resId);
                }
            }
            dialog.dismiss();
        };

        int[] avatarIds = {
                R.id.avatar1, R.id.avatar2, R.id.avatar3, R.id.avatar4,
                R.id.avatar5, R.id.avatar6, R.id.avatar7, R.id.avatar8,
                R.id.avatar9, R.id.avatar10, R.id.avatar11, R.id.avatar12,
                R.id.avatar13, R.id.avatar14, R.id.avatar19, R.id.avatar16
        };

        for (int i = 0; i < avatarIds.length; i++) {
            ImageView av = view.findViewById(avatarIds[i]);
            if (av != null) {
                av.setTag("avatar_" + (i + 1));
                av.setOnClickListener(avatarClickListener);
            }
        }

        btnGallery.setOnClickListener(v -> {
            dialog.dismiss();
            pickMedia.launch("image/*");
        });

        dialog.show();
    }

    private void setupGenderSpinner() {
        String[] genders = {"Select Gender", "Male", "Female", "Non-Binary", "Prefer not to say"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, genders);
        spinnerGender.setAdapter(adapter);
    }

    private void showDatePicker() {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                (view, selectedYear, selectedMonth, selectedDay) -> {
                    String formattedDate = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                    etBirthday.setText(formattedDate);
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    @SuppressWarnings("unchecked")
    private void loadExistingProfile() {
        if (userID.equals("guest_user")) return;

        db.collection("users").document(userID).get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        etFullName.setText(documentSnapshot.getString("fullName"));
                        etEmail.setText(documentSnapshot.getString("email"));
                        etBirthday.setText(documentSnapshot.getString("birthday"));
                        etOccupation.setText(documentSnapshot.getString("occupation"));

                        String gender = documentSnapshot.getString("gender");
                        if (gender != null && spinnerGender.getAdapter() != null) {
                            ArrayAdapter<String> adapter = (ArrayAdapter<String>) spinnerGender.getAdapter();
                            spinnerGender.setSelection(adapter.getPosition(gender));
                        }

                        String savedAvatar = documentSnapshot.getString("profileAvatar");
                        String savedUri = documentSnapshot.getString("profileImageLocalUri");

                        if (savedUri != null && !savedUri.isEmpty()) {
                            selectedImageUri = Uri.parse(savedUri);
                            ivProfilePicture.setPadding(0, 0, 0, 0);
                            ivProfilePicture.setImageTintList(null);
                            ivProfilePicture.setImageURI(selectedImageUri);
                        } else if (savedAvatar != null) {
                            selectedAvatarName = savedAvatar;
                            ivProfilePicture.setPadding(16, 16, 16, 16);
                            ivProfilePicture.setImageTintList(null);

                            int resId = getResources().getIdentifier(savedAvatar, "drawable", getPackageName());
                            if (resId != 0) {
                                ivProfilePicture.setImageResource(resId);
                            }
                        }
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to load profile", Toast.LENGTH_SHORT).show());
    }

    private void validateAndSaveProfile() {
        if (userID.equals("guest_user")) {
            Toast.makeText(this, "Cannot save. Please login first.", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = etFullName.getText().toString().trim();

        if (name.isEmpty()) {
            Toast.makeText(this, "Name is required", Toast.LENGTH_SHORT).show();
            return;
        }

        // Diretsong save na agad, wala ng email duplication check!
        performSaveToFirestore(name);
    }

    private void performSaveToFirestore(String name) {
        btnSaveProfile.setEnabled(false);
        btnSaveProfile.setText("Saving...");

        Map<String, Object> profileData = new HashMap<>();
        profileData.put("fullName", name);
        // Hindi na natin ipapasa yung email dito para hindi magulo yung current data
        profileData.put("birthday", etBirthday.getText().toString().trim());
        profileData.put("occupation", etOccupation.getText().toString().trim());

        String gender = spinnerGender.getSelectedItem().toString();
        if (!gender.equals("Select Gender")) profileData.put("gender", gender);

        // Paggamit ng FieldValue.delete() para malinis ang database at iwas conflict
        if (selectedImageUri != null) {
            profileData.put("profileImageLocalUri", selectedImageUri.toString());
            profileData.put("profileAvatar", FieldValue.delete());
        } else if (selectedAvatarName != null) {
            profileData.put("profileAvatar", selectedAvatarName);
            profileData.put("profileImageLocalUri", FieldValue.delete());
        }

        // I-update ang FirebaseAuth Profile Display Name para consistent
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                    .setDisplayName(name)
                    .build();
            user.updateProfile(profileUpdates);
        }

        // SetOptions.merge() ay maganda para sigurado na in-update lang ang existing document ng userID
        db.collection("users").document(userID)
                .set(profileData, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Profile Saved Successfully!", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to save: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    btnSaveProfile.setEnabled(true);
                    btnSaveProfile.setText("Save Changes");
                });
    }
}