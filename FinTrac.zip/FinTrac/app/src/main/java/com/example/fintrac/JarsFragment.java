package com.example.fintrac;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;

public class JarsFragment extends Fragment implements JarAdapter.OnItemSwipeListener {

    private RecyclerView jarsRecyclerView;
    private JarAdapter jarAdapter;
    private List<JarItem> jarList;
    private TextView totalSavedAmount, totalGoalsAmount;
    private ChipGroup chipGroup;
    private SwipeRefreshLayout swipeRefreshLayout;

    private JarFirestoreManager firestoreManager;
    private ActivityResultLauncher<Intent> detailsLauncher;
    private FirebaseFirestore db;
    private FirebaseAuth mAuth;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        firestoreManager = new JarFirestoreManager();
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        // Setup Launcher for Updates
        detailsLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        String updatedId = result.getData().getStringExtra("UPDATED_ID");
                        double newSavedAmount = result.getData().getDoubleExtra("UPDATED_SAVED", -1.0);

                        if (updatedId != null && newSavedAmount != -1.0 && jarList != null) {
                            for (int i = 0; i < jarList.size(); i++) {
                                if (jarList.get(i).getId().equals(updatedId)) {
                                    jarList.get(i).setSavedAmount(newSavedAmount);
                                    jarAdapter.notifyItemChanged(i);
                                    updateSummaryCards();
                                    break;
                                }
                            }
                        }
                    }
                }
        );

        // Listen for CreateJar results
        getParentFragmentManager().setFragmentResultListener(
                CreateJarDialogFragment.REQUEST_KEY,
                this,
                (requestKey, bundle) -> {
                    String jarName = bundle.getString(CreateJarDialogFragment.KEY_JAR_NAME);
                    String targetAmount = bundle.getString(CreateJarDialogFragment.KEY_TARGET_AMOUNT);
                    String jarType = bundle.getString(CreateJarDialogFragment.KEY_JAR_TYPE, "Flexible");
                    String iconName = bundle.getString(CreateJarDialogFragment.KEY_SELECTED_ICON, "hat");
                    int jarColor = bundle.getInt(CreateJarDialogFragment.KEY_SELECTED_COLOR, Color.RED);
                    String deadline = bundle.getString(CreateJarDialogFragment.KEY_DEADLINE, "");

                    if (targetAmount != null && jarName != null && !targetAmount.isEmpty()) {
                        try {
                            // Allow decimals
                            String cleanAmount = targetAmount.replaceAll("[^\\d.]", "");
                            if (cleanAmount.isEmpty() || cleanAmount.equals(".")) cleanAmount = "0";

                            double goalAmountUI = Double.parseDouble(cleanAmount);

                            // CONVERT TO BASE PHP BEFORE SAVING
                            double amountInPHP = SettingHelper.convertToBasePHP(getContext(), goalAmountUI);

                            String weeklyAmount = "~" + SettingHelper.formatAmount(getContext(), amountInPHP / 52.0) + "/week";

                            // Get current user ID
                            FirebaseUser currentUser = mAuth.getCurrentUser();
                            String userId = currentUser != null ? currentUser.getUid() : "";

                            String daysLeft = "New";
                            if (!deadline.isEmpty()) {
                                daysLeft = "30 days left";
                            }

                            // Create jar model
                            JarFirestoreModel newJar = new JarFirestoreModel(
                                    null,
                                    jarName,
                                    jarType,
                                    0.0,
                                    amountInPHP,
                                    daysLeft,
                                    weeklyAmount,
                                    iconName,
                                    jarColor,
                                    userId
                            );

                            firestoreManager.createJar(newJar,
                                    new JarFirestoreManager.FirestoreCallback<DocumentReference>() {
                                        @Override
                                        public void onSuccess(DocumentReference result) {
                                            Toast.makeText(getContext(),
                                                    "Jar created successfully!",
                                                    Toast.LENGTH_SHORT).show();
                                            loadJarsFromFirestore();
                                        }

                                        @Override
                                        public void onFailure(Exception e) {
                                            Toast.makeText(getContext(),
                                                    "Error creating jar: " + e.getMessage(),
                                                    Toast.LENGTH_SHORT).show();
                                            Log.e("JarsFragment", "Create jar error", e);
                                        }
                                    });
                        } catch (NumberFormatException e) {
                            Toast.makeText(getContext(),
                                    "Invalid amount format",
                                    Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getContext(),
                                "Please enter jar name and amount",
                                Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_jars, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        jarsRecyclerView = view.findViewById(R.id.jars_recycler_view);
        totalSavedAmount = view.findViewById(R.id.total_saved_amount);
        totalGoalsAmount = view.findViewById(R.id.total_goals_amount);
        chipGroup = view.findViewById(R.id.chip_group);
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);

        jarList = new ArrayList<>();
        setupRecyclerView();
        setupFilterChips();
        loadJarsFromFirestore();

        FloatingActionButton addJarFab = view.findViewById(R.id.add_jar_fab);
        addJarFab.setOnClickListener(v -> {
            CreateJarDialogFragment dialogFragment = new CreateJarDialogFragment();
            dialogFragment.show(getParentFragmentManager(), "CreateJarDialogFragment");
        });

        if (swipeRefreshLayout != null) {
            swipeRefreshLayout.setOnRefreshListener(this::loadJarsFromFirestore);
            swipeRefreshLayout.setColorSchemeColors(
                    ContextCompat.getColor(requireContext(), R.color.blue),
                    ContextCompat.getColor(requireContext(), R.color.green),
                    ContextCompat.getColor(requireContext(), R.color.jar_color_orange),
                    ContextCompat.getColor(requireContext(), R.color.jar_color_purple)
            );
        }
    }

    private void loadJarsFromFirestore() {
        firestoreManager.getAllJars(new JarFirestoreManager.FirestoreCallback<List<JarFirestoreModel>>() {
            @Override
            public void onSuccess(List<JarFirestoreModel> jarModels) {
                if (jarList != null && jarAdapter != null) {
                    jarList.clear();
                    for (JarFirestoreModel model : jarModels) {
                        if (model != null) {
                            jarList.add(model.toJarItem());
                        }
                    }
                    jarAdapter.updateJarList(new ArrayList<>(jarList));
                    updateSummaryCards();
                }
                if (swipeRefreshLayout != null && swipeRefreshLayout.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                }
            }

            @Override
            public void onFailure(Exception e) {
                Toast.makeText(getContext(),
                        "Error loading jars: " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
                Log.e("JarsFragment", "Error loading jars", e);
                if (swipeRefreshLayout != null && swipeRefreshLayout.isRefreshing()) {
                    swipeRefreshLayout.setRefreshing(false);
                }
            }
        });
    }

    private void setupRecyclerView() {
        jarAdapter = new JarAdapter(requireContext(), jarList, detailsLauncher);
        // Set this fragment as the swipe listener
        jarAdapter.setSwipeListener(this);

        jarsRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        jarsRecyclerView.setAdapter(jarAdapter);

        // Add swipe to delete functionality
        SwipeToDeleteCallback swipeToDeleteCallback = new SwipeToDeleteCallback(requireContext(), jarAdapter);
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(swipeToDeleteCallback);
        itemTouchHelper.attachToRecyclerView(jarsRecyclerView);
    }

    private void setupFilterChips() {
        if (chipGroup == null) return;

        chipGroup.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) {
                if (jarAdapter != null && jarList != null) {
                    jarAdapter.updateJarList(new ArrayList<>(jarList));
                }
                return;
            }

            int checkedId = checkedIds.get(0);

            if (checkedId == R.id.chip_all) {
                if (jarAdapter != null && jarList != null) {
                    jarAdapter.updateJarList(new ArrayList<>(jarList));
                }
            } else {
                String selectedType = "";
                if (checkedId == R.id.chip_mandatory) {
                    selectedType = "Mandatory";
                } else if (checkedId == R.id.chip_flexible) {
                    selectedType = "Flexible";
                } else if (checkedId == R.id.chip_shared) {
                    selectedType = "Shared";
                }

                if (!selectedType.isEmpty() && jarList != null) {
                    List<JarItem> filteredList = new ArrayList<>();
                    for (JarItem jar : jarList) {
                        if (jar.getType().equalsIgnoreCase(selectedType)) {
                            filteredList.add(jar);
                        }
                    }
                    if (jarAdapter != null) {
                        jarAdapter.updateJarList(filteredList);
                    }
                }
            }
        });

        if (chipGroup.getCheckedChipId() == View.NO_ID) {
            Chip allChip = chipGroup.findViewById(R.id.chip_all);
            if (allChip != null) {
                allChip.setChecked(true);
            }
        }
    }

    private void updateSummaryCards() {
        double totalSaved = 0.0;
        double totalGoals = 0.0;

        if (jarList != null) {
            for (JarItem jar : jarList) {
                totalSaved += jar.getSavedAmount();
                totalGoals += jar.getGoalAmount();
            }
        }

        if (totalSavedAmount != null && getContext() != null) {
            totalSavedAmount.setText(SettingHelper.formatAmount(getContext(), totalSaved));
        }

        if (totalGoalsAmount != null && getContext() != null) {
            totalGoalsAmount.setText(SettingHelper.formatAmount(getContext(), totalGoals));
        }
    }

    // Interface method implementation for swipe deletion
    @Override
    public void onItemSwipe(JarItem jarItem, int position) {
        // Show confirmation dialog
        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Jar")
                .setMessage("Are you sure you want to delete \"" + jarItem.getName() + "\"? This action cannot be undone.")
                .setPositiveButton("Delete", (dialog, which) -> {
                    // Show loading state
                    if (swipeRefreshLayout != null) {
                        swipeRefreshLayout.setRefreshing(true);
                    }

                    // Call Firestore to delete
                    firestoreManager.deleteJar(jarItem.getId(), new JarFirestoreManager.FirestoreCallback<Void>() {
                        @Override
                        public void onSuccess(Void result) {
                            // Remove from list and notify adapter
                            int index = jarList.indexOf(jarItem);
                            if (index != -1) {
                                jarList.remove(index);
                                jarAdapter.notifyItemRemoved(index);
                                updateSummaryCards();
                            }

                            if (swipeRefreshLayout != null) {
                                swipeRefreshLayout.setRefreshing(false);
                            }

                            Toast.makeText(getContext(),
                                    "Jar deleted successfully",
                                    Toast.LENGTH_SHORT).show();
                        }

                        @Override
                        public void onFailure(Exception e) {
                            if (swipeRefreshLayout != null) {
                                swipeRefreshLayout.setRefreshing(false);
                            }

                            Toast.makeText(getContext(),
                                    "Error deleting jar: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                            Log.e("JarsFragment", "Error deleting jar", e);
                        }
                    });
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    // If user cancels, refresh the adapter to remove the swipe state
                    jarAdapter.notifyItemChanged(position);
                })
                .show();
    }

    @Override
    public void onResume() {
        super.onResume();
        loadJarsFromFirestore();
    }
}