package com.example.fintrac;

import androidx.annotation.NonNull;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FirestoreHelper {
    private static final String COLLECTION_TRANSACTIONS = "transactions";
    private static final String COLLECTION_USERS = "users";
    private static final String COLLECTION_JAR_TRANSACTIONS = "jarTransactions"; // Add this

    private final FirebaseFirestore db;
    private final FirebaseAuth mAuth;
    private static FirestoreHelper instance;

    private FirestoreHelper() {
        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
    }

    public static synchronized FirestoreHelper getInstance() {
        if (instance == null) {
            instance = new FirestoreHelper();
        }
        return instance;
    }

    private String getCurrentUserId() {
        FirebaseUser user = mAuth.getCurrentUser();
        return user != null ? user.getUid() : null;
    }

    // ============ USER OPERATIONS ============
    public void saveUserData(String userId, String name, String email, final OnUserSavedListener listener) {
        Map<String, Object> user = new HashMap<>();
        user.put("userId", userId);
        user.put("name", name);
        user.put("email", email);
        user.put("createdAt", new Date());

        db.collection(COLLECTION_USERS)
                .document(userId)
                .set(user)
                .addOnSuccessListener(aVoid -> {
                    if (listener != null) {
                        listener.onSuccess();
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    // ============ TRANSACTION OPERATIONS ============
    public void addTransaction(Transaction transaction, final OnTransactionAddedListener listener) {
        String userId = getCurrentUserId();
        if (userId == null) {
            if (listener != null) {
                listener.onFailure("User not authenticated");
            }
            return;
        }

        // Ensure timestamp is set
        if (transaction.getTimestamp() == null) {
            transaction.setTimestamp(new Timestamp(new Date()));
        }

        transaction.setUserId(userId);

        db.collection(COLLECTION_TRANSACTIONS)
                .add(transaction)
                .addOnSuccessListener(documentReference -> {
                    transaction.setId(documentReference.getId());
                    documentReference.update("id", documentReference.getId());
                    if (listener != null) {
                        listener.onSuccess(transaction);
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    public void getRecentTransactions(int limit, final OnTransactionsLoadedListener listener) {
        String userId = getCurrentUserId();
        if (userId == null) {
            if (listener != null) {
                listener.onFailure("User not authenticated");
            }
            return;
        }

        db.collection(COLLECTION_TRANSACTIONS)
                .whereEqualTo("userId", userId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(limit)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Transaction> transactions = new ArrayList<>();
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        Transaction transaction = document.toObject(Transaction.class);
                        if (transaction != null) {
                            transaction.setId(document.getId());
                            transactions.add(transaction);
                        }
                    }
                    if (listener != null) {
                        listener.onSuccess(transactions);
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    /**
     * UPDATED: Get total balance EXCLUDING jar transactions
     * Jar transactions are stored separately, so we only count regular transactions
     */
    public void getTotalBalance(final OnBalanceLoadedListener listener) {
        String userId = getCurrentUserId();
        if (userId == null) {
            if (listener != null) {
                listener.onFailure("User not authenticated");
            }
            return;
        }

        db.collection(COLLECTION_TRANSACTIONS)
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double totalBalance = 0;
                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        Transaction transaction = document.toObject(Transaction.class);
                        if (transaction != null) {
                            if (transaction.isExpense()) {
                                totalBalance -= transaction.getAmount();
                            } else {
                                totalBalance += transaction.getAmount();
                            }
                        }
                    }

                    // Note: We don't include jar transactions here because they're in a separate collection
                    // The money in jars is calculated separately by loadTotalInJars() in HomeFragment

                    if (listener != null) {
                        listener.onSuccess(totalBalance);
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    /**
     * Get weekly expenses for the current week (Sunday to Saturday)
     * UPDATED: Exclude jar transactions from weekly expenses
     */
    public void getWeeklyExpenses(final OnWeeklyExpensesLoadedListener listener) {
        String userId = getCurrentUserId();
        if (userId == null) {
            if (listener != null) {
                listener.onFailure("User not authenticated");
            }
            return;
        }

        // Get start of week (Sunday)
        Calendar calendar = Calendar.getInstance();
        calendar.setFirstDayOfWeek(Calendar.SUNDAY);
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date startOfWeek = calendar.getTime();

        // Get end of week (Saturday)
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SATURDAY);
        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        calendar.set(Calendar.MILLISECOND, 999);
        Date endOfWeek = calendar.getTime();

        db.collection(COLLECTION_TRANSACTIONS)
                .whereEqualTo("userId", userId)
                .whereEqualTo("isExpense", true)
                .whereGreaterThanOrEqualTo("timestamp", new Timestamp(startOfWeek))
                .whereLessThanOrEqualTo("timestamp", new Timestamp(endOfWeek))
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    float[] weeklyExpenses = new float[7];

                    for (DocumentSnapshot document : queryDocumentSnapshots) {
                        Transaction transaction = document.toObject(Transaction.class);
                        if (transaction != null && transaction.getTimestamp() != null) {
                            // Skip jar transactions if they accidentally got into regular transactions
                            if (transaction.getDescription() != null &&
                                    (transaction.getDescription().contains("Jar:") ||
                                            transaction.getDescription().contains("jar:"))) {
                                continue;
                            }

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(transaction.getTimestamp().toDate());
                            int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                            // Convert to 0-6 (0=Sunday, 6=Saturday)
                            int index;
                            switch (dayOfWeek) {
                                case Calendar.SUNDAY: index = 0; break;
                                case Calendar.MONDAY: index = 1; break;
                                case Calendar.TUESDAY: index = 2; break;
                                case Calendar.WEDNESDAY: index = 3; break;
                                case Calendar.THURSDAY: index = 4; break;
                                case Calendar.FRIDAY: index = 5; break;
                                case Calendar.SATURDAY: index = 6; break;
                                default: index = 0;
                            }
                            weeklyExpenses[index] += (float) transaction.getAmount();
                        }
                    }

                    if (listener != null) {
                        listener.onSuccess(weeklyExpenses);
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    // ============ BILLS OPERATIONS ============
    /**
     * Get all unpaid bills for the current user
     */
    public void getUnpaidBills(final OnUnpaidBillsLoadedListener listener) {
        String userId = getCurrentUserId();
        if (userId == null) {
            if (listener != null) {
                listener.onFailure("User not authenticated");
            }
            return;
        }

        db.collection("users")
                .document(userId)
                .collection("bills")
                .whereEqualTo("isPaid", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    List<Bill> unpaidBills = new ArrayList<>();
                    for (com.google.firebase.firestore.QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Long logoResIdLong = doc.getLong("logoResId");
                        int logoResId = (logoResIdLong != null) ? logoResIdLong.intValue() : R.drawable.ic_visual_reports;

                        Boolean isPaid = doc.getBoolean("isPaid");
                        boolean isPaidValue = (isPaid != null) ? isPaid : false;

                        Bill bill = new Bill(
                                doc.getId(),
                                doc.getString("name"),
                                doc.getString("category"),
                                doc.getString("frequency"),
                                doc.getString("amount"),
                                doc.getString("dueDate"),
                                logoResId,
                                isPaidValue
                        );
                        unpaidBills.add(bill);
                    }

                    // Sort by due date (closest first)
                    sortBillsByDueDate(unpaidBills);

                    if (listener != null) {
                        listener.onSuccess(unpaidBills);
                    }
                })
                .addOnFailureListener(e -> {
                    if (listener != null) {
                        listener.onFailure(e.getMessage());
                    }
                });
    }

    /**
     * Sort bills by due date (closest first)
     */
    private void sortBillsByDueDate(List<Bill> bills) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);

        bills.sort((bill1, bill2) -> {
            try {
                String date1 = bill1.dueDate.replace("Due: ", "");
                String date2 = bill2.dueDate.replace("Due: ", "");

                Date d1 = sdf.parse(date1);
                Date d2 = sdf.parse(date2);

                if (d1 == null) return 1;
                if (d2 == null) return -1;

                return d1.compareTo(d2);
            } catch (Exception e) {
                return 0;
            }
        });
    }

    // ============ LISTENERS ============
    public interface OnUserSavedListener {
        void onSuccess();
        void onFailure(String error);
    }

    public interface OnTransactionAddedListener {
        void onSuccess(Transaction transaction);
        void onFailure(String error);
    }

    public interface OnTransactionsLoadedListener {
        void onSuccess(List<Transaction> transactions);
        void onFailure(String error);
    }

    public interface OnBalanceLoadedListener {
        void onSuccess(double balance);
        void onFailure(String error);
    }

    public interface OnWeeklyExpensesLoadedListener {
        void onSuccess(float[] weeklyExpenses);
        void onFailure(String error);
    }

    // NEW: Interface for unpaid bills
    public interface OnUnpaidBillsLoadedListener {
        void onSuccess(List<Bill> bills);
        void onFailure(String error);
    }
}