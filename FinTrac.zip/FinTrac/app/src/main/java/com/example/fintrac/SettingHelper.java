package com.example.fintrac;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.content.ContextCompat;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SettingHelper {

    private static final String PREFS_NAME = "AppSettings";
    private static final String THEME_PREF = "isDarkMode";
    private static final String COLOR_PREF = "themeColor";
    private static final String CURRENCY_PREF = "selectedCurrency";

    public static void applyTheme(Activity activity) {
        SharedPreferences sharedPreferences = activity.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isDarkMode = sharedPreferences.getBoolean(THEME_PREF, false);
        AppCompatDelegate.setDefaultNightMode(isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        int savedColor = sharedPreferences.getInt(COLOR_PREF, R.color.ocean_blue);
        try { activity.getWindow().setStatusBarColor(ContextCompat.getColor(activity, savedColor)); } catch (Exception e) { e.printStackTrace(); }
    }

    public static void applyTheme(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isDarkMode = sharedPreferences.getBoolean(THEME_PREF, false);
        AppCompatDelegate.setDefaultNightMode(isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static boolean isDarkMode(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(THEME_PREF, false);
    }

    public static void saveDarkModeSetting(Context context, boolean isDarkMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(THEME_PREF, isDarkMode).apply();
        AppCompatDelegate.setDefaultNightMode(isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }

    public static void saveThemeColor(Context context, int colorResId) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putInt(COLOR_PREF, colorResId).apply();
    }

    public static void saveCurrency(Context context, String currencyName) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(CURRENCY_PREF, currencyName).apply();
    }

    public static String getCurrency(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(CURRENCY_PREF, "Philippine Peso (PHP)");
    }

    public static void updateRatesIfNecessary(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo net = cm.getActiveNetworkInfo();
        if (net != null && net.isConnected() && (System.currentTimeMillis() - prefs.getLong("LAST_UPDATED", 0) > 3600000)) {
            fetchRealTimeRates(context);
        }
    }

    private static void fetchRealTimeRates(Context context) {
        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                URL url = new URL("https://open.er-api.com/v6/latest/PHP");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                if (conn.getResponseCode() == 200) {
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    StringBuilder res = new StringBuilder(); String line;
                    while ((line = in.readLine()) != null) res.append(line);
                    in.close();
                    JSONObject rates = new JSONObject(res.toString()).getJSONObject("rates");
                    SharedPreferences.Editor ed = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit();
                    String[] codes = {"USD", "EUR", "JPY", "GBP", "KRW", "SGD", "AUD", "CAD", "CNY", "INR", "CHF", "NZD", "THB", "VND"};
                    for (String c : codes) ed.putFloat("RATE_" + c, (float) rates.optDouble(c, 1.0));
                    ed.putLong("LAST_UPDATED", System.currentTimeMillis()).apply();
                }
            } catch (Exception e) { Log.e("SettingHelper", "API fail", e); }
        });
    }

    public static double getExchangeRate(Context context, String currencyName) {
        if (currencyName == null || context == null) return 1.0;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String code = currencyName.substring(currencyName.indexOf("(") + 1, currencyName.indexOf(")"));
        return prefs.getFloat("RATE_" + code, 1.0f);
    }

    public static String getCurrencySymbol(String currencyName) {
        if (currencyName == null) return "₱";
        if (currencyName.contains("USD") || currencyName.contains("SGD") || currencyName.contains("AUD") || currencyName.contains("CAD") || currencyName.contains("NZD")) return "$";
        if (currencyName.contains("EUR")) return "€";
        if (currencyName.contains("JPY") || currencyName.contains("CNY")) return "¥";
        if (currencyName.contains("GBP")) return "£";
        if (currencyName.contains("KRW")) return "₩";
        if (currencyName.contains("INR")) return "₹";
        if (currencyName.contains("THB")) return "฿";
        if (currencyName.contains("VND")) return "₫";
        return "₱";
    }

    public static String formatAmount(Context context, double amountInPHP) {
        String curr = getCurrency(context);
        double converted = amountInPHP * getExchangeRate(context, curr);
        return getCurrencySymbol(curr) + String.format(java.util.Locale.getDefault(), "%,.2f", converted);
    }

    public static double convertToBasePHP(Context context, double inputAmount) {
        return inputAmount / getExchangeRate(context, getCurrency(context));
    }
}