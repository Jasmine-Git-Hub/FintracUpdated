package com.example.fintrac;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("ClassEscapesDefinedScope")
public class BillsAdapter extends RecyclerView.Adapter<BillsAdapter.BillViewHolder> {

    private final List<Bill> bills = new ArrayList<>();
    private final BillActionListener listener;
    private final Context context;

    public interface BillActionListener {
        void onBillPaid(Bill bill, int position);
        void onBillEdit(Bill bill, int position);
        void onBillDelete(Bill bill, int position);
    }

    public BillsAdapter(List<Bill> billList, BillActionListener listener) {
        this.bills.addAll(billList);
        this.listener = listener;
        this.context = null;
    }

    public BillsAdapter(Context context, List<Bill> billList, BillActionListener listener) {
        this.context = context;
        this.bills.addAll(billList);
        this.listener = listener;
    }

    public Bill getBillAt(int position) {
        return bills.get(position);
    }

    @NonNull
    @Override
    public BillViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bill, parent, false);
        return new BillViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull BillViewHolder holder, int position) {
        Bill bill = bills.get(position);
        Context context = holder.itemView.getContext();

        SettingHelper.applyTheme(context);

        holder.tvName.setText(bill.name);
        holder.tvCategory.setText(bill.category + " • " + bill.frequency);
        holder.tvDate.setText(bill.dueDate);
        holder.rbPaid.setChecked(bill.isPaid);

        // UPDATED: Kukunin ang base PHP value mula sa DB, tapos ico-convert gamit ang formatAmount()
        double amountVal = 0;
        try {
            String cleanAmount = bill.amount.replaceAll("[^\\d.]", "");
            if (!cleanAmount.isEmpty()) {
                amountVal = Double.parseDouble(cleanAmount);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        holder.tvAmount.setText(SettingHelper.formatAmount(context, amountVal));

        // ===== GRAY OUT LOGIC =====
        if (bill.isPaid) {
            holder.tvName.setPaintFlags(holder.tvName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            holder.itemView.setAlpha(0.5f);
            holder.imgLogo.setAlpha(0.5f);
        } else {
            holder.tvName.setPaintFlags(holder.tvName.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG);
            holder.itemView.setAlpha(1.0f);
            holder.imgLogo.setAlpha(1.0f);
        }

        if (bill.logoResId != 0) {
            holder.imgLogo.setImageResource(bill.logoResId);
            holder.imgLogo.setVisibility(View.VISIBLE);
        } else {
            holder.imgLogo.setVisibility(View.INVISIBLE);
        }

        holder.rbPaid.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos != RecyclerView.NO_POSITION && listener != null) {
                listener.onBillPaid(bills.get(pos), pos);
            }
        });
    }

    @Override
    public int getItemCount() {
        return bills.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setBills(List<Bill> newBills) {
        bills.clear();
        bills.addAll(newBills);
        notifyDataSetChanged();
    }

    public void billPaid(int position, boolean isPaid) {
        if (position != RecyclerView.NO_POSITION) {
            bills.get(position).isPaid = isPaid;
            notifyItemChanged(position);
        }
    }

    static class BillViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvCategory, tvAmount, tvDate;
        ImageView imgLogo;
        RadioButton rbPaid;

        public BillViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tvBillName);
            tvCategory = itemView.findViewById(R.id.tvCategory);
            tvAmount = itemView.findViewById(R.id.tvBillAmount);
            tvDate = itemView.findViewById(R.id.tvDueDate);
            imgLogo = itemView.findViewById(R.id.ivBillLogo);
            rbPaid = itemView.findViewById(R.id.rbSelect);
        }
    }
}