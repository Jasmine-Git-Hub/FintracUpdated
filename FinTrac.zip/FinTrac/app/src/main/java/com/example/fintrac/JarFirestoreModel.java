// File: JarFirestoreModel.java
package com.example.fintrac;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.Exclude;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JarFirestoreModel implements Serializable {
    private String id;
    private String name;
    private String type;
    private double savedAmount;
    private double goalAmount;
    private String daysLeft;
    private String weekly;
    private String iconName;
    private int jarColor;
    private String createdBy;
    private Timestamp createdAt;
    private List<String> participants;
    private Map<String, Double> participantContributions;
    private List<JarTransaction> transactions;

    public JarFirestoreModel() {
        // Required empty constructor for Firestore
    }

    // FIXED CONSTRUCTOR - Properly handles parameters
    public JarFirestoreModel(String id, String name, String type, double savedAmount, double goalAmount,
                             String daysLeft, String weekly, String iconName, int jarColor,
                             String createdBy) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.savedAmount = savedAmount;
        this.goalAmount = goalAmount;
        this.daysLeft = daysLeft != null ? daysLeft : "New";
        this.weekly = weekly != null ? weekly : "";
        this.iconName = iconName != null ? iconName : "hat";
        this.jarColor = jarColor;
        this.createdBy = createdBy;
        this.createdAt = Timestamp.now();

        // Initialize collections
        this.participants = new ArrayList<>();
        this.participantContributions = new HashMap<>();
        this.transactions = new ArrayList<>();

        // Add creator as participant if createdBy is not null
        if (createdBy != null && !createdBy.isEmpty()) {
            this.participants.add(createdBy);
            this.participantContributions.put(createdBy, savedAmount);
        }
    }

    @Exclude
    public JarItem toJarItem() {
        return new JarItem(
                this.id != null ? this.id : "",
                this.name != null ? this.name : "",
                this.type != null ? this.type : "Flexible",
                this.savedAmount,
                this.goalAmount,
                this.daysLeft != null ? this.daysLeft : "New",
                this.weekly != null ? this.weekly : "",
                this.iconName != null ? this.iconName : "hat",
                this.jarColor
        );
    }

    // Getters and Setters with null safety
    public String getId() { return id != null ? id : ""; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name != null ? name : ""; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type != null ? type : "Flexible"; }
    public void setType(String type) { this.type = type; }

    public double getSavedAmount() { return savedAmount; }
    public void setSavedAmount(double savedAmount) { this.savedAmount = savedAmount; }

    public double getGoalAmount() { return goalAmount; }
    public void setGoalAmount(double goalAmount) { this.goalAmount = goalAmount; }

    public String getDaysLeft() { return daysLeft != null ? daysLeft : "New"; }
    public void setDaysLeft(String daysLeft) { this.daysLeft = daysLeft; }

    public String getWeekly() { return weekly != null ? weekly : ""; }
    public void setWeekly(String weekly) { this.weekly = weekly; }

    public String getIconName() { return iconName != null ? iconName : "hat"; }
    public void setIconName(String iconName) { this.iconName = iconName; }

    public int getJarColor() { return jarColor; }
    public void setJarColor(int jarColor) { this.jarColor = jarColor; }

    public String getCreatedBy() { return createdBy != null ? createdBy : ""; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public Timestamp getCreatedAt() { return createdAt; }
    public void setCreatedAt(Timestamp createdAt) { this.createdAt = createdAt; }

    public List<String> getParticipants() {
        if (participants == null) participants = new ArrayList<>();
        return participants;
    }
    public void setParticipants(List<String> participants) { this.participants = participants; }

    public Map<String, Double> getParticipantContributions() {
        if (participantContributions == null) participantContributions = new HashMap<>();
        return participantContributions;
    }
    public void setParticipantContributions(Map<String, Double> participantContributions) {
        this.participantContributions = participantContributions;
    }

    public List<JarTransaction> getTransactions() {
        if (transactions == null) transactions = new ArrayList<>();
        return transactions;
    }
    public void setTransactions(List<JarTransaction> transactions) {
        this.transactions = transactions;
    }
}