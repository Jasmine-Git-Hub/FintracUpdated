package com.example.fintrac;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.RecyclerView;

public class SwipeToDeleteCallback extends ItemTouchHelper.SimpleCallback {
    private final JarAdapter mAdapter;
    private final Drawable deleteIcon;
    private final Paint backgroundPaint;
    private final int iconMargin;

    public SwipeToDeleteCallback(Context context, JarAdapter adapter) {
        super(0, ItemTouchHelper.LEFT);
        mAdapter = adapter;

        deleteIcon = ContextCompat.getDrawable(context, android.R.drawable.ic_menu_delete);
        backgroundPaint = new Paint();
        backgroundPaint.setColor(Color.parseColor("#FF4444")); // Red color
        iconMargin = (int) (context.getResources().getDisplayMetrics().density * 16);
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView,
                          @NonNull RecyclerView.ViewHolder viewHolder,
                          @NonNull RecyclerView.ViewHolder target) {
        return false; // We don't want move functionality
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
        int position = viewHolder.getBindingAdapterPosition();
        if (position != RecyclerView.NO_POSITION) {
            mAdapter.onItemSwipe(position);
        }
    }

    @Override
    public void onChildDraw(@NonNull Canvas c, @NonNull RecyclerView recyclerView,
                            @NonNull RecyclerView.ViewHolder viewHolder,
                            float dX, float dY, int actionState, boolean isCurrentlyActive) {

        View itemView = viewHolder.itemView;

        if (actionState == ItemTouchHelper.ACTION_STATE_SWIPE) {
            float height = (float) itemView.getBottom() - (float) itemView.getTop();
            float width = height / 3;

            if (dX < 0) { // Swiping to the left
                // Draw red background
                RectF background = new RectF(
                        (float) itemView.getRight() + dX,
                        (float) itemView.getTop(),
                        (float) itemView.getRight(),
                        (float) itemView.getBottom()
                );
                c.drawRect(background, backgroundPaint);

                // Calculate icon position
                float iconTop = itemView.getTop() + (height - width) / 2;
                float iconBottom = iconTop + width;
                float iconLeft = itemView.getRight() - iconMargin - width;
                float iconRight = itemView.getRight() - iconMargin;

                // Draw delete icon
                if (deleteIcon != null) {
                    deleteIcon.setBounds((int) iconLeft, (int) iconTop, (int) iconRight, (int) iconBottom);
                    deleteIcon.draw(c);
                }
            }
            super.onChildDraw(c, recyclerView, viewHolder, dX, dY, actionState, isCurrentlyActive);
        }
    }

    @Override
    public float getSwipeThreshold(@NonNull RecyclerView.ViewHolder viewHolder) {
        return 0.7f; // Adjust this value to control how far you need to swipe
    }
}