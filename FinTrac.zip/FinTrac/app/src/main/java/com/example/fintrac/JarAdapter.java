package com.example.fintrac;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class JarAdapter extends RecyclerView.Adapter<JarAdapter.JarViewHolder> {
    private List<JarItem> jarList;
    private final Context context;
    private final ActivityResultLauncher<Intent> launcher;
    private OnItemSwipeListener swipeListener;

    // Interface for swipe deletion
    public interface OnItemSwipeListener {
        void onItemSwipe(JarItem jarItem, int position);
    }

    public JarAdapter(Context context, List<JarItem> jarList, ActivityResultLauncher<Intent> launcher) {
        this.context = context;
        this.jarList = jarList;
        this.launcher = launcher;

        // Initialize swipe listener - context should implement the interface
        if (context instanceof OnItemSwipeListener) {
            this.swipeListener = (OnItemSwipeListener) context;
        }
    }

    @NonNull
    @Override
    public JarViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_jar, parent, false);
        return new JarViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull JarViewHolder holder, int position) {
        JarItem jar = jarList.get(position);

        holder.jarTitle.setText(jar.getName());
        holder.jarTypeBadge.setText(jar.getType());

        int progress = jar.getProgressPercentage();
        holder.progressBar.setMax(100);
        holder.progressBar.setProgress(progress);

        // Use string resource with placeholder
        String progressText = context.getString(R.string.percent_complete, progress);
        holder.progressPercentage.setText(progressText);

        // Format dynamically using Base PHP amounts
        holder.savedAmount.setText(SettingHelper.formatAmount(context, jar.getSavedAmount()));
        holder.goalAmount.setText(SettingHelper.formatAmount(context, jar.getGoalAmount()));

        double weeklyVal = jar.getGoalAmount() / 52.0;

        // Use string resource with placeholder for weekly amount
        String weeklyText = context.getString(R.string.weekly_amount_format,
                SettingHelper.formatAmount(context, weeklyVal));
        holder.weeklyAmount.setText(weeklyText);

        holder.daysLeft.setText(jar.getDaysLeft());

        holder.jarIcon.setImageResource(getIconResourceId(jar.getIconName()));
        holder.jarIcon.setBackgroundTintList(ColorStateList.valueOf(jar.getJarColor()));
        holder.progressBar.setProgressTintList(ColorStateList.valueOf(jar.getJarColor()));

        setBadgeColor(holder.jarTypeBadge, jar.getType());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, SharedJarsDetails.class);
            intent.putExtra("JAR_ID", jar.getId());
            intent.putExtra("JAR_NAME", jar.getName());
            intent.putExtra("JAR_SAVED", jar.getSavedAmount());
            intent.putExtra("JAR_GOAL", jar.getGoalAmount());
            intent.putExtra("ICON_NAME", jar.getIconName());
            intent.putExtra("COLOR", jar.getJarColor());
            intent.putExtra("JAR_TYPE", jar.getType());

            if (launcher != null) {
                launcher.launch(intent);
            } else {
                context.startActivity(intent);
            }
        });
    }

    private void setBadgeColor(TextView badge, String type) {
        if (type.equalsIgnoreCase("Mandatory")) {
            badge.setBackgroundResource(R.drawable.bg_mandatory_badge);
        } else if (type.equalsIgnoreCase("Flexible")) {
            badge.setBackgroundResource(R.drawable.bg_flexible_badge);
        } else {
            badge.setBackgroundResource(R.drawable.bg_shared_badge);
        }
    }

    @Override
    public int getItemCount() {
        return jarList != null ? jarList.size() : 0;
    }

    public void updateJarList(List<JarItem> newList) {
        this.jarList = newList;
        notifyDataSetChanged();
    }

    private int getIconResourceId(String iconName) {
        if (iconName == null) return R.drawable.hat;
        switch (iconName) {
            case "house": return R.drawable.house;
            case "airplane": return R.drawable.airplane;
            case "laptop": return R.drawable.laptop;
            case "car": return R.drawable.car;
            case "controller": return R.drawable.controller;
            case "tshirt": return R.drawable.tshirt;
            case "book": return R.drawable.book;
            case "burger": return R.drawable.burger;
            case "ic_gift": return R.drawable.ic_gift;
            default: return R.drawable.hat;
        }
    }

    // Method to handle swipe deletion
    public void onItemSwipe(int position) {
        if (position >= 0 && position < getItemCount()) {
            JarItem swipedJar = jarList.get(position);
            if (swipeListener != null) {
                swipeListener.onItemSwipe(swipedJar, position);
            }
        }
    }

    // Set the swipe listener manually (alternative method)
    public void setSwipeListener(OnItemSwipeListener listener) {
        this.swipeListener = listener;
    }

    public static class JarViewHolder extends RecyclerView.ViewHolder {
        TextView jarTitle, jarTypeBadge, savedAmount, goalAmount, daysLeft, weeklyAmount, progressPercentage;
        ProgressBar progressBar;
        ImageView jarIcon;

        public JarViewHolder(@NonNull View itemView) {
            super(itemView);
            jarTitle = itemView.findViewById(R.id.jar_title);
            jarTypeBadge = itemView.findViewById(R.id.jar_type_badge);
            savedAmount = itemView.findViewById(R.id.saved_amount);
            goalAmount = itemView.findViewById(R.id.goal_amount);
            daysLeft = itemView.findViewById(R.id.days_left);
            weeklyAmount = itemView.findViewById(R.id.weekly_amount);
            progressBar = itemView.findViewById(R.id.progress_bar);
            jarIcon = itemView.findViewById(R.id.jar_icon);
            progressPercentage = itemView.findViewById(R.id.progress_percentage);
        }
    }
}