package com.example.fintrac;

import java.io.Serializable;

public class JarItem implements Serializable {
    private final String id;
    private final String name;
    private final String type;
    private double savedAmount; // UPDATED to double
    private final double goalAmount; // UPDATED to double
    private final String daysLeft;
    private final String weekly;
    private final String iconName;
    private final int jarColor;

    public JarItem(String id, String name, String type, double savedAmount, double goalAmount,
                   String daysLeft, String weekly, String iconName, int jarColor) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.savedAmount = savedAmount;
        this.goalAmount = goalAmount;
        this.daysLeft = daysLeft;
        this.weekly = weekly;
        this.iconName = iconName;
        this.jarColor = jarColor;
    }

    // Setters allowing updates
    public void setSavedAmount(double amount) {
        this.savedAmount = amount;
    }

    public void addSavedAmount(double amount) {
        this.savedAmount += amount;
    }

    // Accurate Progress Calculation
    public int getProgressPercentage() {
        if (goalAmount <= 0) return 0;
        double percentage = (savedAmount / goalAmount) * 100;
        return (int) Math.min(percentage, 100);
    }

    // Getters
    public String getId() { return id; }
    public String getName() { return name; }
    public String getType() { return type; }
    public double getSavedAmount() { return savedAmount; }
    public double getGoalAmount() { return goalAmount; }
    public String getDaysLeft() { return daysLeft; }
    public String getWeekly() { return weekly; }
    public String getIconName() { return iconName; }
    public int getJarColor() { return jarColor; }
}