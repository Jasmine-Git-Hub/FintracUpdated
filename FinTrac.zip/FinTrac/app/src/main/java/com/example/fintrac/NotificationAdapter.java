package com.example.fintrac;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<NotificationItem> notifications;
    private Context context;
    private OnNotificationActionListener listener;

    public interface OnNotificationActionListener {
        void onAcceptInvite(NotificationItem notification);
        void onDeclineInvite(NotificationItem notification);
        void onNotificationClick(NotificationItem notification);
        void onMarkAsRead(NotificationItem notification);
    }

    public NotificationAdapter(Context context, List<NotificationItem> notifications,
                               OnNotificationActionListener listener) {
        this.context = context;
        this.notifications = notifications;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NotificationItem notification = notifications.get(position);

        // Set title and message
        holder.title.setText(notification.getTitle());
        holder.message.setText(notification.getMessage());

        // Set time ago
        holder.timeText.setText(getTimeAgo(notification.getTimestamp()));

        // Set icon based on notification type
        int iconResId;
        int iconColor;
        switch (notification.getType()) {
            case "JAR_INVITE":
                iconResId = R.drawable.ic_add_person;
                iconColor = R.color.blue;
                holder.actionButtons.setVisibility(View.VISIBLE);
                holder.btnAccept.setVisibility(View.VISIBLE);
                holder.btnDecline.setVisibility(View.VISIBLE);
                break;
            case "BILL_DUE":
                iconResId = R.drawable.ic_visual_reports;
                iconColor = R.color.red;
                holder.actionButtons.setVisibility(View.GONE);
                break;
            case "JAR_GOAL_REACHED":
                iconResId = R.drawable.ic_goal;
                iconColor = R.color.green;
                holder.actionButtons.setVisibility(View.GONE);
                break;
            default:
                iconResId = R.drawable.ic_notifications;
                iconColor = R.color.gray;
                holder.actionButtons.setVisibility(View.GONE);
                break;
        }

        holder.icon.setImageResource(iconResId);
        holder.iconCard.setCardBackgroundColor(ContextCompat.getColor(context, iconColor));

        // Show unread indicator
        holder.unreadIndicator.setVisibility(notification.isRead() ? View.GONE : View.VISIBLE);

        // Set click listeners
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onNotificationClick(notification);
            }
        });

        // Accept button click
        if (holder.btnAccept != null) {
            holder.btnAccept.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onAcceptInvite(notification);
                }
            });
        }

        // Decline button click
        if (holder.btnDecline != null) {
            holder.btnDecline.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onDeclineInvite(notification);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return notifications.size();
    }

    private String getTimeAgo(Date date) {
        if (date == null) return "";

        long now = System.currentTimeMillis();
        long diff = now - date.getTime();
        long seconds = TimeUnit.MILLISECONDS.toSeconds(diff);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(diff);
        long hours = TimeUnit.MILLISECONDS.toHours(diff);
        long days = TimeUnit.MILLISECONDS.toDays(diff);

        if (seconds < 60) {
            return "Just now";
        } else if (minutes < 60) {
            return minutes + "m ago";
        } else if (hours < 24) {
            return hours + "h ago";
        } else if (days < 7) {
            return days + "d ago";
        } else {
            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd", Locale.getDefault());
            return sdf.format(date);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CardView iconCard;
        ImageView icon;
        TextView title, message, timeText;
        LinearLayout actionButtons;
        MaterialButton btnAccept, btnDecline;
        View unreadIndicator;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            iconCard = itemView.findViewById(R.id.icon_card);
            icon = itemView.findViewById(R.id.notification_icon);
            title = itemView.findViewById(R.id.notification_title);
            message = itemView.findViewById(R.id.notification_message);
            timeText = itemView.findViewById(R.id.time_text);
            actionButtons = itemView.findViewById(R.id.action_buttons_container);
            btnAccept = itemView.findViewById(R.id.btn_accept);
            btnDecline = itemView.findViewById(R.id.btn_decline);
            unreadIndicator = itemView.findViewById(R.id.unread_indicator);
        }
    }
}