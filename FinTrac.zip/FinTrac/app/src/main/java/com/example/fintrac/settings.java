package com.example.fintrac;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.switchmaterial.SwitchMaterial;
import com.google.firebase.auth.FirebaseAuth;

public class settings extends Fragment {

    // Views
    private TextView tvSelectedCurrency;
    private MaterialCardView cardCurrencySelector;
    private MaterialCardView btnLogout;
    private TextView btnEditProfile, btnChangePassword;
    private SwitchMaterial switchDarkMode;
    private SwitchMaterial switchPushNotifications; // Variable para sa Push Notifications

    // Theme Buttons
    private Button btnOceanBlue, btnForestGreen, btnRoyalPurple, btnSunsetOrange;

    // Currency Data
    private final String[] currencies = {
            "Philippine Peso (PHP)", "US Dollar (USD)", "Euro (EUR)",
            "Japanese Yen (JPY)", "British Pound (GBP)", "South Korean Won (KRW)",
            "Singapore Dollar (SGD)", "Australian Dollar (AUD)", "Canadian Dollar (CAD)",
            "Chinese Yuan (CNY)", "Indian Rupee (INR)", "Swiss Franc (CHF)",
            "New Zealand Dollar (NZD)", "Thai Baht (THB)", "Vietnamese Dong (VND)"
    };

    private int selectedCurrencyIndex = 0;

    public settings() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        // 1. Initialize Views
        tvSelectedCurrency = view.findViewById(R.id.tvSelectedCurrency);
        cardCurrencySelector = view.findViewById(R.id.cardCurrencySelector);
        btnLogout = view.findViewById(R.id.btnLogout);
        btnEditProfile = view.findViewById(R.id.btnEditProfile);
        btnChangePassword = view.findViewById(R.id.btnChangePassword);
        switchDarkMode = view.findViewById(R.id.switchDarkMode);

        // TUGMA NA YUNG ID DITO SA NASA XML MO:
        switchPushNotifications = view.findViewById(R.id.switchNotifications);

        // Initialize Theme Color Buttons
        btnOceanBlue = view.findViewById(R.id.btnOceanBlue);
        btnForestGreen = view.findViewById(R.id.btnForestGreen);
        btnRoyalPurple = view.findViewById(R.id.btnRoyalPurple);
        btnSunsetOrange = view.findViewById(R.id.btnSunsetOrange);

        // --- A. LOAD SAVED DATA (Currency) ---
        if (getContext() != null) {
            String savedCurrency = SettingHelper.getCurrency(getContext());
            tvSelectedCurrency.setText(savedCurrency);

            for (int i = 0; i < currencies.length; i++) {
                if (currencies[i].equals(savedCurrency)) {
                    selectedCurrencyIndex = i;
                    break;
                }
            }
        }

        // --- B. DARK MODE LOGIC ---
        if (switchDarkMode != null) {
            boolean isDark = SettingHelper.isDarkMode(getContext());
            switchDarkMode.setChecked(isDark);

            switchDarkMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (getContext() != null) {
                    SettingHelper.saveDarkModeSetting(getContext(), isChecked);
                    if (getActivity() != null) getActivity().recreate();
                }
            });
        }

        // --- C. THEME COLOR LOGIC ---
        setupColorButton(btnOceanBlue, R.color.ocean_blue, "Ocean Blue");
        setupColorButton(btnForestGreen, R.color.forest_green, "Forest Green");
        setupColorButton(btnRoyalPurple, R.color.royal_purple, "Royal Purple");
        setupColorButton(btnSunsetOrange, R.color.sunset_orange, "Sunset Orange");


        // --- D. CURRENCY LOGIC ---
        if (cardCurrencySelector != null) {
            cardCurrencySelector.setOnClickListener(v -> showCurrencyDialog());
        }

        // --- E. LOGOUT LOGIC ---
        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> showLogoutConfirmation());
        }

        // --- F. EDIT PROFILE LOGIC ---
        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivity(intent);
            });
        }

        if (btnChangePassword != null) {
            btnChangePassword.setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(intent);
            });
        }

        // ==========================================
        // --- G. PUSH NOTIFICATIONS LOGIC ---
        // ==========================================
        if (switchPushNotifications != null && getContext() != null) {
            SharedPreferences prefs = getContext().getSharedPreferences("SettingsPrefs", Context.MODE_PRIVATE);
            // Default is TRUE (Naka-ON) pagkabukas ng app for the first time
            boolean isPushEnabled = prefs.getBoolean("push_notifications_enabled", true);

            switchPushNotifications.setChecked(isPushEnabled);

            switchPushNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
                // I-save ang preference kapag tinoggle
                prefs.edit().putBoolean("push_notifications_enabled", isChecked).apply();

                String status = isChecked ? "enabled" : "disabled";
                Toast.makeText(getContext(), "Push Notifications " + status, Toast.LENGTH_SHORT).show();
            });
        }

        return view;
    }

    private void setupColorButton(Button btn, int colorResId, String colorName) {
        if (btn != null) {
            btn.setOnClickListener(v -> {
                if (getContext() != null) {
                    SettingHelper.saveThemeColor(getContext(), colorResId);
                    Toast.makeText(getContext(), "Theme set to " + colorName, Toast.LENGTH_SHORT).show();

                    if (getActivity() != null) {
                        getActivity().recreate();
                    }
                }
            });
        }
    }

    private void showCurrencyDialog() {
        if (getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Select Currency");

        builder.setSingleChoiceItems(currencies, selectedCurrencyIndex, (dialog, which) -> {
            selectedCurrencyIndex = which;
            String selected = currencies[which];

            if (tvSelectedCurrency != null) {
                tvSelectedCurrency.setText(selected);
            }

            SettingHelper.saveCurrency(getContext(), selected);

            Toast.makeText(getContext(), "Currency updated to " + selected, Toast.LENGTH_SHORT).show();
            dialog.dismiss();
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void showLogoutConfirmation() {
        new AlertDialog.Builder(getContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to log out?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    FirebaseAuth.getInstance().signOut();

                    Toast.makeText(getContext(), "Logged out successfully", Toast.LENGTH_SHORT).show();

                    if (getActivity() != null) {
                        Intent intent = new Intent(getActivity(), LogIn.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                        getActivity().finish();
                    }
                })
                .setNegativeButton("No", null)
                .show();
    }
}