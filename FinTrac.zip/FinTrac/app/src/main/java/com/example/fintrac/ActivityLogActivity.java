package com.example.fintrac;

import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ActivityLogActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SettingHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_log);

        // Setup Back Button
        ImageButton backButton = findViewById(R.id.back_button);
        if (backButton != null) {
            backButton.setOnClickListener(v -> finish());
        }

        // Setup Views
        TextView titleView = findViewById(R.id.title_text);
        TextView messageView = findViewById(R.id.message);

        // Get Data from Intent
        String jarName = getIntent().getStringExtra("JAR_NAME");
        if (titleView != null && jarName != null) {
            titleView.setText(jarName + " - Activity Log");
        }

        ArrayList<String> logs = getIntent().getStringArrayListExtra("LOGS");

        if (messageView != null) {
            if (logs != null && !logs.isEmpty()) {
                StringBuilder sb = new StringBuilder();
                for (String log : logs) {
                    sb.append("• ").append(log).append("\n\n");
                }
                messageView.setText(sb.toString());
            } else {
                messageView.setText("No activity recorded yet.\n\n" +
                        "Add money to your jar or invite participants to see activity here.");
            }
        }
    }
}