package com.example.fintrac;

import android.content.Context;
import android.content.SharedPreferences;
import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyHelper {
    private static final String PREF_NAME = "AppPreferences";
    private static final String KEY_CURRENCY = "selected_currency";

    // Save Currency Choice (e.g., "PHP", "USD")
    public static void setCurrency(Context context, String currencyCode) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putString(KEY_CURRENCY, currencyCode).apply();
    }

    // Get Current Currency Code
    public static String getCurrencyCode(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getString(KEY_CURRENCY, "PHP"); // Default is PHP
    }

    // Format Amount (e.g., converts 500.0 to "₱500.00" or "$500.00")
    public static String formatAmount(Context context, double amount) {
        String code = getCurrencyCode(context);
        Locale locale;

        switch (code) {
            case "USD": locale = Locale.US; break;
            case "EUR": locale = Locale.GERMANY; break;
            case "GBP": locale = Locale.UK; break;
            case "JPY": locale = Locale.JAPAN; break;
            case "INR": locale = new Locale("en", "IN"); break; // India
            default:    locale = new Locale("en", "PH"); break; // Philippines (Default)
        }

        NumberFormat format = NumberFormat.getCurrencyInstance(locale);
        return format.format(amount);
    }
}