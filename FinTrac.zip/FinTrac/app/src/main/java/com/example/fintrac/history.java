package com.example.fintrac;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class history extends Fragment {

    private ChipGroup chipGroupFilter;
    private TextView tvTransactionCount;
    private RecyclerView rvHistory;
    private HistoryAdapter adapter;
    private List<Transaction> allTransactions;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private FirebaseUser currentUser;

    private String currentFilter = "all";

    public history() { }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        SettingHelper.applyTheme(requireActivity());
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        currentUser = mAuth.getCurrentUser();

        if (currentUser == null) {
            Toast.makeText(requireContext(), "User not logged in", Toast.LENGTH_SHORT).show();
            return;
        }

        chipGroupFilter = view.findViewById(R.id.chipGroupFilter);
        tvTransactionCount = view.findViewById(R.id.tvTransactionCount);
        rvHistory = view.findViewById(R.id.rvHistory);

        allTransactions = new ArrayList<>();
        rvHistory.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new HistoryAdapter(new ArrayList<>(), requireContext());
        rvHistory.setAdapter(adapter);

        loadAllHistory();

        chipGroupFilter.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (!checkedIds.isEmpty()) {
                int id = checkedIds.get(0);
                if (id == R.id.chipAll) {
                    currentFilter = "all";
                } else if (id == R.id.chipIncome) {
                    currentFilter = "income";
                } else if (id == R.id.chipExpense) {
                    currentFilter = "expense";
                }
                filterList();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (currentUser != null) {
            loadAllHistory();
        }
    }

    private void loadAllHistory() {
        if (currentUser == null) return;

        allTransactions.clear();

        // Show loading state
        tvTransactionCount.setText("Loading...");

        String userId = currentUser.getUid();

        // We'll track completion of all fetches
        AtomicInteger pendingFetches = new AtomicInteger(3); // transactions, bills, jars

        Runnable checkAndSort = () -> {
            if (pendingFetches.decrementAndGet() == 0) {
                // Sort all transactions by date (newest first)
                Collections.sort(allTransactions, (t1, t2) -> {
                    Date d1 = getDateFromTransaction(t1);
                    Date d2 = getDateFromTransaction(t2);
                    if (d1 != null && d2 != null) {
                        return d2.compareTo(d1);
                    }
                    return 0;
                });

                requireActivity().runOnUiThread(() -> {
                    Log.d("HistoryFragment", "Total items loaded: " + allTransactions.size());
                    if (allTransactions.isEmpty()) {
                        Toast.makeText(requireContext(), "No history found", Toast.LENGTH_SHORT).show();
                    }
                    filterList();
                });
            }
        };

        // 1. Load regular transactions
        loadTransactions(userId, pendingFetches, checkAndSort);

        // 2. Load bills (as expense transactions)
        loadBillsAsTransactions(userId, pendingFetches, checkAndSort);

        // 3. Load jar activities from all jars user participates in
        loadJarActivities(userId, pendingFetches, checkAndSort);
    }

    private Date getDateFromTransaction(Transaction t) {
        if (t.getTimestamp() != null) {
            return t.getTimestamp().toDate();
        } else if (t.getDate() != null) {
            return t.getDate();
        }
        return new Date();
    }

    private void loadTransactions(String userId, AtomicInteger pendingFetches, Runnable completionCallback) {
        db.collection("users").document(userId).collection("transactions")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                Transaction item = document.toObject(Transaction.class);
                                item.setId(document.getId());
                                allTransactions.add(item);
                                Log.d("HistoryFragment", "Loaded transaction: " + item.getTitle());
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping transaction", e);
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private void loadBillsAsTransactions(String userId, AtomicInteger pendingFetches, Runnable completionCallback) {
        db.collection("users").document(userId).collection("bills")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                Transaction billTransaction = createTransactionFromBill(document, userId);
                                if (billTransaction != null) {
                                    allTransactions.add(billTransaction);
                                    Log.d("HistoryFragment", "Loaded bill: " + billTransaction.getTitle());
                                }
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping bill", e);
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private Transaction createTransactionFromBill(QueryDocumentSnapshot document, String userId) {
        try {
            String billName = document.getString("name");
            String category = document.getString("category");
            String amountStr = document.getString("amount");
            Boolean isPaid = document.getBoolean("isPaid");

            // Only show paid bills in history
            if (isPaid != null && isPaid && billName != null && amountStr != null) {
                double amount = 0;
                try {
                    String cleanAmount = amountStr.replaceAll("[^\\d.]", "");
                    if (!cleanAmount.isEmpty()) {
                        amount = Double.parseDouble(cleanAmount);
                    }
                } catch (NumberFormatException e) {
                    Log.e("HistoryFragment", "Error parsing bill amount", e);
                }

                Transaction transaction = new Transaction();
                transaction.setId("bill_" + document.getId());
                transaction.setTitle("Paid Bill: " + billName);
                transaction.setDescription(category != null ? category : "Bill Payment");
                transaction.setCategory("Bills");
                transaction.setAmount(amount);
                transaction.setExpense(true);
                transaction.setUserId(userId);
                transaction.setDate(new Date());
                transaction.setTimestamp(new Timestamp(new Date()));

                return transaction;
            }
        } catch (Exception e) {
            Log.e("HistoryFragment", "Error creating bill transaction", e);
        }
        return null;
    }

    private void loadJarActivities(String userId, AtomicInteger pendingFetches, Runnable completionCallback) {
        // First try: Load from main jars collection (where user is participant)
        db.collection("jars")
                .whereArrayContains("participants", userId)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                JarFirestoreModel jar = document.toObject(JarFirestoreModel.class);
                                jar.setId(document.getId());

                                // Get jar creation transaction
                                Transaction jarCreationTx = createJarCreationTransaction(jar, userId);
                                if (jarCreationTx != null) {
                                    allTransactions.add(jarCreationTx);
                                }

                                // Get individual jar transactions from the jar's transaction list
                                List<Transaction> jarTransactions = createTransactionsFromJar(jar, userId);
                                allTransactions.addAll(jarTransactions);

                                Log.d("HistoryFragment", "Loaded jar: " + jar.getName());
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping jar", e);
                            }
                        }
                    }

                    // Second try: Load from user's jars subcollection
                    loadJarsFromSubcollection(userId, pendingFetches, completionCallback);
                });
    }

    private void loadJarsFromSubcollection(String userId, AtomicInteger pendingFetches, Runnable completionCallback) {
        db.collection("users").document(userId).collection("jars")
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful() && task.getResult() != null) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            try {
                                JarFirestoreModel jar = document.toObject(JarFirestoreModel.class);
                                jar.setId(document.getId());

                                Transaction jarCreationTx = createJarCreationTransaction(jar, userId);
                                if (jarCreationTx != null) {
                                    allTransactions.add(jarCreationTx);
                                }

                                List<Transaction> jarTransactions = createTransactionsFromJar(jar, userId);
                                allTransactions.addAll(jarTransactions);

                                Log.d("HistoryFragment", "Loaded jar from subcollection: " + jar.getName());
                            } catch (Exception e) {
                                Log.e("HistoryFragment", "Error mapping jar from subcollection", e);
                            }
                        }
                    }
                    completionCallback.run();
                });
    }

    private Transaction createJarCreationTransaction(JarFirestoreModel jar, String userId) {
        if (jar.getSavedAmount() > 0) {
            Transaction jarCreationTx = new Transaction();
            jarCreationTx.setId("jar_creation_" + jar.getId());
            jarCreationTx.setTitle("Started Jar: " + jar.getName());
            jarCreationTx.setDescription("Initial savings for " + jar.getName());
            jarCreationTx.setCategory(jar.getType() != null ? jar.getType() : "Savings");
            jarCreationTx.setAmount(jar.getSavedAmount());
            jarCreationTx.setExpense(false);
            jarCreationTx.setUserId(userId);

            if (jar.getCreatedAt() != null) {
                jarCreationTx.setTimestamp(jar.getCreatedAt());
            } else {
                jarCreationTx.setDate(new Date());
            }

            return jarCreationTx;
        }
        return null;
    }

    private List<Transaction> createTransactionsFromJar(JarFirestoreModel jar, String userId) {
        List<Transaction> transactions = new ArrayList<>();

        try {
            String jarName = jar.getName();
            String jarId = jar.getId();

            // Get all individual transactions from jar's transaction list
            List<JarTransaction> jarTransactions = jar.getTransactions();
            if (jarTransactions != null && !jarTransactions.isEmpty()) {
                for (int i = 0; i < jarTransactions.size(); i++) {
                    JarTransaction jarTx = jarTransactions.get(i);

                    // Only show transactions by this user
                    if (userId.equals(jarTx.getUserId())) {
                        Transaction tx = new Transaction();
                        tx.setId("jar_tx_" + jarId + "_" + i);

                        // Use jarName from the transaction if available, otherwise use the jar's name
                        String txJarName = jarTx.getJarName();
                        if (txJarName == null || txJarName.isEmpty()) {
                            txJarName = jarName;
                        }

                        tx.setTitle("Added to Jar: " + txJarName);

                        // Use note as description
                        String note = jarTx.getNote();
                        tx.setDescription(note != null && !note.isEmpty() ? note : "Savings contribution");

                        tx.setCategory(jar.getType() != null ? jar.getType() : "Savings");
                        tx.setAmount(jarTx.getAmount());
                        tx.setExpense(false); // Adding to jar is positive
                        tx.setUserId(userId);

                        if (jarTx.getTimestamp() != null) {
                            tx.setTimestamp(jarTx.getTimestamp());
                            tx.setDate(jarTx.getTimestamp().toDate());
                        } else {
                            tx.setDate(new Date());
                            tx.setTimestamp(new Timestamp(new Date()));
                        }

                        transactions.add(tx);
                    }
                }
            }
        } catch (Exception e) {
            Log.e("HistoryFragment", "Error creating jar transactions", e);
        }

        return transactions;
    }

    private void filterList() {
        List<Transaction> filteredList = new ArrayList<>();

        for (Transaction item : allTransactions) {
            if (currentFilter.equals("all")) {
                filteredList.add(item);
            } else if (currentFilter.equals("income") && !item.isExpense()) {
                filteredList.add(item);
            } else if (currentFilter.equals("expense") && item.isExpense()) {
                filteredList.add(item);
            }
        }

        adapter.setTransactions(filteredList);

        String text = filteredList.size() == 1 ? "1 transaction" : filteredList.size() + " transactions";
        tvTransactionCount.setText(text);

        Log.d("HistoryFragment", "Filtered list: " + filteredList.size() + " items");
    }
}