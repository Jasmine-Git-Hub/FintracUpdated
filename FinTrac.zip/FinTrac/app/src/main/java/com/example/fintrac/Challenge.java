package com.example.fintrac;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Challenge extends Fragment implements ChallengeAdapter.OnChallengeActionListener {

    private RecyclerView recyclerView;
    private ChallengeAdapter adapter;
    private List<ChallengeItem> challengeList;
    private FirebaseFirestore db;
    private final String userID = "Ny8KvFodm8OLbVokBeEquoGzglH3"; // Palitan mo na lang pag may Auth na

    // Dinagdag para sa dynamic top cards
    private TextView tvActiveCount;
    private TextView tvSavedTotal;

    // Quick start cards
    private MaterialCardView cardNoCafe;
    private MaterialCardView cardDaily20Pesos;

    public Challenge() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_challenge, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        db = FirebaseFirestore.getInstance();

        recyclerView = view.findViewById(R.id.rv_active_challenges);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        tvActiveCount = view.findViewById(R.id.tv_active_count);
        tvSavedTotal = view.findViewById(R.id.tv_saved_total);

        // Initialize quick start cards
        cardNoCafe = view.findViewById(R.id.card_no_cafe);
        cardDaily20Pesos = view.findViewById(R.id.card_daily_20p);

        challengeList = new ArrayList<>();
        adapter = new ChallengeAdapter(challengeList, getContext(), this);
        recyclerView.setAdapter(adapter);

        loadChallengesFromFirebase();

        // Set click listeners for quick start cards
        setupQuickStartClickListeners();

        FloatingActionButton fabAddChallenge = view.findViewById(R.id.fab_add_challenge);
        fabAddChallenge.setOnClickListener(v -> showTemplatesDialogFragment());

        // Update the fragment result listener to handle both template selection and custom challenge creation
        getChildFragmentManager().setFragmentResultListener(TemplatesDialogFragment.REQUEST_KEY, this, (requestKey, result) -> {
            String action = result.getString(TemplatesDialogFragment.KEY_ACTION, "");

            if (TemplatesDialogFragment.ACTION_SELECT_TEMPLATE.equals(action)) {
                // Handle template selection - show custom dialog with pre-filled data
                String name = result.getString(TemplatesDialogFragment.KEY_NAME);
                String desc = result.getString(TemplatesDialogFragment.KEY_DESC);
                int duration = result.getInt(TemplatesDialogFragment.KEY_DURATION);
                double target = result.getDouble(TemplatesDialogFragment.KEY_TARGET);

                // Show custom dialog with pre-filled template data
                showCustomChallengeDialog(name, desc, duration, target);

            } else if (TemplatesDialogFragment.ACTION_CREATE_CUSTOM.equals(action)) {
                // Handle direct custom challenge creation
                String name = result.getString(TemplatesDialogFragment.KEY_NAME);
                String desc = result.getString(TemplatesDialogFragment.KEY_DESC);
                int duration = result.getInt(TemplatesDialogFragment.KEY_DURATION);
                double target = result.getDouble(TemplatesDialogFragment.KEY_TARGET);

                ChallengeItem newChallenge = new ChallengeItem(
                        name, desc, getIconForChallenge(name), getColorForChallenge(name),
                        0, duration, target
                );

                saveChallengeToFirebase(newChallenge);
            }
        });
    }

    private void setupQuickStartClickListeners() {
        // No-Café Week quick start
        cardNoCafe.setOnClickListener(v -> {
            // This matches the first template in TemplatesDialogFragment
            showCustomChallengeDialog(
                    "No-Café Week",
                    "Skip buying coffee for 7 days.",
                    7,
                    1050
            );
        });

        // Daily 20 Pesos quick start
        cardDaily20Pesos.setOnClickListener(v -> {
            // This is a custom quick start that might not be in the templates list
            showCustomChallengeDialog(
                    "Daily 20 Pesos Challenge",
                    "Save 20 pesos every day for 30 days",
                    30,
                    600  // 20 * 30 = 600
            );
        });

        // You can add more quick start cards here if you have them in your layout
    }

    // Method to show custom dialog with pre-filled data
    private void showCustomChallengeDialog(String templateName, String templateDesc, int templateDuration, double templateTarget) {
        CustomChallengeDialogFragment dialog = new CustomChallengeDialogFragment();

        // Pass the template data to the dialog
        Bundle args = new Bundle();
        args.putString("template_name", templateName);
        args.putString("template_desc", templateDesc);
        args.putInt("template_duration", templateDuration);
        args.putDouble("template_target", templateTarget);
        dialog.setArguments(args);

        // Set listener to handle the custom challenge creation
        dialog.setOnCustomChallengeCreatedListener(challenge -> {
            // Create ChallengeItem from the custom challenge (which may be modified by user)
            ChallengeItem newChallenge = new ChallengeItem(
                    challenge.getName(),
                    challenge.getDescription(),
                    getIconForChallenge(challenge.getName()),
                    getColorForChallenge(challenge.getName()),
                    0,
                    challenge.getDurationDays(),
                    challenge.getTargetAmount()
            );

            saveChallengeToFirebase(newChallenge);
        });

        dialog.show(getChildFragmentManager(), "custom_challenge_dialog");
    }

    // Function para kalkulahin at i-update ang dashboard cards
    private void updateSummary() {
        if (tvActiveCount == null || tvSavedTotal == null) return;

        int activeCount = challengeList.size();
        tvActiveCount.setText(String.valueOf(activeCount));

        double totalSavedPHP = 0;
        for (ChallengeItem item : challengeList) {
            if (item.getTotalDays() > 0) {
                // Kalkulahin kung magkano na ang na-save base sa progress percentage
                double amountSaved = item.getTargetAmount() * (item.getProgress() / 100.0);
                totalSavedPHP += amountSaved;
            }
        }

        // I-format nang tama base sa napiling bansa sa settings
        tvSavedTotal.setText(SettingHelper.formatAmount(requireContext(), totalSavedPHP));
    }

    private void loadChallengesFromFirebase() {
        db.collection("users").document(userID).collection("challenges")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    challengeList.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        ChallengeItem item = document.toObject(ChallengeItem.class);
                        item.setDocumentId(document.getId());

                        item.setIconResId(getIconForChallenge(item.getName()));
                        item.setColorResId(getColorForChallenge(item.getName()));
                        item.updateCalculatedFields();

                        challengeList.add(item);
                    }
                    adapter.notifyDataSetChanged();
                    updateSummary(); // Update UI
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Error loading: " + e.getMessage(), Toast.LENGTH_SHORT).show());
    }

    private void saveChallengeToFirebase(ChallengeItem challenge) {
        db.collection("users").document(userID).collection("challenges")
                .add(challenge)
                .addOnSuccessListener(documentReference -> {
                    challenge.setDocumentId(documentReference.getId());
                    challengeList.add(challenge);
                    adapter.notifyItemInserted(challengeList.size() - 1);
                    updateSummary(); // Update UI
                    Toast.makeText(getContext(), "Challenge Started!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to save: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    @Override
    public void onCheckIn(ChallengeItem item, int position) {
        if (item.getDocumentId() == null) return;

        int newDay = item.getCurrentDay() + 1;
        long currentTime = System.currentTimeMillis();

        item.setCurrentDay(newDay);
        item.setLastCheckInTime(currentTime);

        Map<String, Object> updates = new HashMap<>();
        updates.put("currentDay", newDay);
        updates.put("lastCheckInTime", currentTime);

        db.collection("users").document(userID)
                .collection("challenges").document(item.getDocumentId())
                .update(updates)
                .addOnSuccessListener(aVoid -> {
                    adapter.notifyItemChanged(position);
                    updateSummary(); // Update UI after checkin (tataas ang saved amount)
                    Toast.makeText(getContext(), "Checked In!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    item.setCurrentDay(newDay - 1);
                    Toast.makeText(getContext(), "Update failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    @Override
    public void onGiveUp(ChallengeItem item, int position) {
        if (item.getDocumentId() == null) return;

        db.collection("users").document(userID)
                .collection("challenges").document(item.getDocumentId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    challengeList.remove(position);
                    adapter.notifyItemRemoved(position);
                    adapter.notifyItemRangeChanged(position, challengeList.size());
                    updateSummary(); // Update UI
                    Toast.makeText(getContext(), "Challenge Deleted", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Delete failed: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    private void showTemplatesDialogFragment() {
        TemplatesDialogFragment dialog = new TemplatesDialogFragment();
        dialog.show(getChildFragmentManager(), "templates_dialog");
    }

    private int getIconForChallenge(String name) {
        if (name == null) return R.drawable.hat;
        if (name.contains("Café") || name.contains("Coffee")) return R.drawable.coffee;
        if (name.contains("Pesos") || name.contains("Save")) return R.drawable.savings;
        if (name.contains("Food") || name.contains("Eat")) return R.drawable.burger;
        if (name.contains("Transport") || name.contains("Walk")) return R.drawable.airplane;
        return R.drawable.hat;
    }

    private int getColorForChallenge(String name) {
        if (name == null) return R.color.challenge_orange;
        if (name.contains("Café") || name.contains("Coffee")) return R.color.challenge_orange;
        if (name.contains("Pesos") || name.contains("Save")) return R.color.challenge_blue;
        if (name.contains("Food")) return R.color.challenge_red;
        if (name.contains("Transport")) return R.color.challenge_green;
        return R.color.challenge_orange;
    }
}