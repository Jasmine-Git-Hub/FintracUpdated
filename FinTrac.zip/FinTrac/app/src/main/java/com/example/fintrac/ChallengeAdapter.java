package com.example.fintrac;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ChallengeAdapter extends RecyclerView.Adapter<ChallengeAdapter.ChallengeViewHolder> {

    private final List<ChallengeItem> challengeList;
    private final Context context;
    private final OnChallengeActionListener actionListener;

    public interface OnChallengeActionListener {
        void onCheckIn(ChallengeItem item, int position);
        void onGiveUp(ChallengeItem item, int position);
    }

    public ChallengeAdapter(List<ChallengeItem> challengeList, Context context, OnChallengeActionListener listener) {
        this.challengeList = challengeList;
        this.context = context;
        this.actionListener = listener;
    }

    @NonNull
    @Override
    public ChallengeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_challenge, parent, false);
        return new ChallengeViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChallengeViewHolder holder, int position) {
        ChallengeItem item = challengeList.get(position);

        holder.tvName.setText(item.getName());
        holder.tvDesc.setText(item.getDescription());
        holder.pbChallenge.setProgress(item.getProgress());
        holder.tvDaysLeft.setText(item.getDaysLeft());
        holder.tvPercentDone.setText(item.getPercentDone());
        holder.tvProgressStart.setText(item.getProgressStart());
        holder.tvProgressEnd.setText(item.getProgressEnd());

        if (item.getIconResId() != 0) holder.ivIcon.setImageResource(item.getIconResId());
        else holder.ivIcon.setImageResource(android.R.drawable.ic_menu_info_details);

        if (item.getColorResId() != 0) {
            try {
                int color = ContextCompat.getColor(context, item.getColorResId());
                holder.ivIcon.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
            } catch (Exception e) { e.printStackTrace(); }
        }

        holder.itemView.setOnClickListener(v -> showChallengeDetailDialog(item, position));
    }

    private void showChallengeDetailDialog(ChallengeItem challenge, int position) {
        try {
            View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_challenge_detail, null);
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setView(dialogView);
            AlertDialog dialog = builder.create();

            if (dialog.getWindow() != null)
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

            TextView tvName = dialogView.findViewById(R.id.tv_challenge_name);
            TextView tvDesc = dialogView.findViewById(R.id.tv_challenge_description);
            TextView tvProgressPercent = dialogView.findViewById(R.id.tv_progress_percent);
            TextView tvDayProgress = dialogView.findViewById(R.id.tv_day_progress);
            TextView tvDaysLeft = dialogView.findViewById(R.id.tv_days_left);
            TextView tvTotalDays = dialogView.findViewById(R.id.tv_total_days);

            Button btnCheckIn = dialogView.findViewById(R.id.btn_check_in);
            Button btnGiveUp = dialogView.findViewById(R.id.btn_give_up);
            View btnClose = dialogView.findViewById(R.id.btn_close);

            tvName.setText(challenge.getName());
            tvDesc.setText(challenge.getDescription());
            tvProgressPercent.setText(challenge.getProgress() + "%");
            tvDayProgress.setText("Day " + challenge.getCurrentDay() + " / " + challenge.getTotalDays());
            tvDaysLeft.setText(String.valueOf(challenge.getTotalDays() - challenge.getCurrentDay()));
            tvTotalDays.setText(String.valueOf(challenge.getTotalDays()));

            if (!challenge.isCheckInAvailable()) {
                btnCheckIn.setEnabled(false);
                btnCheckIn.setText("Checked in today");
                btnCheckIn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.parseColor("#A9A9A9")));
            } else {
                btnCheckIn.setEnabled(true);
                btnCheckIn.setText("Check In");
            }

            btnCheckIn.setOnClickListener(v -> {
                if (challenge.getCurrentDay() < challenge.getTotalDays()) {
                    actionListener.onCheckIn(challenge, position);
                    dialog.dismiss();
                } else {
                    Toast.makeText(context, "Challenge Completed!", Toast.LENGTH_SHORT).show();
                }
            });

            btnGiveUp.setOnClickListener(v -> {
                new AlertDialog.Builder(context)
                        .setTitle("Give Up?")
                        .setMessage("Are you sure you want to delete this challenge?")
                        .setPositiveButton("Yes", (d, w) -> {
                            actionListener.onGiveUp(challenge, position);
                            dialog.dismiss();
                        })
                        .setNegativeButton("No", null)
                        .show();
            });

            btnClose.setOnClickListener(v -> dialog.dismiss());
            dialog.show();

        } catch (Exception e) { e.printStackTrace(); }
    }

    @Override
    public int getItemCount() { return challengeList.size(); }

    public static class ChallengeViewHolder extends RecyclerView.ViewHolder {
        TextView tvName, tvDesc, tvDaysLeft, tvPercentDone, tvProgressStart, tvProgressEnd;
        ProgressBar pbChallenge;
        ImageView ivIcon;

        public ChallengeViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_challenge_name);
            tvDesc = itemView.findViewById(R.id.tv_challenge_desc);
            tvDaysLeft = itemView.findViewById(R.id.tv_days_left);
            tvPercentDone = itemView.findViewById(R.id.tv_percent_done);
            pbChallenge = itemView.findViewById(R.id.pb_challenge);
            ivIcon = itemView.findViewById(R.id.iv_icon);
            tvProgressStart = itemView.findViewById(R.id.tv_progress_start);
            tvProgressEnd = itemView.findViewById(R.id.tv_progress_end);
        }
    }
}