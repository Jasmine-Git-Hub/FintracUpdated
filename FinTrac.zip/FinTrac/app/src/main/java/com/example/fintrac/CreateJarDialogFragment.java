package com.example.fintrac;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class CreateJarDialogFragment extends DialogFragment {

    public static final String REQUEST_KEY = "create_jar_request";
    public static final String KEY_JAR_NAME = "jar_name";
    public static final String KEY_TARGET_AMOUNT = "target_amount";
    public static final String KEY_JAR_TYPE = "jar_type";
    public static final String KEY_SELECTED_ICON = "selected_icon";
    public static final String KEY_SELECTED_COLOR = "selected_color";
    public static final String KEY_DEADLINE = "deadline";

    private EditText jarNameInput, targetAmountInput, deadlineInput;
    private ChipGroup jarTypeGroup;
    private ImageView selectedIcon = null;
    private ImageView selectedColorView = null;
    private String selectedIconName = "hat";
    private int selectedColorInt = Color.parseColor("#F44336"); // Default red
    private Button createButton;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setStyle(DialogFragment.STYLE_NORMAL, R.style.ThemeOverlay_App_Dialog);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.dialog_create_jar, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        setupIconSelection(view);
        setupColorSelection(view);
        setupDeadlinePicker();
        setupAmountFormatting();
        setupCreateButton(view);
        setupCloseButton(view);
    }

    private void initViews(View view) {
        jarNameInput = view.findViewById(R.id.jar_name_input);
        targetAmountInput = view.findViewById(R.id.target_amount_input);
        deadlineInput = view.findViewById(R.id.deadline_input);
        jarTypeGroup = view.findViewById(R.id.jar_type_group);
        createButton = view.findViewById(R.id.create_jar_button);

        Chip flexibleChip = view.findViewById(R.id.flexible_chip);
        if (flexibleChip != null) {
            flexibleChip.setChecked(true);
        }
    }

    private void setupIconSelection(View view) {
        View.OnClickListener iconClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedIcon != null) {
                    selectedIcon.setBackgroundResource(R.drawable.bg_icon_unselected);
                }

                v.setBackgroundResource(R.drawable.bg_icon_selected);
                selectedIcon = (ImageView) v;

                String viewId = getResources().getResourceEntryName(v.getId());
                selectedIconName = viewId.replace("icon_", "");
            }
        };

        int[] iconIds = {
                R.id.icon_hat, R.id.icon_house, R.id.icon_plane, R.id.icon_laptop,
                R.id.icon_car, R.id.icon_game, R.id.icon_shirt, R.id.icon_book,
                R.id.icon_burger, R.id.icon_gift
        };

        for (int id : iconIds) {
            ImageView icon = view.findViewById(id);
            if (icon != null) {
                icon.setOnClickListener(iconClickListener);
            }
        }

        ImageView defaultIcon = view.findViewById(R.id.icon_hat);
        if (defaultIcon != null) {
            defaultIcon.setBackgroundResource(R.drawable.bg_icon_selected);
            selectedIcon = defaultIcon;
            selectedIconName = "hat";
        }
    }

    private void setupColorSelection(View view) {
        View.OnClickListener colorClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedColorView != null) {
                    selectedColorView.setBackgroundResource(R.drawable.bg_color_circle);
                }
                v.setBackgroundResource(R.drawable.bg_color_circle);
                v.animate().scaleX(1.2f).scaleY(1.2f).setDuration(100).start();
                if (selectedColorView != null && selectedColorView != v) {
                    selectedColorView.animate().scaleX(1.0f).scaleY(1.0f).setDuration(100).start();
                }

                selectedColorView = (ImageView) v;

                int id = v.getId();
                if (id == R.id.color_red) selectedColorInt = Color.parseColor("#F44336");
                else if (id == R.id.color_blue) selectedColorInt = Color.parseColor("#2196F3");
                else if (id == R.id.color_green) selectedColorInt = Color.parseColor("#4CAF50");
                else if (id == R.id.color_purple) selectedColorInt = Color.parseColor("#9C27B0");
                else if (id == R.id.color_orange) selectedColorInt = Color.parseColor("#FF9800");
                else if (id == R.id.color_teal) selectedColorInt = Color.parseColor("#009688");
                else if (id == R.id.color_pink) selectedColorInt = Color.parseColor("#E91E63");
                else if (id == R.id.color_indigo) selectedColorInt = Color.parseColor("#3F51B5");
                else if (id == R.id.color_black) selectedColorInt = Color.parseColor("#000000");
                else if (id == R.id.color_custom) selectedColorInt = Color.parseColor("#9E9E9E");
            }
        };

        int[] colorIds = {
                R.id.color_red, R.id.color_blue, R.id.color_green, R.id.color_purple,
                R.id.color_orange, R.id.color_teal, R.id.color_pink, R.id.color_indigo,
                R.id.color_black, R.id.color_custom
        };

        for (int id : colorIds) {
            ImageView color = view.findViewById(id);
            if (color != null) {
                color.setOnClickListener(colorClickListener);
            }
        }

        ImageView defaultColor = view.findViewById(R.id.color_red);
        if (defaultColor != null) {
            defaultColor.animate().scaleX(1.2f).scaleY(1.2f).setDuration(0).start();
            selectedColorView = defaultColor;
            selectedColorInt = Color.parseColor("#F44336");
        }
    }

    private void setupDeadlinePicker() {
        deadlineInput.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(),
                        (view, year1, month1, dayOfMonth) -> {
                            calendar.set(year1, month1, dayOfMonth);
                            SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                            deadlineInput.setText(sdf.format(calendar.getTime()));
                        }, year, month, day);
                datePickerDialog.show();
            }
        });
    }

    private void setupAmountFormatting() {
        targetAmountInput.addTextChangedListener(new TextWatcher() {
            private String current = "";

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (!s.toString().equals(current)) {
                    targetAmountInput.removeTextChangedListener(this);

                    // UPDATED: Allow numbers and dot.
                    String cleanString = s.toString().replaceAll("[^\\d.]", "");

                    // Prevent multiple dots
                    if (cleanString.chars().filter(ch -> ch == '.').count() > 1) {
                        cleanString = cleanString.substring(0, cleanString.length() - 1);
                    }

                    if (!cleanString.isEmpty() && !cleanString.equals(".")) {
                        String symbol = SettingHelper.getCurrencySymbol(SettingHelper.getCurrency(requireContext()));

                        if (cleanString.contains(".")) {
                            current = symbol + cleanString;
                        } else {
                            double parsed = Double.parseDouble(cleanString);
                            current = symbol + String.format(Locale.US, "%,.0f", parsed);
                        }
                        targetAmountInput.setText(current);
                        targetAmountInput.setSelection(current.length());
                    } else {
                        current = "";
                        targetAmountInput.setText("");
                    }
                    targetAmountInput.addTextChangedListener(this);
                }
            }
        });
    }

    private void setupCreateButton(View view) {
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String jarName = jarNameInput.getText().toString().trim();
                String targetAmount = targetAmountInput.getText().toString().trim();

                if (jarName.isEmpty()) {
                    jarNameInput.setError(getString(R.string.jar_name_required));
                    return;
                }

                String cleanAmount = targetAmount.replaceAll("[^\\d.]", "");
                if (cleanAmount.isEmpty() || cleanAmount.equals("0")) {
                    targetAmountInput.setError(getString(R.string.error_invalid_amount));
                    return;
                }

                int selectedChipId = jarTypeGroup.getCheckedChipId();
                String jarType = "Flexible";
                if (selectedChipId == R.id.mandatory_chip) {
                    jarType = "Mandatory";
                } else if (selectedChipId == R.id.flexible_chip) {
                    jarType = "Flexible";
                } else if (selectedChipId == R.id.shared_chip) {
                    jarType = "Shared";
                }

                Bundle result = new Bundle();
                result.putString(KEY_JAR_NAME, jarName);
                result.putString(KEY_TARGET_AMOUNT, cleanAmount);
                result.putString(KEY_JAR_TYPE, jarType);
                result.putString(KEY_SELECTED_ICON, selectedIconName);
                result.putInt(KEY_SELECTED_COLOR, selectedColorInt);

                if (deadlineInput != null && !deadlineInput.getText().toString().isEmpty()) {
                    result.putString(KEY_DEADLINE, deadlineInput.getText().toString());
                }

                getParentFragmentManager().setFragmentResult(REQUEST_KEY, result);
                dismiss();
            }
        });
    }

    private void setupCloseButton(View view) {
        ImageView closeButton = view.findViewById(R.id.close_button);
        if (closeButton != null) {
            closeButton.setOnClickListener(v -> dismiss());
        }
    }
}