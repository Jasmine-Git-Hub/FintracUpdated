package com.example.fintrac;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class ChangePasswordActivity extends AppCompatActivity {

    private ImageView btnBack;
    private TextInputEditText etCurrentPassword, etNewPassword, etConfirmPassword;
    private MaterialButton btnUpdatePassword;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        SettingHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // 1. Initialize Views
        btnBack = findViewById(R.id.btnBack);
        etCurrentPassword = findViewById(R.id.etCurrentPassword);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnUpdatePassword = findViewById(R.id.btnUpdatePassword);

        // 2. Back Button Action
        btnBack.setOnClickListener(v -> finish());

        // 3. Update Button Action
        btnUpdatePassword.setOnClickListener(v -> {
            String currentPass = etCurrentPassword.getText() != null ? etCurrentPassword.getText().toString().trim() : "";
            String newPass = etNewPassword.getText() != null ? etNewPassword.getText().toString().trim() : "";
            String confirmPass = etConfirmPassword.getText() != null ? etConfirmPassword.getText().toString().trim() : "";

            // Validation 1: Check if fields are empty
            if (currentPass.isEmpty() || newPass.isEmpty() || confirmPass.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validation 2: Check if new password is the same as the old one
            if (newPass.equals(currentPass)) {
                Toast.makeText(this, "This was your previous password. Try again and create a new one.", Toast.LENGTH_LONG).show();
                return;
            }

            // Validation 3: Check if new passwords match
            if (!newPass.equals(confirmPass)) {
                Toast.makeText(this, "New passwords do not match", Toast.LENGTH_SHORT).show();
                return;
            }

            // Validation 4: Check password strength (minimum 8 chars, mix of lowercase and number)
            if (!isValidPassword(newPass)) {
                Toast.makeText(this, "Password must be at least 8 characters long and contain a mix of lowercase letters and numbers.", Toast.LENGTH_LONG).show();
                return;
            }

            // Kung pasado sa lahat ng validation, proceed sa Firebase Update
            updatePasswordInFirebase(currentPass, newPass);
        });
    }

    // Helper method para sa Password Validation Rule
    private boolean isValidPassword(String password) {
        // ".*[a-z].*" = requires at least one lowercase letter
        // ".*[0-9].*" = requires at least one number
        return password.length() >= 8 && password.matches(".*[a-z].*") && password.matches(".*[0-9].*");
    }

    // Helper method para sa Firebase Authentication at Update
    private void updatePasswordInFirebase(String currentPass, String newPass) {
        FirebaseUser user = mAuth.getCurrentUser();

        if (user != null && user.getEmail() != null) {
            // I-disable muna yung button para hindi ma-spam click
            btnUpdatePassword.setEnabled(false);
            btnUpdatePassword.setText("Updating...");

            // Step 1: Re-authenticate ang user (Requirement ng Firebase)
            AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), currentPass);

            user.reauthenticate(credential).addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    // Step 2: Pag successful ang re-auth, tsaka natin papalitan yung password
                    user.updatePassword(newPass).addOnCompleteListener(updateTask -> {
                        // I-enable ulit yung button at ibalik yung text
                        btnUpdatePassword.setEnabled(true);
                        btnUpdatePassword.setText("Update Password");

                        if (updateTask.isSuccessful()) {
                            Toast.makeText(this, "Password updated successfully!", Toast.LENGTH_SHORT).show();
                            finish(); // I-close na natin yung activity pag success
                        } else {
                            Toast.makeText(this, "Failed to update password: " + updateTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                } else {
                    // Fail sa re-authentication (Mali ang current password)
                    btnUpdatePassword.setEnabled(true);
                    btnUpdatePassword.setText("Update Password");
                    Toast.makeText(this, "Incorrect current password.", Toast.LENGTH_LONG).show();
                }
            });
        } else {
            Toast.makeText(this, "No authenticated user found. Please log in again.", Toast.LENGTH_SHORT).show();
        }
    }
}