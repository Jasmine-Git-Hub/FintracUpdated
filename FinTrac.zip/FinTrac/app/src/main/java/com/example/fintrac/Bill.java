package com.example.fintrac;

import com.google.firebase.firestore.Exclude;
import com.google.firebase.firestore.IgnoreExtraProperties;

// Optional: @IgnoreExtraProperties prevents crashes if there are fields in DB not in this class
@IgnoreExtraProperties
public class Bill {

    // Ginawang PUBLIC lahat para mabasa ni Firestore at ma-save sa database
    public String id;
    public String name;
    public String category;
    public String amount;
    public String dueDate;
    public String frequency;
    public int logoResId;
    public boolean isPaid;

    // Empty constructor (Required ni Firestore para sa pag-read ng data)
    public Bill() {
    }

    // Constructor without ID (Ginagamit kapag mag-aadd ng bagong bill)
    public Bill(String name, String category, String frequency, String amount,
                String dueDate, int logoResId, boolean isPaid) {
        this.name = name;
        this.category = category;
        this.frequency = frequency;
        this.amount = amount;
        this.dueDate = dueDate;
        this.logoResId = logoResId;
        this.isPaid = isPaid;
    }

    // Constructor with ID (Ginagamit kapag galing sa Firestore yung data)
    public Bill(String id, String name, String category, String frequency,
                String amount, String dueDate, int logoResId, boolean isPaid) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.frequency = frequency;
        this.amount = amount;
        this.dueDate = dueDate;
        this.logoResId = logoResId;
        this.isPaid = isPaid;
    }

    // Optional: Helper method para makuha ang ID kahit private (kung gusto mo ibalik sa private later)
    @Exclude
    public String getId() {
        return id;
    }

    @Exclude
    public void setId(String id) {
        this.id = id;
    }
}