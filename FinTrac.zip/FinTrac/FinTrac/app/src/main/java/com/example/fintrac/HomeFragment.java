package com.example.fintrac;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.ListenerRegistration;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.WriteBatch;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class HomeFragment extends Fragment {

    // --- VARIABLES ---
    private double currentBalance = 0.00;
    private double totalInJars = 0.00;
    // BAGO: Gumagamit na nang direkta sa Transaction para makuha pati yung description
    private final List<Transaction> transactionList = new ArrayList<>();
    private TransactionAdapter adapter;

    // Chart Variables
    private BarChart barChart;
    private final float[] weeklyExpenses = new float[]{0f, 0f, 0f, 0f, 0f, 0f, 0f};

    // UI Elements
    private TextView tvTotalBalance, tvSpendable, tvNoTransactions;
    private TextView welcomeText, usernameText;
    private TextView tvInJarsAmount, tvUnpaidBillsAmount, tvInJarsSubtitle, tvUnpaidBillsSubtitle;
    private CardView profileCard;
    private ImageView profileImage;
    private RecyclerView recyclerView;

    // Unpaid Bills Elements
    private LinearLayout unpaidBillsContainer;
    private TextView tvUnpaidBillsTitle, tvNoUnpaidBills;
    private final List<Bill> unpaidBillsList = new ArrayList<>();

    // Notification variables
    private MaterialCardView notificationBellCard;
    private ImageView notificationBell;
    private TextView notificationBadge;
    private final List<NotificationItem> notificationList = new ArrayList<>();
    private NotificationAdapter notificationAdapter;
    private BottomSheetDialog notificationDialog;
    private ListenerRegistration notificationListener;

    private boolean isExpenseType = true;

    private FirebaseAuth mAuth;
    private FirestoreHelper firestoreHelper;
    private FirebaseFirestore db;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        SettingHelper.applyTheme(requireActivity());
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
        mAuth = FirebaseAuth.getInstance();
        firestoreHelper = FirestoreHelper.getInstance();
        db = FirebaseFirestore.getInstance();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }

        SettingHelper.updateRatesIfNecessary(requireContext());

        tvTotalBalance = view.findViewById(R.id.total_balance_amount);
        tvSpendable = view.findViewById(R.id.spendable_amount);
        tvNoTransactions = view.findViewById(R.id.no_transactions_text);
        recyclerView = view.findViewById(R.id.transactions_recycler_view);
        welcomeText = view.findViewById(R.id.welcome_text);
        usernameText = view.findViewById(R.id.username_text);
        tvInJarsAmount = view.findViewById(R.id.in_jars_amount);
        tvUnpaidBillsAmount = view.findViewById(R.id.unpaid_bills_amount);
        tvInJarsSubtitle = view.findViewById(R.id.in_jars_subtitle);
        tvUnpaidBillsSubtitle = view.findViewById(R.id.unpaid_bills_subtitle);

        unpaidBillsContainer = view.findViewById(R.id.unpaid_bills_container);
        tvUnpaidBillsTitle = view.findViewById(R.id.tv_unpaid_bills_title);
        tvNoUnpaidBills = view.findViewById(R.id.tv_no_unpaid_bills);

        profileCard = view.findViewById(R.id.profile_card);
        profileImage = view.findViewById(R.id.profile_image);

        FloatingActionButton addTransactionFab = view.findViewById(R.id.add_transaction_fab);
        barChart = view.findViewById(R.id.weeklySpendingChart);

        initNotificationBell(view);

        displayCurrentUserInfo();

        adapter = new TransactionAdapter(transactionList);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(adapter);

        setupWeeklyChart();
        updateDashboardDisplay();
        loadUserData();

        loadUnpaidBills();

        addTransactionFab.setOnClickListener(v -> showNewTransactionDialog());
        setupProfileCard();

        startBackgroundNotificationService();
    }

    private void startBackgroundNotificationService() {
        PeriodicWorkRequest notificationWork = new PeriodicWorkRequest.Builder(
                FinTracWorker.class, 1, TimeUnit.HOURS)
                .build();

        WorkManager.getInstance(requireContext()).enqueueUniquePeriodicWork(
                "FinTracBackgroundSync",
                ExistingPeriodicWorkPolicy.KEEP,
                notificationWork);

        Log.d("HomeFragment", "Background Notification Worker scheduled.");
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
            // Apply theme color to status bar and action bar
            applyThemeColor();
        }
        displayCurrentUserInfo();
        loadUserProfileData();
        loadUserData();
        loadUnpaidBills();
        loadTotalInJars();
    }

    private void applyThemeColor() {
        if (getActivity() == null) return;

        // Get the current theme from SharedPreferences
        android.content.SharedPreferences prefs = requireActivity().getSharedPreferences("FinTracPrefs", Context.MODE_PRIVATE);
        String currentTheme = prefs.getString("selected_theme", "Ocean Blue");

        // Get the color resource ID for the current theme
        int themeColorResId = ThemeColorManager.getThemeColorResId(requireContext(), currentTheme);

        // Apply the theme color
        ThemeColorManager.applyThemeColor(requireActivity(), themeColorResId);
    }

    private void loadUserData() {
        loadTransactions();
        loadBalance();
        loadWeeklyExpenses();
        loadTotalInJars();
    }

    private void loadTransactions() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        firestoreHelper.getRecentTransactions(20, new FirestoreHelper.OnTransactionsLoadedListener() {
            @Override
            public void onSuccess(List<Transaction> transactions) {
                if (isAdded() && getContext() != null) {
                    transactionList.clear();
                    // Diretso nang nilalagay yung Transaction, hindi na TransactionItem
                    transactionList.addAll(transactions);
                    adapter.notifyDataSetChanged();
                    updateDashboardDisplay();
                }
            }

            @Override
            public void onFailure(String error) {
                if (isAdded() && getContext() != null) {
                    updateDashboardDisplay();
                    if (!error.contains("FAILED_PRECONDITION") && !error.contains("index")) {
                        Toast.makeText(getContext(), "Failed to load transactions: " + error, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void loadBalance() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        firestoreHelper.getTotalBalance(new FirestoreHelper.OnBalanceLoadedListener() {
            @Override
            public void onSuccess(double balance) {
                if (isAdded()) {
                    currentBalance = balance;
                    updateBalanceDisplay();
                    loadTotalInJars();
                }
            }

            @Override
            public void onFailure(String error) {
                if (isAdded() && getContext() != null) {
                    Toast.makeText(getContext(), "Failed to load balance: " + error, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void loadWeeklyExpenses() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        firestoreHelper.getWeeklyExpenses(new FirestoreHelper.OnWeeklyExpensesLoadedListener() {
            @Override
            public void onSuccess(float[] expenses) {
                if (isAdded()) {
                    if (expenses != null) {
                        for (int i = 0; i < weeklyExpenses.length && i < expenses.length; i++) {
                            weeklyExpenses[i] = expenses[i];
                        }
                    }
                    setupWeeklyChart();
                    if (barChart != null) {
                        barChart.setVisibility(View.VISIBLE);
                        barChart.animateY(800);
                    }
                }
            }

            @Override
            public void onFailure(String error) {
                if (isAdded() && getContext() != null) {
                    // Even on failure, show chart with zeros
                    setupWeeklyChart();
                    if (barChart != null) {
                        barChart.setVisibility(View.VISIBLE);
                    }
                    if (!error.contains("FAILED_PRECONDITION") && !error.contains("index")) {
                        Toast.makeText(getContext(), "Failed to load chart data: " + error, Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void loadTotalInJars() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || !isAdded()) return;

        String userId = currentUser.getUid();
        totalInJars = 0.0;

        FirebaseFirestore.getInstance()
                .collection("jars")
                .whereArrayContains("participants", userId)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double jarsTotal = 0.0;

                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Double savedAmount = doc.getDouble("savedAmount");
                        if (savedAmount != null) {
                            jarsTotal += savedAmount;
                        }
                    }

                    totalInJars = jarsTotal;

                    if (isAdded() && getContext() != null) {
                        String formattedJarsAmount = SettingHelper.formatAmount(requireContext(), totalInJars);
                        tvInJarsAmount.setText(formattedJarsAmount);

                        if (currentBalance > 0) {
                            double percentage = (totalInJars / currentBalance) * 100;
                            tvInJarsSubtitle.setText(String.format(Locale.getDefault(),
                                    "%.1f%% of total balance", percentage));
                        } else {
                            tvInJarsSubtitle.setText("0% of total balance");
                        }

                        updateBalanceDisplay();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("HomeFragment", "Error loading jars total", e);
                    loadTotalInJarsFromSubcollection();
                });
    }

    private void loadTotalInJarsFromSubcollection() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || !isAdded()) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("jars")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    double jarsTotal = 0.0;
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Double savedAmount = doc.getDouble("savedAmount");
                        if (savedAmount != null) {
                            jarsTotal += savedAmount;
                        }
                    }

                    totalInJars = jarsTotal;

                    if (isAdded() && getContext() != null) {
                        String formattedJarsAmount = SettingHelper.formatAmount(requireContext(), totalInJars);
                        tvInJarsAmount.setText(formattedJarsAmount);

                        if (currentBalance > 0) {
                            double percentage = (totalInJars / currentBalance) * 100;
                            tvInJarsSubtitle.setText(String.format(Locale.getDefault(),
                                    "%.1f%% of total balance", percentage));
                        } else {
                            tvInJarsSubtitle.setText("0% of total balance");
                        }

                        updateBalanceDisplay();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("HomeFragment", "Error loading jars from subcollection", e);
                    totalInJars = 0.0;
                    if (isAdded() && getContext() != null) {
                        tvInJarsAmount.setText(SettingHelper.formatAmount(requireContext(), 0));
                        tvInJarsSubtitle.setText("0% of total balance");
                        updateBalanceDisplay();
                    }
                });
    }

    private void loadUserProfileData() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        FirebaseFirestore.getInstance().collection("users").document(currentUser.getUid())
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot != null && documentSnapshot.exists()) {
                        if (isAdded() && getContext() != null) {
                            String fullName = documentSnapshot.getString("fullName");
                            if (fullName != null && !fullName.isEmpty() && usernameText != null) {
                                usernameText.setText(fullName);
                            }

                            if (profileImage != null) {
                                String savedAvatar = documentSnapshot.getString("profileAvatar");
                                String savedUri = documentSnapshot.getString("profileImageLocalUri");

                                if (savedUri != null && !savedUri.isEmpty()) {
                                    profileImage.setImageDrawable(null);
                                    profileImage.setPadding(0, 0, 0, 0);
                                    profileImage.setImageTintList(null);
                                    profileImage.setImageURI(Uri.parse(savedUri));
                                } else if (savedAvatar != null) {
                                    profileImage.setImageDrawable(null);
                                    profileImage.setPadding(0, 0, 0, 0);
                                    profileImage.setImageTintList(null);
                                    int resId = getResources().getIdentifier(savedAvatar, "drawable", requireContext().getPackageName());
                                    if (resId != 0) {
                                        profileImage.setImageResource(resId);
                                    }
                                }
                            }
                        }
                    }
                })
                .addOnFailureListener(e -> Log.e("HomeFragment", "Error loading profile", e));
    }

    private void loadUnpaidBills() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        db.collection("users")
                .document(currentUser.getUid())
                .collection("bills")
                .whereEqualTo("isPaid", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (isAdded() && getContext() != null) {
                        unpaidBillsList.clear();
                        for (DocumentSnapshot doc : queryDocumentSnapshots) {
                            Long logoResIdLong = doc.getLong("logoResId");
                            int logoResId = (logoResIdLong != null) ? logoResIdLong.intValue() : R.drawable.ic_visual_reports;

                            Boolean isPaid = doc.getBoolean("isPaid");
                            boolean isPaidValue = (isPaid != null) ? isPaid : false;

                            Bill bill = new Bill(
                                    doc.getId(),
                                    doc.getString("name"),
                                    doc.getString("category"),
                                    doc.getString("frequency"),
                                    doc.getString("amount"),
                                    doc.getString("dueDate"),
                                    logoResId,
                                    isPaidValue
                            );
                            unpaidBillsList.add(bill);
                        }
                        displayUnpaidBills();
                        updateUnpaidBillsTotal();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("HomeFragment", "Error loading unpaid bills: " + e.getMessage());
                    if (unpaidBillsContainer != null) {
                        unpaidBillsContainer.setVisibility(View.GONE);
                    }
                });
    }

    private void displayUnpaidBills() {
        if (unpaidBillsContainer == null || tvNoUnpaidBills == null || getContext() == null) return;

        unpaidBillsContainer.removeAllViews();

        if (tvUnpaidBillsTitle != null) {
            unpaidBillsContainer.addView(tvUnpaidBillsTitle);
        }

        if (unpaidBillsList.isEmpty()) {
            tvNoUnpaidBills.setVisibility(View.VISIBLE);
            unpaidBillsContainer.addView(tvNoUnpaidBills);
        } else {
            tvNoUnpaidBills.setVisibility(View.GONE);

            int displayCount = Math.min(unpaidBillsList.size(), 3);
            for (int i = 0; i < displayCount; i++) {
                Bill bill = unpaidBillsList.get(i);
                View billView = createUnpaidBillView(bill);
                unpaidBillsContainer.addView(billView);
            }

            if (unpaidBillsList.size() > 3) {
                addViewAllBillsButton();
            }
        }
    }

    private View createUnpaidBillView(Bill bill) {
        if (getContext() == null) return new View(getContext());

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View billView = inflater.inflate(R.layout.item_unpaid_bill, unpaidBillsContainer, false);

        TextView tvBillName = billView.findViewById(R.id.tv_bill_name);
        TextView tvBillAmount = billView.findViewById(R.id.tv_bill_amount);
        TextView tvBillDueDate = billView.findViewById(R.id.tv_bill_due_date);
        TextView tvBillCategory = billView.findViewById(R.id.tv_bill_category);
        MaterialButton btnMarkPaid = billView.findViewById(R.id.btn_mark_paid);
        CardView billCard = billView.findViewById(R.id.bill_card);

        tvBillName.setText(bill.name);

        double amount = 0;
        try {
            String cleanAmount = bill.amount.replaceAll("[^\\d.]", "");
            if (!cleanAmount.isEmpty()) {
                amount = Double.parseDouble(cleanAmount);
            }
        } catch (NumberFormatException e) {
            Log.e("HomeFragment", "Error parsing amount", e);
        }

        String formattedAmount = SettingHelper.formatAmount(requireContext(), amount);
        tvBillAmount.setText(formattedAmount);

        String dueDate = bill.dueDate;
        if (dueDate.startsWith("Due: ")) {
            dueDate = dueDate.substring(5);
        }
        tvBillDueDate.setText("Due: " + dueDate);
        tvBillCategory.setText(bill.category);

        int categoryColor = getCategoryColor(bill.category);
        tvBillCategory.setTextColor(categoryColor);
        tvBillCategory.setBackgroundTintList(ColorStateList.valueOf(categoryColor + 0x20000000));

        if (SettingHelper.isDarkMode(requireContext())) {
            billCard.setCardBackgroundColor(Color.parseColor("#2C2C2C"));
        }

        btnMarkPaid.setOnClickListener(v -> markBillAsPaid(bill));

        return billView;
    }

    private int getCategoryColor(String category) {
        if (getContext() == null) return Color.GRAY;

        if (SettingHelper.isDarkMode(requireContext())) {
            switch (category.toLowerCase()) {
                case "utilities": return Color.parseColor("#64B5F6");
                case "subscriptions": return Color.parseColor("#BA68C8");
                case "loans": return Color.parseColor("#EF9A9A");
                case "rent": return Color.parseColor("#FFB74D");
                case "groceries": return Color.parseColor("#81C784");
                case "transportation": return Color.parseColor("#4FC3F7");
                default: return Color.parseColor("#B0B0B0");
            }
        } else {
            switch (category.toLowerCase()) {
                case "utilities": return Color.parseColor("#1976D2");
                case "subscriptions": return Color.parseColor("#7B1FA2");
                case "loans": return Color.parseColor("#D32F2F");
                case "rent": return Color.parseColor("#F57C00");
                case "groceries": return Color.parseColor("#388E3C");
                case "transportation": return Color.parseColor("#0288D1");
                default: return Color.parseColor("#616161");
            }
        }
    }

    private void addViewAllBillsButton() {
        if (getContext() == null) return;

        MaterialButton btnViewAll = new MaterialButton(requireContext());
        btnViewAll.setText(R.string.view_all_bills);
        btnViewAll.setBackgroundTintList(ColorStateList.valueOf(Color.TRANSPARENT));
        btnViewAll.setTextColor(getCategoryColor("default"));
        btnViewAll.setIcon(ContextCompat.getDrawable(requireContext(), R.drawable.ic_arrow_forward));
        btnViewAll.setIconGravity(MaterialButton.ICON_GRAVITY_END);
        btnViewAll.setPadding(0, 16, 0, 16);
        btnViewAll.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        btnViewAll.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) {
                ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_bills);
            }
        });

        unpaidBillsContainer.addView(btnViewAll);
    }

    private void markBillAsPaid(Bill bill) {
        if (bill == null || bill.id == null || getContext() == null) return;

        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        builder.setTitle(R.string.mark_as_paid)
                .setMessage(getString(R.string.mark_bill_paid_confirmation, bill.name))
                .setPositiveButton(R.string.yes, (dialog, which) -> {
                    FirebaseUser currentUser = mAuth.getCurrentUser();
                    if (currentUser == null) return;

                    FirebaseFirestore.getInstance()
                            .collection("users")
                            .document(currentUser.getUid())
                            .collection("bills")
                            .document(bill.id)
                            .update("isPaid", true)
                            .addOnSuccessListener(aVoid -> {
                                unpaidBillsList.remove(bill);
                                displayUnpaidBills();
                                updateUnpaidBillsTotal();

                                double amount = 0;
                                try {
                                    String cleanAmount = bill.amount.replaceAll("[^\\d.]", "");
                                    if (!cleanAmount.isEmpty()) {
                                        amount = Double.parseDouble(cleanAmount);
                                    }
                                } catch (Exception ignore) {}

                                Transaction historyTx = new Transaction(
                                        "Paid: " + bill.name,
                                        bill.category + " • " + bill.frequency,
                                        "bills",
                                        amount,
                                        true,
                                        currentUser.getUid()
                                );

                                FirebaseFirestore.getInstance()
                                        .collection("users")
                                        .document(currentUser.getUid())
                                        .collection("transactions")
                                        .add(historyTx);

                                Toast.makeText(getContext(), R.string.bill_marked_paid, Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> {
                                Log.e("HomeFragment", "Error marking bill as paid", e);
                                Toast.makeText(getContext(), R.string.failed_update_bill, Toast.LENGTH_SHORT).show();
                            });
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void updateUnpaidBillsTotal() {
        if (tvUnpaidBillsAmount == null || tvUnpaidBillsSubtitle == null || getContext() == null) return;

        double totalUnpaid = 0;
        for (Bill bill : unpaidBillsList) {
            try {
                String cleanAmount = bill.amount.replaceAll("[^\\d.]", "");
                if (!cleanAmount.isEmpty()) {
                    totalUnpaid += Double.parseDouble(cleanAmount);
                }
            } catch (NumberFormatException e) {
                Log.e("HomeFragment", "Error parsing amount", e);
            }
        }

        String formattedTotal = SettingHelper.formatAmount(requireContext(), totalUnpaid);
        tvUnpaidBillsAmount.setText(formattedTotal);

        int count = unpaidBillsList.size();
        if (count == 0) {
            tvUnpaidBillsSubtitle.setText(R.string.no_pending_bills);
        } else if (count == 1) {
            tvUnpaidBillsSubtitle.setText(R.string.one_pending_bill);
        } else {
            tvUnpaidBillsSubtitle.setText(getString(R.string.pending_bills_count, count));
        }
    }

    private void updateBalanceDisplay() {
        if (getContext() != null) {
            double spendableAmount = currentBalance;

            String formattedBalance = SettingHelper.formatAmount(requireContext(), currentBalance);
            String formattedSpendable = SettingHelper.formatAmount(requireContext(), spendableAmount);
            String formattedJars = SettingHelper.formatAmount(requireContext(), totalInJars);

            tvTotalBalance.setText(formattedBalance);
            tvSpendable.setText(formattedSpendable);
            tvInJarsAmount.setText(formattedJars);

            if (currentBalance > 0) {
                double percentage = (totalInJars / currentBalance) * 100;
                tvInJarsSubtitle.setText(String.format(Locale.getDefault(),
                        "%.1f%% of total balance", percentage));
            } else {
                tvInJarsSubtitle.setText("0% of total balance");
            }
        }
    }

    private void displayCurrentUserInfo() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser != null) {
            String displayName = currentUser.getDisplayName();
            String email = currentUser.getEmail();

            if (displayName != null && !displayName.isEmpty()) {
                usernameText.setText(displayName);
                welcomeText.setText(R.string.welcome_back);
            } else {
                usernameText.setText(email != null ? email : getString(R.string.user));
                welcomeText.setText(R.string.welcome);
            }
        } else {
            usernameText.setText(R.string.guest);
            welcomeText.setText(R.string.welcome);
        }
    }

    private void setupProfileCard() {
        if (profileCard != null) {
            profileCard.setOnClickListener(v -> showProfileOptionsDialog());
        }
    }

    private void showProfileOptionsDialog() {
        BottomSheetDialog dialog = new BottomSheetDialog(requireContext());

        View view = getLayoutInflater().inflate(R.layout.dialog_profile_menu, null, false);
        dialog.setContentView(view);

        View bottomSheet = (View) view.getParent();
        if (bottomSheet != null) {
            bottomSheet.setBackgroundColor(Color.TRANSPARENT);
        }

        TextView btnEditProfile = view.findViewById(R.id.btnMenuEditProfile);
        TextView btnLogout = view.findViewById(R.id.btnMenuLogout);
        TextView btnCancel = view.findViewById(R.id.btnMenuCancel);

        if (btnEditProfile != null) {
            btnEditProfile.setOnClickListener(v -> {
                dialog.dismiss();
                startActivity(new Intent(getActivity(), EditProfileActivity.class));
            });
        }

        if (btnLogout != null) {
            btnLogout.setOnClickListener(v -> {
                dialog.dismiss();
                showLogoutConfirmationDialog();
            });
        }

        if (btnCancel != null) {
            btnCancel.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    private void showLogoutConfirmationDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.logout)
                .setMessage(R.string.logout_confirmation)
                .setPositiveButton(R.string.yes, (dialog, which) -> logoutUser())
                .setNegativeButton(R.string.cancel, (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void logoutUser() {
        mAuth.signOut();
        redirectToLogin();
    }

    private void redirectToLogin() {
        if (getActivity() != null) {
            Intent intent = new Intent(getActivity(), LogIn.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            getActivity().finish();
        }
    }

    private void setupWeeklyChart() {
        if (barChart == null || getContext() == null) return;

        ArrayList<BarEntry> entries = new ArrayList<>();
        double rate = SettingHelper.getExchangeRate(requireContext(), SettingHelper.getCurrency(requireContext()));

        // Log the values to debug
        for (int i = 0; i < weeklyExpenses.length; i++) {
            float value = (float) (weeklyExpenses[i] * rate);
            entries.add(new BarEntry(i, value));
            Log.d("ChartDebug", "Day " + i + ": " + weeklyExpenses[i] + " * " + rate + " = " + value);
        }

        BarDataSet dataSet = new BarDataSet(entries, getString(R.string.weekly_spending));

        Context context = requireContext();
        if (SettingHelper.isDarkMode(context)) {
            dataSet.setColor(Color.parseColor("#64B5F6"));
        } else {
            dataSet.setColor(Color.parseColor("#2196F3"));
        }

        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(10f);
        dataSet.setDrawValues(false);

        BarData barData = new BarData(dataSet);

        // Important: Set bar width to ensure all bars are visible
        barData.setBarWidth(0.9f); // Adjust bar width

        barChart.setData(barData);

        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.setDrawGridBackground(false);
        barChart.getAxisRight().setEnabled(false);

        // Configure left axis
        barChart.getAxisLeft().setDrawGridLines(true);
        barChart.getAxisLeft().setAxisMinimum(0f);
        barChart.getAxisLeft().setSpaceTop(15f); // Add some space at the top

        // Important: Set fit bars to true
        barChart.setFitBars(true);
        barChart.setPinchZoom(false);
        barChart.setScaleEnabled(false);
        barChart.setDoubleTapToZoomEnabled(false);

        // Set chart padding/margins
        barChart.setExtraOffsets(5, 10, 5, 10);

        if (SettingHelper.isDarkMode(context)) {
            barChart.getXAxis().setTextColor(Color.WHITE);
            barChart.getAxisLeft().setTextColor(Color.WHITE);
        } else {
            barChart.getXAxis().setTextColor(Color.BLACK);
            barChart.getAxisLeft().setTextColor(Color.BLACK);
        }

        String[] days = {
                getString(R.string.sun),
                getString(R.string.mon),
                getString(R.string.tue),
                getString(R.string.wed),
                getString(R.string.thu),
                getString(R.string.fri),
                getString(R.string.sat)
        };

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(days));
        xAxis.setGranularity(1f);
        xAxis.setDrawGridLines(false);

        // Important: Set label count to ensure all labels are shown
        xAxis.setLabelCount(7, true);
        xAxis.setAxisMinimum(-0.5f); // Add some padding
        xAxis.setAxisMaximum(6.5f);   // Add some padding

        // Force chart to redraw with new settings
        barChart.invalidate();
    }

    private void updateDashboardDisplay() {
        if (getContext() != null) {
            String formattedBalance = SettingHelper.formatAmount(requireContext(), currentBalance);
            tvTotalBalance.setText(formattedBalance);
            tvSpendable.setText(formattedBalance);
        }

        if (transactionList.isEmpty()) {
            tvNoTransactions.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            tvNoTransactions.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void updateWeeklyExpenses(float amount) {
        Calendar calendar = Calendar.getInstance();
        int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
        int index;
        switch (dayOfWeek) {
            case Calendar.SUNDAY: index = 0; break;
            case Calendar.MONDAY: index = 1; break;
            case Calendar.TUESDAY: index = 2; break;
            case Calendar.WEDNESDAY: index = 3; break;
            case Calendar.THURSDAY: index = 4; break;
            case Calendar.FRIDAY: index = 5; break;
            case Calendar.SATURDAY: index = 6; break;
            default: index = 0;
        }
        weeklyExpenses[index] += amount;
        setupWeeklyChart();
        barChart.animateY(800);
    }

    private void showNewTransactionDialog() {
        Context context = requireContext();
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_new_transaction, null);
        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        SettingHelper.applyTheme(dialog.getContext());

        ImageButton btnClose = dialogView.findViewById(R.id.btn_close);
        MaterialButton btnExpense = dialogView.findViewById(R.id.btn_type_expense);
        MaterialButton btnIncome = dialogView.findViewById(R.id.btn_type_income);
        MaterialButton btnSave = dialogView.findViewById(R.id.btn_save_transaction);
        TextInputLayout tilCategory = dialogView.findViewById(R.id.til_category);
        TextView tvCategoryLabel = dialogView.findViewById(R.id.tv_category_label);
        TextInputEditText etAmount = dialogView.findViewById(R.id.et_amount);
        TextInputEditText etDesc = dialogView.findViewById(R.id.et_desc);
        AutoCompleteTextView actCategory = dialogView.findViewById(R.id.act_category);

        int colorRed, colorGreen, colorGray, colorTextGray;

        if (SettingHelper.isDarkMode(context)) {
            colorRed = Color.parseColor("#EF9A9A");
            colorGreen = Color.parseColor("#81C784");
            colorGray = Color.parseColor("#424242");
            colorTextGray = Color.parseColor("#B0B0B0");
        } else {
            colorRed = ContextCompat.getColor(context, R.color.jar_color_red);
            colorGreen = ContextCompat.getColor(context, R.color.green);
            colorGray = ContextCompat.getColor(context, R.color.light_gray);
            colorTextGray = ContextCompat.getColor(context, R.color.gray);
        }

        String[] categories = {getString(R.string.food), getString(R.string.transportation),
                getString(R.string.bills), getString(R.string.shopping),
                getString(R.string.entertainment), getString(R.string.health),
                getString(R.string.education), getString(R.string.other)};
        ArrayAdapter<String> adapterCat = new ArrayAdapter<>(context,
                android.R.layout.simple_dropdown_item_1line, categories);
        actCategory.setAdapter(adapterCat);
        actCategory.setText(categories[0], false);

        Runnable updateUI = () -> {
            if (isExpenseType) {
                btnExpense.setStrokeColor(ColorStateList.valueOf(colorRed));
                btnExpense.setTextColor(colorRed);
                btnIncome.setStrokeColor(ColorStateList.valueOf(colorGray));
                btnIncome.setTextColor(colorTextGray);

                tilCategory.setVisibility(View.VISIBLE);
                tvCategoryLabel.setVisibility(View.VISIBLE);

                btnSave.setText(R.string.add_expense);
                btnSave.setBackgroundTintList(ColorStateList.valueOf(colorRed));
            } else {
                btnIncome.setStrokeColor(ColorStateList.valueOf(colorGreen));
                btnIncome.setTextColor(colorGreen);
                btnExpense.setStrokeColor(ColorStateList.valueOf(colorGray));
                btnExpense.setTextColor(colorTextGray);

                tilCategory.setVisibility(View.GONE);
                tvCategoryLabel.setVisibility(View.GONE);

                btnSave.setText(R.string.add_income);
                btnSave.setBackgroundTintList(ColorStateList.valueOf(colorGreen));
            }
        };

        isExpenseType = true;
        updateUI.run();

        btnExpense.setOnClickListener(v -> {
            isExpenseType = true;
            updateUI.run();
        });
        btnIncome.setOnClickListener(v -> {
            isExpenseType = false;
            updateUI.run();
        });
        btnClose.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String amountStr = Objects.requireNonNull(etAmount.getText()).toString().trim();
            if (amountStr.isEmpty()) {
                Toast.makeText(context, R.string.enter_amount, Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                double uiAmount = Double.parseDouble(amountStr);
                double amountInPHP = SettingHelper.convertToBasePHP(context, uiAmount);

                String desc = Objects.requireNonNull(etDesc.getText()).toString().trim();
                String category = Objects.requireNonNull(actCategory.getText()).toString().trim();

                if (isExpenseType && category.isEmpty()) {
                    Toast.makeText(context, R.string.select_category, Toast.LENGTH_SHORT).show();
                    return;
                }

                FirebaseUser currentUser = mAuth.getCurrentUser();
                if (currentUser == null) {
                    Toast.makeText(context, R.string.user_not_authenticated, Toast.LENGTH_SHORT).show();
                    dialog.dismiss();
                    redirectToLogin();
                    return;
                }

                String title;
                if (isExpenseType) {
                    title = category.isEmpty() ? getString(R.string.expense) : category;
                } else {
                    title = desc.isEmpty() ? getString(R.string.income) : desc;
                }

                Transaction transaction = new Transaction(
                        title,
                        desc,
                        category,
                        amountInPHP,
                        isExpenseType,
                        currentUser.getUid()
                );

                btnSave.setEnabled(false);
                btnSave.setText(R.string.saving);

                firestoreHelper.addTransaction(transaction,
                        new FirestoreHelper.OnTransactionAddedListener() {
                            @Override
                            public void onSuccess(Transaction savedTransaction) {
                                if (isAdded() && getContext() != null) {
                                    currentBalance = isExpenseType ?
                                            currentBalance - amountInPHP : currentBalance + amountInPHP;

                                    // Nilalagay na nang direkta ang Transaction object
                                    transactionList.add(0, savedTransaction);
                                    adapter.notifyItemInserted(0);
                                    recyclerView.smoothScrollToPosition(0);

                                    if (isExpenseType) {
                                        updateWeeklyExpenses((float) amountInPHP);
                                    }

                                    updateDashboardDisplay();
                                    updateBalanceDisplay();

                                    Toast.makeText(context, R.string.transaction_saved, Toast.LENGTH_SHORT).show();

                                    btnSave.setEnabled(true);
                                    dialog.dismiss();
                                }
                            }

                            @Override
                            public void onFailure(String error) {
                                if (isAdded() && getContext() != null) {
                                    Toast.makeText(context, getString(R.string.save_failed) + error, Toast.LENGTH_LONG).show();
                                    btnSave.setEnabled(true);
                                    btnSave.setText(isExpenseType ? R.string.add_expense : R.string.add_income);
                                }
                            }
                        });

            } catch (NumberFormatException e) {
                Toast.makeText(context, R.string.invalid_amount, Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void initNotificationBell(View view) {
        notificationBellCard = view.findViewById(R.id.notification_bell_card);
        notificationBell = view.findViewById(R.id.notification_bell);
        notificationBadge = view.findViewById(R.id.notification_badge);

        notificationBellCard.setOnClickListener(v -> showNotificationsDialog());
        setupNotificationListener();
        checkPendingInvitations();
    }

    private void setupNotificationListener() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        notificationListener = FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((value, error) -> {
                    if (error != null) {
                        Log.e("HomeFragment", "Error listening to notifications", error);
                        return;
                    }

                    if (value != null) {
                        notificationList.clear();
                        int unreadCount = 0;

                        for (DocumentSnapshot doc : value.getDocuments()) {
                            NotificationItem notification = doc.toObject(NotificationItem.class);
                            if (notification != null) {
                                notification.setId(doc.getId());
                                notificationList.add(notification);
                                if (!notification.isRead()) {
                                    unreadCount++;
                                }
                            }
                        }

                        updateNotificationBadge(unreadCount);

                        if (notificationDialog != null && notificationDialog.isShowing() && notificationAdapter != null) {
                            notificationAdapter.notifyDataSetChanged();
                            updateNotificationsDialogVisibility();
                        }
                    }
                });
    }

    private void updateNotificationBadge(int unreadCount) {
        if (notificationBadge != null) {
            if (unreadCount > 0) {
                notificationBadge.setVisibility(View.VISIBLE);
                notificationBadge.setText(String.valueOf(unreadCount));
            } else {
                notificationBadge.setVisibility(View.GONE);
            }
        }
    }

    private void checkPendingInvitations() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .whereEqualTo("type", "JAR_INVITE")
                .whereEqualTo("isRead", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    int pendingCount = queryDocumentSnapshots.size();
                    if (pendingCount > 0) {
                        animateNotificationBell();
                    }
                });
    }

    private void animateNotificationBell() {
        if (notificationBell != null) {
            notificationBell.animate()
                    .rotation(10f)
                    .setDuration(100)
                    .withEndAction(() -> notificationBell.animate()
                            .rotation(-10f)
                            .setDuration(100)
                            .withEndAction(() -> notificationBell.animate()
                                    .rotation(0f)
                                    .setDuration(100)))
                    .start();
        }
    }

    private void showNotificationsDialog() {
        if (getContext() == null) return;

        notificationDialog = new BottomSheetDialog(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_notifications, null);
        notificationDialog.setContentView(dialogView);

        RecyclerView recyclerView = dialogView.findViewById(R.id.notifications_recycler_view);
        TextView noNotificationsText = dialogView.findViewById(R.id.no_notifications_text);
        TextView markAllRead = dialogView.findViewById(R.id.mark_all_read);

        notificationAdapter = new NotificationAdapter(requireContext(), notificationList,
                new NotificationAdapter.OnNotificationActionListener() {
                    @Override
                    public void onAcceptInvite(NotificationItem notification) {
                        acceptJarInvite(notification);
                    }

                    @Override
                    public void onDeclineInvite(NotificationItem notification) {
                        declineJarInvite(notification);
                    }

                    @Override
                    public void onNotificationClick(NotificationItem notification) {
                        markNotificationAsRead(notification);
                        handleNotificationClick(notification);
                    }

                    @Override
                    public void onMarkAsRead(NotificationItem notification) {
                        markNotificationAsRead(notification);
                    }
                });

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(notificationAdapter);

        markAllRead.setOnClickListener(v -> markAllNotificationsAsRead());

        updateNotificationsDialogVisibility();

        notificationDialog.setOnDismissListener(dialog -> {
            notificationDialog = null;
        });

        notificationDialog.show();
    }

    private void updateNotificationsDialogVisibility() {
        if (notificationDialog == null) return;

        RecyclerView recyclerView = notificationDialog.findViewById(R.id.notifications_recycler_view);
        TextView noNotificationsText = notificationDialog.findViewById(R.id.no_notifications_text);

        if (notificationList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            noNotificationsText.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            noNotificationsText.setVisibility(View.GONE);
        }
    }

    private void acceptJarInvite(NotificationItem notification) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getJarId() == null) return;

        Toast.makeText(getContext(), "Joining jar...", Toast.LENGTH_SHORT).show();

        DocumentReference jarRef = FirebaseFirestore.getInstance()
                .collection("jars")
                .document(notification.getJarId());

        jarRef.get().addOnSuccessListener(documentSnapshot -> {
            if (!documentSnapshot.exists()) {
                Toast.makeText(getContext(), "Jar not found", Toast.LENGTH_SHORT).show();
                return;
            }

            List<String> participants = (List<String>) documentSnapshot.get("participants");
            if (participants == null) {
                participants = new ArrayList<>();
            }

            if (participants.contains(currentUser.getUid())) {
                Toast.makeText(getContext(), "You are already a participant", Toast.LENGTH_SHORT).show();
                deleteNotification(notification);
                return;
            }

            participants.add(currentUser.getUid());

            Map<String, Double> contributions = (Map<String, Double>) documentSnapshot.get("participantContributions");
            if (contributions == null) {
                contributions = new HashMap<>();
            }
            contributions.put(currentUser.getUid(), 0.0);

            Map<String, Object> updates = new HashMap<>();
            updates.put("participants", participants);
            updates.put("participantContributions", contributions);

            jarRef.update(updates)
                    .addOnSuccessListener(aVoid -> {
                        String userName = currentUser.getDisplayName();
                        if (userName == null || userName.isEmpty()) {
                            userName = currentUser.getEmail() != null ?
                                    currentUser.getEmail().split("@")[0] : "User";
                        }

                        // FIXED: Use FirestoreHelper to store in jarTransactions collection
                        FirestoreHelper.getInstance().addJarTransaction(
                                notification.getJarId(),
                                notification.getJarName(),
                                currentUser.getUid(),
                                userName,
                                "ADD_PARTICIPANT",
                                0.0,
                                "Joined the jar"
                        );

                        deleteNotification(notification);

                        Toast.makeText(getContext(),
                                "You've joined " + notification.getJarName() + "!",
                                Toast.LENGTH_LONG).show();

                        openJarDetails(notification.getJarId(), notification.getJarName());
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(getContext(),
                                "Failed to accept invitation: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                        Log.e("HomeFragment", "Accept invite error", e);
                    });
        }).addOnFailureListener(e -> {
            Toast.makeText(getContext(),
                    "Failed to load jar: " + e.getMessage(),
                    Toast.LENGTH_LONG).show();
        });
    }

    private void declineJarInvite(NotificationItem notification) {
        new AlertDialog.Builder(requireContext())
                .setTitle("Decline Invitation")
                .setMessage("Are you sure you want to decline the invitation to join '" +
                        notification.getJarName() + "'?")
                .setPositiveButton("Yes, Decline", (dialog, which) -> {
                    deleteNotification(notification);
                    Toast.makeText(getContext(), "Invitation declined", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteNotification(NotificationItem notification) {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .document(notification.getId())
                .delete()
                .addOnSuccessListener(aVoid -> {
                    notificationList.remove(notification);
                    if (notificationAdapter != null) {
                        notificationAdapter.notifyDataSetChanged();
                    }
                    updateNotificationsDialogVisibility();
                    updateNotificationBadge(getUnreadCount());
                });
    }

    private int getUnreadCount() {
        int count = 0;
        for (NotificationItem notification : notificationList) {
            if (!notification.isRead()) {
                count++;
            }
        }
        return count;
    }

    private void markNotificationAsRead(NotificationItem notification) {
        if (notification.isRead()) return;

        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null || notification.getId() == null) return;

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(currentUser.getUid())
                .collection("notifications")
                .document(notification.getId())
                .update("isRead", true)
                .addOnSuccessListener(aVoid -> {
                    notification.setRead(true);
                    if (notificationAdapter != null) {
                        notificationAdapter.notifyDataSetChanged();
                    }
                    updateNotificationBadge(getUnreadCount());
                });
    }

    private void markAllNotificationsAsRead() {
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) return;

        WriteBatch batch = FirebaseFirestore.getInstance().batch();

        for (NotificationItem notification : notificationList) {
            if (!notification.isRead()) {
                DocumentReference notifRef = FirebaseFirestore.getInstance()
                        .collection("users")
                        .document(currentUser.getUid())
                        .collection("notifications")
                        .document(notification.getId());
                batch.update(notifRef, "isRead", true);
                notification.setRead(true);
            }
        }

        batch.commit().addOnSuccessListener(aVoid -> {
            if (notificationAdapter != null) {
                notificationAdapter.notifyDataSetChanged();
            }
            updateNotificationBadge(0);
        });
    }

    private void handleNotificationClick(NotificationItem notification) {
        switch (notification.getType()) {
            case "JAR_INVITE":
                break;
            case "BILL_DUE":
                if (getActivity() instanceof MainActivity) {
                    ((MainActivity) getActivity()).selectBottomNavItem(R.id.navigation_bills);
                    if (notificationDialog != null) {
                        notificationDialog.dismiss();
                    }
                }
                break;
            case "JAR_GOAL_REACHED":
            case "JAR_UPDATE":
                if (notification.getJarId() != null) {
                    openJarDetails(notification.getJarId(), notification.getJarName());
                }
                break;
        }
    }

    private void openJarDetails(String jarId, String jarName) {
        Intent intent = new Intent(getActivity(), SharedJarsDetails.class);
        intent.putExtra("JAR_ID", jarId);
        intent.putExtra("JAR_NAME", jarName);
        intent.putExtra("JAR_SAVED", 0.0);
        intent.putExtra("JAR_GOAL", 0.0);
        intent.putExtra("ICON_NAME", "hat");
        intent.putExtra("COLOR", 0xFFF44336);
        intent.putExtra("JAR_TYPE", "Shared");
        startActivity(intent);

        if (notificationDialog != null) {
            notificationDialog.dismiss();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (notificationListener != null) {
            notificationListener.remove();
        }
    }

    // ==========================================
    // BAGONG TRANSACTION ADAPTER (Gumagamit ng totoong Transaction class)
    // ==========================================
    public static class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {
        private final List<Transaction> list;

        public TransactionAdapter(List<Transaction> list) {
            this.list = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_transaction, parent, false);
            SettingHelper.applyTheme(parent.getContext());
            return new ViewHolder(view);
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            Transaction item = list.get(position);
            Context context = holder.itemView.getContext();

            holder.tvTitle.setText(item.getTitle());

            // 1. I-set yung Date nang tama
            String dateToShow = "";
            if (item.getTimestamp() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                dateToShow = sdf.format(item.getTimestamp().toDate());
            } else if (item.getDate() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());
                dateToShow = sdf.format(item.getDate());
            } else {
                dateToShow = "Recent";
            }
            holder.tvDate.setText(dateToShow);

            // 2. I-set yung totoong Description!
            if (holder.tvDesc != null) {
                String desc = item.getDescription();
                if (desc == null || desc.trim().isEmpty()) {
                    desc = item.getCategory() != null ? item.getCategory() : "";
                }
                holder.tvDesc.setText(desc);
            }

            // 3. I-set yung Amount at kulay
            String formattedAmount = SettingHelper.formatAmount(context, item.getAmount());
            int expenseColor, incomeColor, expenseBgColor, incomeBgColor;

            if (SettingHelper.isDarkMode(context)) {
                expenseColor = Color.parseColor("#EF9A9A");
                incomeColor = Color.parseColor("#81C784");
                expenseBgColor = Color.parseColor("#4A1F1F");
                incomeBgColor = Color.parseColor("#1F4A23");
            } else {
                expenseColor = Color.parseColor("#F44336");
                incomeColor = Color.parseColor("#4CAF50");
                expenseBgColor = Color.parseColor("#FCE8E6");
                incomeBgColor = Color.parseColor("#E6F4EA");
            }

            if (item.isExpense()) { // Gamit na ang isExpense() na method
                holder.tvAmount.setText(context.getString(R.string.amount_format_negative, formattedAmount));
                holder.tvAmount.setTextColor(expenseColor);
                holder.cardBackground.setCardBackgroundColor(expenseBgColor);
                holder.iconImage.setImageResource(R.drawable.ic_arrow_down);
                holder.iconImage.setColorFilter(expenseColor);
            } else {
                holder.tvAmount.setText(context.getString(R.string.amount_format_positive, formattedAmount));
                holder.tvAmount.setTextColor(incomeColor);
                holder.cardBackground.setCardBackgroundColor(incomeBgColor);
                holder.iconImage.setImageResource(R.drawable.ic_arrow_up);
                holder.iconImage.setColorFilter(incomeColor);
            }

            // Theme handling para sa text
            if (SettingHelper.isDarkMode(context)) {
                holder.tvTitle.setTextColor(Color.WHITE);
                holder.tvDate.setTextColor(Color.LTGRAY);
                if (holder.tvDesc != null) holder.tvDesc.setTextColor(Color.LTGRAY);
            } else {
                holder.tvTitle.setTextColor(Color.BLACK);
                holder.tvDate.setTextColor(Color.DKGRAY);
                if (holder.tvDesc != null) holder.tvDesc.setTextColor(Color.DKGRAY);
            }
        }

        @Override
        public int getItemCount() {
            return list.size();
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvTitle, tvDate, tvAmount, tvDesc;
            CardView cardBackground;
            ImageView iconImage;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvTitle = itemView.findViewById(R.id.text_title);
                tvDate = itemView.findViewById(R.id.text_date);
                tvAmount = itemView.findViewById(R.id.text_amount);

                // Kumokonekta na ulit tayo sa XML id na ginawa mo kanina
                tvDesc = itemView.findViewById(R.id.text_desc);

                cardBackground = itemView.findViewById(R.id.icon_background_card);
                iconImage = itemView.findViewById(R.id.icon_image);
            }
        }
    }
}