package com.example.fintrac;

import android.app.IntentService;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class BillReminderService extends IntentService {

    private static final String CHANNEL_ID = "bill_reminders";
    private static final String CHANNEL_NAME = "Bill Reminders";
    private static final String CHANNEL_DESC = "Notifications for upcoming bill due dates";

    public BillReminderService() {
        super("BillReminderService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        checkDueBills();
    }

    private void checkDueBills() {
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        // Get tomorrow's date in the format stored in your database
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault());
        long tomorrow = System.currentTimeMillis() + TimeUnit.DAYS.toMillis(1);
        String tomorrowDate = "Due: " + sdf.format(new Date(tomorrow));

        Log.d("BillReminder", "Checking for bills due on: " + tomorrowDate);

        db.collection("bills")
                .whereEqualTo("dueDate", tomorrowDate)
                .whereEqualTo("isPaid", false)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        Log.d("BillReminder", "No bills due tomorrow");
                        return;
                    }

                    for (QueryDocumentSnapshot doc : queryDocumentSnapshots) {
                        Boolean isArchived = doc.getBoolean("isArchived");
                        if (isArchived != null && isArchived) {
                            continue;
                        }

                        String billName = doc.getString("name");
                        String billAmount = doc.getString("amount");

                        // Clean amount for display
                        if (billAmount != null) {
                            billAmount = billAmount.replace("Due: ", "");
                            // Extract just the number part
                            billAmount = billAmount.replaceAll("[^\\d.]", "");
                        }

                        sendNotification(billName, billAmount);
                    }
                })
                .addOnFailureListener(e ->
                        Log.e("BillReminder", "Error checking bills", e));
    }

    private void sendNotification(String billName, String amount) {
        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        // Create notification channel for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(CHANNEL_DESC);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 500, 200, 500});
            notificationManager.createNotificationChannel(channel);
        }

        // Create intent to open Bills fragment when notification is clicked
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("open_fragment", "bills");
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                this,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Format the amount if needed
        String displayAmount = "₱" + amount;
        try {
            double amountVal = Double.parseDouble(amount);
            displayAmount = SettingHelper.formatAmount(this, amountVal);
        } catch (NumberFormatException e) {
            // Use the original amount if parsing fails
        }

        // Build notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notifications)
                .setContentTitle("💰 Bill Due Tomorrow!")
                .setContentText(billName + " of " + displayAmount + " is due tomorrow")
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(billName + " of " + displayAmount + " is due tomorrow. Don't forget to pay it!"))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setVibrate(new long[]{0, 500, 200, 500});

        // Show notification
        int notificationId = (int) System.currentTimeMillis();
        notificationManager.notify(notificationId, builder.build());

        Log.d("BillReminder", "Notification sent for: " + billName);
    }
}