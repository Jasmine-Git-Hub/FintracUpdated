package com.example.fintrac;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.checkbox.MaterialCheckBox;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

@SuppressLint("SetTextI18n")
public class Bills extends Fragment implements BillsAdapter.BillActionListener {

    private RecyclerView recyclerView;
    private BillsAdapter adapter;
    private List<Bill> billList;
    private ChipGroup chipGroupCategory;

    private TextView tvTotalDue, tvTotalPaid;

    private FirestoreService firestoreService;
    private boolean isLoading = false;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        SettingHelper.applyTheme(requireActivity());
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
        return inflater.inflate(R.layout.fragment_bills, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }

        tvTotalDue = view.findViewById(R.id.tvTotalDue);
        tvTotalPaid = view.findViewById(R.id.tvTotalPaid);

        firestoreService = new FirestoreService();

        setupRecyclerView(view);
        setupAddBillButton(view);
        setupCategoryChips(view);
        setupSwipeActions();

        loadBillsFromFirestore();
        scheduleBillReminders();
    }

    private void loadBillsFromFirestore() {
        if (isLoading) return;
        isLoading = true;

        firestoreService.getAllBills()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    billList.clear();
                    for (com.google.firebase.firestore.QueryDocumentSnapshot doc : queryDocumentSnapshots) {

                        Boolean isArchived = doc.getBoolean("isArchived");
                        if (isArchived != null && isArchived) {
                            continue;
                        }

                        Long logoResIdLong = doc.getLong("logoResId");
                        int logoResId = (logoResIdLong != null) ? logoResIdLong.intValue() : R.drawable.ic_visual_reports;

                        Boolean isPaid = doc.getBoolean("isPaid");
                        boolean isPaidValue = (isPaid != null) ? isPaid : false;

                        Bill bill = new Bill(
                                doc.getId(),
                                doc.getString("name"),
                                doc.getString("category"),
                                doc.getString("frequency"),
                                doc.getString("amount"),
                                doc.getString("dueDate"),
                                logoResId,
                                isPaidValue
                        );
                        billList.add(bill);
                    }

                    filterBills(getCurrentFilter());
                    calculateSummary();
                    isLoading = false;
                })
                .addOnFailureListener(e -> {
                    Log.e("BillsFragment", "Error loading bills", e);
                    Toast.makeText(requireContext(), "Failed to load bills", Toast.LENGTH_SHORT).show();
                    isLoading = false;
                });
    }

    @Override
    public void onBillPaid(Bill bill, int position) {
        if (bill == null || adapter == null) return;

        boolean newStatus = !bill.isPaid;

        if (newStatus) {
            firestoreService.archiveBill(bill.id)
                    .addOnSuccessListener(aVoid -> {
                        billList.remove(position);
                        adapter.notifyItemRemoved(position);
                        filterBills(getCurrentFilter());
                        calculateSummary();
                        Toast.makeText(requireContext(), "Bill paid and moved to Archives", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Log.e("BillsFragment", "Error archiving bill", e);
                        Toast.makeText(requireContext(), "Failed to move to archives", Toast.LENGTH_SHORT).show();
                        adapter.notifyItemChanged(position);
                    });
        } else {
            bill.isPaid = false;
            firestoreService.updateBillPaidStatus(bill.id, false)
                    .addOnSuccessListener(aVoid -> {
                        adapter.billPaid(position, false);
                        calculateSummary();
                        Toast.makeText(requireContext(), "Bill marked as unpaid", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Log.e("BillsFragment", "Error updating bill status", e);
                        Toast.makeText(requireContext(), "Failed to update bill status", Toast.LENGTH_SHORT).show();
                        adapter.notifyItemChanged(position);
                    });
        }
    }

    @Override
    public void onBillEdit(Bill bill, int position) {
        showAddOrEditBillDialog(bill);
    }

    @Override
    public void onBillDelete(Bill bill, int position) {
        if (bill == null || bill.id == null) return;

        new AlertDialog.Builder(requireContext())
                .setTitle("Delete Bill")
                .setMessage("Are you sure you want to delete '" + bill.name + "'?")
                .setPositiveButton("Delete", (dialog, which) -> {
                    firestoreService.deleteBill(bill.id)
                            .addOnSuccessListener(aVoid -> {
                                billList.remove(bill);
                                filterBills(getCurrentFilter());
                                calculateSummary();
                                Toast.makeText(requireContext(), "Bill deleted", Toast.LENGTH_SHORT).show();
                            })
                            .addOnFailureListener(e -> {
                                Log.e("BillsFragment", "Error deleting bill", e);
                                Toast.makeText(requireContext(), "Failed to delete bill", Toast.LENGTH_SHORT).show();
                                if (adapter != null) adapter.notifyItemChanged(position);
                            });
                })
                .setNegativeButton("Cancel", (dialog, which) -> {
                    if (adapter != null) adapter.notifyItemChanged(position);
                })
                .show();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            SettingHelper.applyTheme(getActivity());
        }
    }

    private void setupRecyclerView(View view) {
        recyclerView = view.findViewById(R.id.rvBillsList);
        if (recyclerView == null) return;

        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));

        billList = new ArrayList<>();

        adapter = new BillsAdapter(billList, this);
        recyclerView.setAdapter(adapter);
    }

    private void calculateSummary() {
        double totalDue = 0;
        double totalPaid = 0;

        if (billList == null) return;

        for (Bill bill : billList) {
            if (bill.amount == null) continue;
            String cleanAmount = bill.amount.replaceAll("[^\\d.]", "");
            double amount = 0;
            try {
                if (!cleanAmount.isEmpty()) {
                    amount = Double.parseDouble(cleanAmount);
                }
            } catch (NumberFormatException e) {
                Log.e("BillsFragment", "Error parsing amount: " + cleanAmount, e);
            }

            if (bill.isPaid) {
                totalPaid += amount;
            } else {
                totalDue += amount;
            }
        }

        if (tvTotalDue != null && getContext() != null) {
            tvTotalDue.setText(SettingHelper.formatAmount(getContext(), totalDue));
        }
        if (tvTotalPaid != null && getContext() != null) {
            tvTotalPaid.setText(SettingHelper.formatAmount(getContext(), totalPaid));
        }
    }

    private void setupCategoryChips(View view) {
        chipGroupCategory = view.findViewById(R.id.chipGroupCategory);
        if (chipGroupCategory == null) return;

        Chip chipAll = view.findViewById(R.id.chipAll);
        if (chipAll != null) {
            chipAll.setChecked(true);
        }

        chipGroupCategory.setOnCheckedStateChangeListener((group, checkedIds) -> {
            if (checkedIds.isEmpty()) return;
            int checkedId = checkedIds.get(0);
            Chip chip = group.findViewById(checkedId);
            if (chip != null) {
                filterBills(chip.getText().toString());
            }
        });
    }

    private void filterBills(String category) {
        if (billList == null || adapter == null) return;
        List<Bill> filteredList = new ArrayList<>();
        if (category == null || category.equalsIgnoreCase("All")) {
            filteredList.addAll(billList);
        } else {
            for (Bill bill : billList) {
                if (bill.category != null && bill.category.equalsIgnoreCase(category)) {
                    filteredList.add(bill);
                }
            }
        }
        adapter.setBills(filteredList);
    }

    private void setupAddBillButton(View view) {
        FloatingActionButton fabAdd = view.findViewById(R.id.fabAddBill);
        if (fabAdd != null) {
            fabAdd.setOnClickListener(v -> showAddOrEditBillDialog(null));
        }
    }

    private void setupSwipeActions() {
        if (recyclerView == null) return;
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getBindingAdapterPosition();
                if (position == RecyclerView.NO_POSITION) return;

                Bill bill = adapter.getBillAt(position);
                if (bill == null) {
                    adapter.notifyItemChanged(position);
                    return;
                }

                if (direction == ItemTouchHelper.LEFT) {
                    onBillDelete(bill, position);
                } else {
                    onBillEdit(bill, position);
                }
            }
        }).attachToRecyclerView(recyclerView);
    }

    private String getCurrentFilter() {
        if (chipGroupCategory == null) return "All";
        int checkedId = chipGroupCategory.getCheckedChipId();
        if (checkedId == View.NO_ID) return "All";
        Chip chip = chipGroupCategory.findViewById(checkedId);
        return chip != null ? chip.getText().toString() : "All";
    }

    private void scheduleBillReminders() {
        AlarmManager alarmManager = (AlarmManager) requireContext().getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(requireContext(), BillReminderReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                requireContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.set(Calendar.HOUR_OF_DAY, 8);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);

        if (calendar.getTimeInMillis() <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1);
        }

        alarmManager.setRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY,
                pendingIntent
        );
    }

    private void showAddOrEditBillDialog(@Nullable Bill existingBill) {
        try {
            boolean isEditMode = existingBill != null;

            android.view.ContextThemeWrapper wrapper = new android.view.ContextThemeWrapper(requireContext(),
                    com.google.android.material.R.style.Theme_Material3_DayNight_NoActionBar);

            View dialogView = LayoutInflater.from(wrapper).inflate(R.layout.dialog_add_bill, null);
            AlertDialog dialog = new AlertDialog.Builder(requireContext()).setView(dialogView).create();

            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }

            TextInputEditText etName = dialogView.findViewById(R.id.etBillName);
            TextInputEditText etAmount = dialogView.findViewById(R.id.etAmount);
            TextInputEditText etDueDate = dialogView.findViewById(R.id.etDueDate);
            AutoCompleteTextView actCategory = dialogView.findViewById(R.id.actCategory);
            com.google.android.material.textfield.TextInputLayout tilFrequency = dialogView.findViewById(R.id.tilFrequency);
            AutoCompleteTextView actFrequency = dialogView.findViewById(R.id.actFrequency);

            MaterialCheckBox cbRecurring = dialogView.findViewById(R.id.cbRecurring);
            MaterialCheckBox cbReminder = dialogView.findViewById(R.id.cbReminder);
            MaterialButton btnSave = dialogView.findViewById(R.id.btnAddBill);
            ImageView btnClose = dialogView.findViewById(R.id.btnClose);

            if (cbRecurring != null && tilFrequency != null) {
                cbRecurring.setOnCheckedChangeListener((buttonView, isChecked) ->
                        tilFrequency.setVisibility(isChecked ? View.VISIBLE : View.GONE));
            }

            if (actFrequency != null) {
                String[] freqOptions = getResources().getStringArray(R.array.frequency_options);
                ArrayAdapter<String> freqAdapter = new ArrayAdapter<>(requireContext(),
                        android.R.layout.simple_dropdown_item_1line, freqOptions);
                actFrequency.setAdapter(freqAdapter);
            }

            if (etDueDate != null) {
                etDueDate.setOnClickListener(v -> {
                    final java.util.Calendar c = java.util.Calendar.getInstance();
                    int mYear = c.get(java.util.Calendar.YEAR);
                    int mMonth = c.get(java.util.Calendar.MONTH);
                    int mDay = c.get(java.util.Calendar.DAY_OF_MONTH);

                    android.app.DatePickerDialog datePickerDialog = new android.app.DatePickerDialog(requireContext(),
                            (view, year, monthOfYear, dayOfMonth) -> {
                                String selectedDate = (monthOfYear + 1) + "/" + dayOfMonth + "/" + year;
                                etDueDate.setText(selectedDate);
                            }, mYear, mMonth, mDay);
                    datePickerDialog.show();
                });
            }

            if (actCategory != null) {
                String[] categories = {"Utilities", "Subscriptions", "Loans", "Rent", "Groceries", "Transportation", "Others"};
                ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(requireContext(),
                        android.R.layout.simple_dropdown_item_1line, categories);
                actCategory.setAdapter(categoryAdapter);
            }

            if (isEditMode) {
                if (etName != null) etName.setText(existingBill.name);
                if (etAmount != null && existingBill.amount != null) {
                    try {
                        double phpAmount = Double.parseDouble(existingBill.amount.replaceAll("[^\\d.]", ""));
                        double displayAmt = phpAmount * SettingHelper.getExchangeRate(requireContext(), SettingHelper.getCurrency(requireContext()));
                        etAmount.setText(String.format(java.util.Locale.US, "%.2f", displayAmt));
                    } catch (Exception e) {
                        etAmount.setText(existingBill.amount.replaceAll("[^\\d.]", ""));
                    }
                }
                if (etDueDate != null && existingBill.dueDate != null) {
                    String dateOnly = existingBill.dueDate.replace("Due: ", "");
                    etDueDate.setText(dateOnly);
                }
                if (actCategory != null) actCategory.setText(existingBill.category, false);
                if (btnSave != null) btnSave.setText(R.string.save_changes);

                if (existingBill.frequency != null && !existingBill.frequency.equalsIgnoreCase("One-time")) {
                    if (cbRecurring != null) cbRecurring.setChecked(true);
                    if (actFrequency != null) actFrequency.setText(existingBill.frequency, false);
                }
            }

            if (btnClose != null) {
                btnClose.setOnClickListener(v -> dialog.dismiss());
            }

            if (btnSave != null) {
                btnSave.setOnClickListener(v -> {
                    String nameStr = (etName != null && etName.getText() != null) ? etName.getText().toString().trim() : "";
                    String amountStr = (etAmount != null && etAmount.getText() != null) ? etAmount.getText().toString().trim() : "";
                    String dateStr = (etDueDate != null && etDueDate.getText() != null) ? etDueDate.getText().toString().trim() : "";
                    String categoryStr = (actCategory != null && actCategory.getText() != null) ? actCategory.getText().toString().trim() : "Utilities";

                    String freqStr = "One-time";
                    if (cbRecurring != null && cbRecurring.isChecked()) {
                        if (actFrequency != null && actFrequency.getText() != null && !actFrequency.getText().toString().isEmpty()) {
                            freqStr = actFrequency.getText().toString();
                        } else {
                            freqStr = "Monthly";
                        }
                    }

                    if (nameStr.isEmpty() || amountStr.isEmpty() || dateStr.isEmpty()) {
                        Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    double amountInPHP;
                    try {
                        String cleanStr = amountStr.replaceAll("[^\\d.]", "");
                        double uiAmount = Double.parseDouble(cleanStr);
                        amountInPHP = SettingHelper.convertToBasePHP(requireContext(), uiAmount);
                    } catch (NumberFormatException e) {
                        Toast.makeText(requireContext(), "Invalid amount", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    boolean isPaidStatus = isEditMode && existingBill != null && existingBill.isPaid;

                    Bill bill = new Bill(
                            nameStr,
                            categoryStr,
                            freqStr,
                            String.valueOf(amountInPHP),
                            "Due: " + dateStr,
                            R.drawable.ic_visual_reports,
                            isPaidStatus
                    );

                    if (isEditMode && existingBill != null) {
                        firestoreService.updateBill(existingBill.id, bill)
                                .addOnSuccessListener(aVoid -> {
                                    int index = billList.indexOf(existingBill);
                                    if (index != -1) {
                                        bill.id = existingBill.id;
                                        billList.set(index, bill);
                                    }
                                    filterBills(getCurrentFilter());
                                    calculateSummary();
                                    dialog.dismiss();
                                    Toast.makeText(requireContext(), "Bill updated", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("BillsFragment", "Error updating bill", e);
                                    Toast.makeText(requireContext(), "Failed to update bill", Toast.LENGTH_SHORT).show();
                                });
                    } else {
                        firestoreService.addBill(bill)
                                .addOnSuccessListener(documentReference -> {
                                    bill.id = documentReference.getId();
                                    billList.add(bill);
                                    filterBills(getCurrentFilter());
                                    calculateSummary();
                                    dialog.dismiss();
                                    Toast.makeText(requireContext(), "Bill added", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e -> {
                                    Log.e("BillsFragment", "Error adding bill", e);
                                    Toast.makeText(requireContext(), "Failed to add bill", Toast.LENGTH_SHORT).show();
                                });
                    }
                });
            }

            dialog.show();

        } catch (Exception e) {
            Log.e("BillsFragment", "Error showing dialog", e);
            Toast.makeText(requireContext(), "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}