package com.example.fintrac;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

public class BillReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("BillReminder", "Alarm triggered, starting service...");
        // Start the service to check for due bills
        Intent serviceIntent = new Intent(context, BillReminderService.class);
        context.startService(serviceIntent);
    }
}