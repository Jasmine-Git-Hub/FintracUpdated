package com.example.fintrac;

public class ChallengeIconHelper {

    public static int getIcon(String name) {
        if (name == null) return R.drawable.hat; // Default fallback
        String lower = name.toLowerCase();

        if (lower.contains("café") || lower.contains("coffee")) return R.drawable.coffee;
        if (lower.contains("pesos") || lower.contains("p50") || lower.contains("save")) return R.drawable.savings;
        if (lower.contains("fast food") || lower.contains("eat") || lower.contains("burger")) return R.drawable.burger;
        if (lower.contains("baon")) return R.drawable.ic_lunchbox; // Make sure you have this drawable
        if (lower.contains("sweets") || lower.contains("ban")) return R.drawable.ic_sweets; // Make sure you have this drawable
        if (lower.contains("walkathon") || lower.contains("walk") || lower.contains("transport")) return R.drawable.airplane;
        if (lower.contains("water")) return R.drawable.ic_water; // Make sure you have this drawable
        if (lower.contains("shopping")) return R.drawable.ic_shopping_cart; // Make sure you have this drawable
        if (lower.contains("wi-fi") || lower.contains("wifi")) return R.drawable.ic_wifi; // Make sure you have this drawable
        if (lower.contains("homebody") || lower.contains("home")) return R.drawable.ic_home; // Make sure you have this drawable

        return R.drawable.hat;
    }

    public static int getColor(String name) {
        if (name == null) return R.color.challenge_orange; // Default fallback
        String lower = name.toLowerCase();

        if (lower.contains("café") || lower.contains("coffee")) return R.color.challenge_orange;
        if (lower.contains("pesos") || lower.contains("p50") || lower.contains("save")) return R.color.challenge_blue;
        if (lower.contains("fast food") || lower.contains("eat") || lower.contains("sweets") || lower.contains("baon")) return R.color.challenge_red;
        if (lower.contains("walkathon") || lower.contains("walk") || lower.contains("transport")) return R.color.challenge_green;
        if (lower.contains("water")) return R.color.ocean_blue; // Assuming you have ocean_blue in colors.xml
        if (lower.contains("shopping")) return R.color.royal_purple; // Assuming you have royal_purple in colors.xml
        if (lower.contains("wi-fi") || lower.contains("wifi")) return R.color.sunset_orange; // Assuming you have sunset_orange in colors.xml
        if (lower.contains("homebody") || lower.contains("home")) return R.color.forest_green; // Assuming you have forest_green in colors.xml

        return R.color.challenge_orange;
    }
}