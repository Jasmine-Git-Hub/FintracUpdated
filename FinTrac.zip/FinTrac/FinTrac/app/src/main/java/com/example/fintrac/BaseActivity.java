package com.example.fintrac;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        // Apply theme before super.onCreate
        SettingHelper.applyTheme(this);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Apply theme color when activity resumes
        SettingHelper.applyThemeColor(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }
}